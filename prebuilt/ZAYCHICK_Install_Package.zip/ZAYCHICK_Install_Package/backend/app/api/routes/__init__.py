"""FastAPI routers package."""
