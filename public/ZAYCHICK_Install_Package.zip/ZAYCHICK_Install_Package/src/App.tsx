/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  BookOpen,
  Bookmark,
  Calendar,
  CheckSquare,
  CloudSun,
  Columns,
  Edit3,
  FilePlus2,
  FileSpreadsheet,
  Filter,
  HardDriveDownload,
  History,
  Layers,
  Lock,
  Menu,
  Plus,
  Redo2,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Trash2,
  Undo2,
  UserCheck,
} from 'lucide-react';
import {
  AppSection,
  AuditLogEntry,
  ColumnDefinition,
  ColumnTemplate,
  FacilityObject,
  LRVItem,
  ProjectLineItem,
  ReadinessGroupCondition,
  TechCardItem,
  UserAccount,
  WelderProfile,
  WeldingMaterialCertificate,
  WeldJoint,
  WeldJointFieldKey,
} from './types/welding';
import {
  ALL_COLUMNS,
  applyBulkUpdateToJoints,
  applyBulkUpdateToLineList,
  buildUniqueLineId,
  DEFAULT_COLUMN_KEYS,
  deriveFacilitiesFromLineList,
  estimateAmbientTempByCoordsAndDate,
  fetchAmbientTemperatureAuto,
  FIELD_LABELS_MAP,
  formatDateDDMMYY,
  isDateColumnKey,
  isWeldingDateInRange,
  MAX_HISTORY_STEPS,
  performRedoStep,
  performUndoStep,
  pushHistorySnapshot,
  suggestNextJointNumber,
} from './utils/weldingLogic';
import {
  FACILITY_LOCATION_PRESETS,
  FACILITY_OBJECTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_COLUMN_TEMPLATES,
  INITIAL_JOINTS,
  INITIAL_LRV_CATALOG,
  INITIAL_PROJECT_LINELIST,
  INITIAL_TECH_CARDS,
  INITIAL_WELDING_MATERIALS,
  INSPECTORS_DIRECTORY,
  USER_ACCOUNTS,
  WELDERS_DIRECTORY,
} from './data/seedData';
import { exportAllJointsToFile } from './utils/excelUtils';
import { ZaychickLogo } from './components/ZaychickLogo';
import { HamburgerDrawer } from './components/HamburgerDrawer';
import { ExcelColumnFilter } from './components/ExcelColumnFilter';
import { ColumnTemplatesModal } from './components/ColumnTemplatesModal';
import { BulkEditModal } from './components/BulkEditModal';
import { JointPassportModal } from './components/JointPassportModal';
import { WeldingJournalsView } from './components/WeldingJournalsView';
import { ReadinessReportView } from './components/ReadinessReportView';
import { LrvCatalogView } from './components/LrvCatalogView';
import { AuditHistoryView } from './components/AuditHistoryView';
import { LoginModal } from './components/LoginModal';
import { ProjectLineListView } from './components/ProjectLineListView';
import { WeldingTechView } from './components/WeldingTechView';
import { FacilityLocationModal } from './components/FacilityLocationModal';
import { ImportJointsExcelModal } from './components/ImportJointsExcelModal';
import { UserGuideBookletView } from './components/UserGuideBookletView';
import {
  BackupAndResetModal,
  FullSystemBackupPayload,
} from './components/BackupAndResetModal';

const STORAGE_KEYS = {
  TEMPLATES: 'zaychick_column_templates_v2',
  ACTIVE_TPL: 'zaychick_active_template_id_v2',
  FULL_STATE: 'zaychick_app_full_state_v1',
};

const EMPTY_FACILITY_FALLBACK: FacilityObject = {
  id: 'fac-empty-default',
  name: 'Новый объект',
  shortName: 'Новый объект',
  region: 'ЯНАО',
  weatherStation: 'Метеостанция объекта',
  latitude: 66.53,
  longitude: 66.6,
  rdCodes: [
    {
      code: 'НОВЫЙ-ШИФР-РД',
      title: 'Рабочая документация',
      contours: ['Основной контур'],
    },
  ],
};

interface AppDataSnapshot {
  actionLabel: string;
  joints: WeldJoint[];
  projectLineList: ProjectLineItem[];
  lrvCatalog: LRVItem[];
  auditLogs: AuditLogEntry[];
  welders: WelderProfile[];
  techCards: TechCardItem[];
  weldingMaterials: WeldingMaterialCertificate[];
  facilityGeoOverrides: Record<
    string,
    {
      region: string;
      weatherStation: string;
      latitude: number;
      longitude: number;
    }
  >;
}

type PersistedAppState = FullSystemBackupPayload['data'] & {
  selectedObjectName?: string;
  selectedRdCode?: string;
};

function loadSavedFullState(): Partial<PersistedAppState> | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FULL_STATE);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return parsed;
    }
  } catch {
    // ignore storage read errors
  }
  return null;
}

export default function App() {
  const initialSavedState = useMemo(() => loadSavedFullState(), []);

  // Авторизованный пользователь и пул зарегистрированных учётных записей
  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() =>
    Array.isArray(initialSavedState?.userAccounts) &&
    initialSavedState.userAccounts.length > 0
      ? initialSavedState.userAccounts
      : USER_ACCOUNTS
  );
  const [currentUser, setCurrentUser] = useState<UserAccount>(() =>
    Array.isArray(initialSavedState?.userAccounts) &&
    initialSavedState.userAccounts.length > 0
      ? initialSavedState.userAccounts[0]
      : USER_ACCOUNTS[0]
  );
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Кнопка-бутерброд (выбор объекта и основного раздела программы)
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<AppSection>('registry');
  const [selectedObjectName, setSelectedObjectName] = useState<string>(() =>
    typeof initialSavedState?.selectedObjectName === 'string'
      ? initialSavedState.selectedObjectName
      : FACILITY_OBJECTS[0].name
  );
  const [selectedRdCode, setSelectedRdCode] = useState<string>(() =>
    typeof initialSavedState?.selectedRdCode === 'string'
      ? initialSavedState.selectedRdCode
      : 'ALL'
  );

  // Основные данные системы
  const [joints, setJoints] = useState<WeldJoint[]>(() =>
    Array.isArray(initialSavedState?.joints)
      ? initialSavedState.joints
      : INITIAL_JOINTS
  );
  const [projectLineList, setProjectLineList] = useState<ProjectLineItem[]>(
    () =>
      Array.isArray(initialSavedState?.projectLineList)
        ? initialSavedState.projectLineList
        : INITIAL_PROJECT_LINELIST
  );
  const [lrvCatalog, setLrvCatalog] = useState<LRVItem[]>(() =>
    Array.isArray(initialSavedState?.lrvCatalog)
      ? initialSavedState.lrvCatalog
      : INITIAL_LRV_CATALOG
  );
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() =>
    Array.isArray(initialSavedState?.auditLogs)
      ? initialSavedState.auditLogs
      : INITIAL_AUDIT_LOGS
  );

  // Данные раздела «Технология сварочного производства»
  const [welders, setWelders] = useState<WelderProfile[]>(() =>
    Array.isArray(initialSavedState?.welders)
      ? initialSavedState.welders
      : WELDERS_DIRECTORY
  );
  const [techCards, setTechCards] = useState<TechCardItem[]>(() =>
    Array.isArray(initialSavedState?.techCards)
      ? initialSavedState.techCards
      : INITIAL_TECH_CARDS
  );
  const [weldingMaterials, setWeldingMaterials] = useState<
    WeldingMaterialCertificate[]
  >(() =>
    Array.isArray(initialSavedState?.weldingMaterials)
      ? initialSavedState.weldingMaterials
      : INITIAL_WELDING_MATERIALS
  );

  // Пользовательские геокоординаты, метеопункты и регионы объектов для автоматического расчёта температуры воздуха
  const [facilityGeoOverrides, setFacilityGeoOverrides] = useState<
    Record<
      string,
      {
        region: string;
        weatherStation: string;
        latitude: number;
        longitude: number;
      }
    >
  >(() =>
    initialSavedState?.facilityGeoOverrides &&
    typeof initialSavedState.facilityGeoOverrides === 'object'
      ? initialSavedState.facilityGeoOverrides
      : {}
  );
  const [locationModalFacilityName, setLocationModalFacilityName] = useState<
    string | null
  >(null);

  // Модальное окно резервного копирования (.JSON) и скрытой консоли автора («Чистый лист»)
  const [backupModalState, setBackupModalState] = useState<{
    isOpen: boolean;
    initialTab: 'backup' | 'author_reset';
  }>({
    isOpen: false,
    initialTab: 'backup',
  });

  // Скрытый счётчик 5 кликов по логотипу ZAYCHICK в шапке для вызова Консоли Автора
  const logoClickCountRef = useRef(0);
  const logoClickTimerRef = useRef<number | null>(null);

  const handleHeaderLogoSecretClick = () => {
    logoClickCountRef.current += 1;
    if (logoClickTimerRef.current) {
      window.clearTimeout(logoClickTimerRef.current);
    }
    if (logoClickCountRef.current >= 5) {
      logoClickCountRef.current = 0;
      setBackupModalState({ isOpen: true, initialTab: 'author_reset' });
      return;
    }
    logoClickTimerRef.current = window.setTimeout(() => {
      logoClickCountRef.current = 0;
    }, 2500);
  };

  // Стек отмены / повтора на 10 действий (Undo / Redo)
  const [undoStack, setUndoStack] = useState<AppDataSnapshot[]>([]);
  const [redoStack, setRedoStack] = useState<AppDataSnapshot[]>([]);
  const [confirmBulkDeleteJoints, setConfirmBulkDeleteJoints] = useState(false);

  const appendSystemAuditEntry = (
    actionType: string,
    uniqueLineId: string,
    jointNumber: string,
    fieldChanged: string,
    oldValue: string,
    newValue: string,
    jointId = 'sys-dict'
  ) => {
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      userLogin: currentUser.login,
      userFullName: currentUser.fullName,
      userRole: currentUser.role,
      jointId,
      jointNumber,
      uniqueLineId,
      rdCode: selectedRdCode === 'ALL' ? 'СИСТЕМА' : selectedRdCode,
      fieldKey: 'system',
      fieldLabel: fieldChanged,
      oldValue,
      newValue,
      operationType:
        actionType === 'Создание стыка' ? 'create_joint' : 'single_edit',
    };
    setAuditLogs((prev) => [entry, ...prev]);
  };

  const buildCurrentSnapshot = (actionLabel: string): AppDataSnapshot => ({
    actionLabel,
    joints,
    projectLineList,
    lrvCatalog,
    auditLogs,
    welders,
    techCards,
    weldingMaterials,
    facilityGeoOverrides,
  });

  const recordUndoSnapshot = (actionLabel: string) => {
    const snap = buildCurrentSnapshot(actionLabel);
    setUndoStack((prev) => pushHistorySnapshot(prev, snap, MAX_HISTORY_STEPS).undoStack);
    setRedoStack([]);
  };

  // При откате/повторе (Undo/Redo) журнал аудита остаётся неизменяемым (append-only) и фиксирует сам факт отката/повтора
  const applySnapshotState = (snap: AppDataSnapshot) => {
    setJoints(snap.joints);
    setProjectLineList(snap.projectLineList);
    setLrvCatalog(snap.lrvCatalog);
    setWelders(snap.welders);
    setTechCards(snap.techCards);
    setWeldingMaterials(snap.weldingMaterials);
    setFacilityGeoOverrides(snap.facilityGeoOverrides);
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const lastAction = undoStack[undoStack.length - 1]?.actionLabel || 'действие';
    const currentSnap = buildCurrentSnapshot(lastAction);
    const res = performUndoStep(undoStack, redoStack, currentSnap, MAX_HISTORY_STEPS);
    if (res.targetState) {
      setUndoStack(res.undoStack);
      setRedoStack(res.redoStack);
      applySnapshotState(res.targetState);
      appendSystemAuditEntry(
        'Редактирование',
        'СИСТЕМА (UNDO)',
        '—',
        'Отмена действия (Undo)',
        lastAction,
        'Состояние восстановлено'
      );
    }
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const nextAction = redoStack[redoStack.length - 1]?.actionLabel || 'действие';
    const currentSnap = buildCurrentSnapshot(nextAction);
    const res = performRedoStep(undoStack, redoStack, currentSnap, MAX_HISTORY_STEPS);
    if (res.targetState) {
      setUndoStack(res.undoStack);
      setRedoStack(res.redoStack);
      applySnapshotState(res.targetState);
      appendSystemAuditEntry(
        'Редактирование',
        'СИСТЕМА (REDO)',
        '—',
        'Повтор действия (Redo)',
        'Отменённое состояние',
        nextAction
      );
    }
  };

  // Горячие клавиши Ctrl+Z (Undo) и Ctrl+Y / Ctrl+Shift+Z (Redo)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInput =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable);
      // Секретная комбинация клавиш автора: Ctrl + Shift + Alt + Z
      if (
        (e.ctrlKey || e.metaKey) &&
        e.shiftKey &&
        e.altKey &&
        e.key.toLowerCase() === 'z'
      ) {
        e.preventDefault();
        setBackupModalState({ isOpen: true, initialTab: 'author_reset' });
        return;
      }

      if (isInput) return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  // Шаблоны столбцов (положение включенных и перенесённых столбцов)
  const [templates, setTemplates] = useState<ColumnTemplate[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return INITIAL_COLUMN_TEMPLATES;
  });

  const [activeTemplateId, setActiveTemplateId] = useState<string>('tpl-full-30');
  const [columnOrder, setColumnOrder] = useState<WeldJointFieldKey[]>([
    ...DEFAULT_COLUMN_KEYS,
  ]);
  const [visibleColumns, setVisibleColumns] = useState<WeldJointFieldKey[]>([
    ...DEFAULT_COLUMN_KEYS,
  ]);
  const [isColumnsModalOpen, setIsColumnsModalOpen] = useState(false);

  // Поиск, диапазон дат сварки, Excel-фильтры по столбцам и сортировка
  const [globalSearch, setGlobalSearch] = useState('');
  const [weldingDateFrom, setWeldingDateFrom] = useState('');
  const [weldingDateTo, setWeldingDateTo] = useState('');
  const [columnFilters, setColumnFilters] = useState<
    Partial<Record<WeldJointFieldKey, string[]>>
  >({});
  const [openFilterColumnKey, setOpenFilterColumnKey] =
    useState<WeldJointFieldKey | null>(null);
  const [sortConfig, setSortConfig] = useState<{
    key: WeldJointFieldKey;
    direction: 'asc' | 'desc';
  } | null>(null);

  // Выделенные строки для массового редактирования (за исключением номера стыка)
  const [selectedJointIds, setSelectedJointIds] = useState<string[]>([]);
  const [isBulkEditOpen, setIsBulkEditOpen] = useState(false);

  // Паспорт стыка (создание основного / дополнительного стыка или редактирование)
  const [passportModal, setPassportModal] = useState<{
    isOpen: boolean;
    mode: 'create' | 'edit';
    joint: WeldJoint | null;
  }>({
    isOpen: false,
    mode: 'create',
    joint: null,
  });

  // Модальное окно загрузки данных в реестр стыков из файла Excel
  const [isImportExcelOpen, setIsImportExcelOpen] = useState(false);

  // Автоматическое получение температуры окружающей среды для текущего объекта
  const [siteWeather, setSiteWeather] = useState<{
    tempC: string;
    source: string;
    loading: boolean;
  }>({
    tempC: '-6',
    source: 'Метеопост УКПГ-2В (70.37°N, 68.43°E)',
    loading: false,
  });

  // Все данные по объектам, шифрам РД и названиям линий система изначально берёт из лайнлиста
  const derivedFacilities = useMemo(() => {
    const base = deriveFacilitiesFromLineList(
      projectLineList,
      FACILITY_OBJECTS,
      true
    );
    return base.map((fac) => {
      const over = facilityGeoOverrides[fac.name];
      if (!over) return fac;
      return {
        ...fac,
        region: over.region,
        weatherStation: over.weatherStation || fac.weatherStation,
        latitude: over.latitude,
        longitude: over.longitude,
      };
    });
  }, [projectLineList, facilityGeoOverrides]);

  const currentFacility = useMemo(
    () =>
      derivedFacilities.find((f) => f.name === selectedObjectName) ||
      derivedFacilities[0] ||
      EMPTY_FACILITY_FALLBACK,
    [derivedFacilities, selectedObjectName]
  );

  // Автоматическое сохранение полного состояния программы в localStorage
  useEffect(() => {
    try {
      const stateToPersist: Partial<PersistedAppState> = {
        joints,
        projectLineList,
        lrvCatalog,
        auditLogs,
        welders,
        techCards,
        weldingMaterials,
        userAccounts,
        facilityGeoOverrides,
        selectedObjectName,
        selectedRdCode,
      };
      localStorage.setItem(
        STORAGE_KEYS.FULL_STATE,
        JSON.stringify(stateToPersist)
      );
    } catch {
      // ignore storage quota errors
    }
  }, [
    joints,
    projectLineList,
    lrvCatalog,
    auditLogs,
    welders,
    techCards,
    weldingMaterials,
    userAccounts,
    facilityGeoOverrides,
    selectedObjectName,
    selectedRdCode,
  ]);

  const activeLocationFacility: FacilityObject | null = useMemo(() => {
    if (!locationModalFacilityName) return null;
    return (
      derivedFacilities.find((f) => f.name === locationModalFacilityName) ||
      currentFacility ||
      null
    );
  }, [locationModalFacilityName, derivedFacilities, currentFacility]);

  const handleSaveFacilityLocation = (
    facilityName: string,
    loc: {
      region: string;
      weatherStation: string;
      latitude: number;
      longitude: number;
    }
  ) => {
    recordUndoSnapshot(`Смена метеопункта объекта ${facilityName}`);
    setFacilityGeoOverrides((prev) => ({
      ...prev,
      [facilityName]: {
        region: loc.region,
        weatherStation: loc.weatherStation,
        latitude: loc.latitude,
        longitude: loc.longitude,
      },
    }));

    // Автоматически пересчитываем температуру воздуха для стыков данного объекта по новым координатам
    setJoints((prev) =>
      prev.map((j) => {
        if (j.objectName !== facilityName) return j;
        const est = estimateAmbientTempByCoordsAndDate(
          loc.latitude,
          loc.longitude,
          j.weldingDate
        );
        const formatted = est > 0 ? `+${est}` : `${est}`;
        return { ...j, ambientTemp: formatted };
      })
    );
  };

  const refreshSiteWeather = async () => {
    setSiteWeather((prev) => ({ ...prev, loading: true }));
    const res = await fetchAmbientTemperatureAuto(
      currentFacility.latitude,
      currentFacility.longitude
    );
    setSiteWeather({
      tempC: res.tempC,
      source: res.source,
      loading: false,
    });
  };

  useEffect(() => {
    refreshSiteWeather();
  }, [currentFacility.id]);

  // Сохранение пользовательских шаблонов столбцов
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));
    } catch {
      // ignore
    }
  }, [templates]);

  // Столбцы, активные в текущем представлении и в нужном порядке
  const activeColumnDefs: ColumnDefinition[] = useMemo(() => {
    const visSet = new Set(visibleColumns);
    return columnOrder
      .filter((k) => visSet.has(k))
      .map((k) => ALL_COLUMNS.find((c) => c.key === k))
      .filter((c): c is ColumnDefinition => Boolean(c));
  }, [columnOrder, visibleColumns]);

  // Стыки, отфильтрованные по выбранному в кнопке-бутерброде Объекту и Шифру РД
  const scopedJoints = useMemo(() => {
    return joints.filter((j) => {
      if (selectedObjectName !== 'ALL' && j.objectName !== selectedObjectName) {
        return false;
      }
      if (selectedRdCode !== 'ALL' && j.rdCode !== selectedRdCode) {
        return false;
      }
      return true;
    });
  }, [joints, selectedObjectName, selectedRdCode]);

  // Применение глобального поиска, Excel-фильтров по столбцам и сортировки
  const filteredAndSortedJoints = useMemo(() => {
    const q = globalSearch.trim().toLowerCase();

    const filtered = scopedJoints.filter((joint) => {
      // Проверка Excel-фильтров по каждому столбцу
      for (const [colKey, allowedValues] of Object.entries(columnFilters)) {
        if (!allowedValues) continue;
        const rawVal = String(joint[colKey as WeldJointFieldKey] ?? '');
        if (!allowedValues.includes(rawVal)) {
          return false;
        }
      }

      // Фильтр по диапазону дат сварки
      if (!isWeldingDateInRange(joint.weldingDate, weldingDateFrom, weldingDateTo)) {
        return false;
      }

      // Глобальный текстовый поиск
      if (q) {
        return ALL_COLUMNS.some((col) => {
          const rawStr = String(joint[col.key] ?? '');
          const formattedStr = isDateColumnKey(col.key)
            ? formatDateDDMMYY(rawStr)
            : rawStr;
          return (
            rawStr.toLowerCase().includes(q) ||
            formattedStr.toLowerCase().includes(q)
          );
        });
      }
      return true;
    });

    if (!sortConfig) return filtered;

    const { key, direction } = sortConfig;
    return [...filtered].sort((a, b) => {
      const valA = a[key] ?? '';
      const valB = b[key] ?? '';
      const cmp = String(valA).localeCompare(String(valB), 'ru', { numeric: true });
      return direction === 'asc' ? cmp : -cmp;
    });
  }, [scopedJoints, columnFilters, globalSearch, weldingDateFrom, weldingDateTo, sortConfig]);

  // Уникальные значения для открытого Excel-фильтра столбца
  const getUniqueValuesForColumn = (colKey: WeldJointFieldKey) => {
    const counts = new Map<string, number>();
    for (const j of scopedJoints) {
      const val = String(j[colKey] ?? '');
      counts.set(val, (counts.get(val) || 0) + 1);
    }
    return Array.from(counts.entries())
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => a.value.localeCompare(b.value, 'ru', { numeric: true }));
  };

  // Применение шаблона столбцов
  const handleApplyTemplate = (tpl: ColumnTemplate) => {
    setActiveTemplateId(tpl.id);
    setColumnOrder([...tpl.columnOrder]);
    setVisibleColumns([...tpl.visibleColumns]);
  };

  const handleSaveNewTemplate = (name: string, description: string) => {
    const newTpl: ColumnTemplate = {
      id: `tpl-user-${Date.now()}`,
      name,
      description,
      isSystem: false,
      columnOrder: [...columnOrder],
      visibleColumns: [...visibleColumns],
    };
    setTemplates((prev) => [...prev, newTpl]);
    setActiveTemplateId(newTpl.id);
  };

  const handleDeleteTemplate = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
    if (activeTemplateId === id) {
      handleApplyTemplate(INITIAL_COLUMN_TEMPLATES[0]);
    }
  };

  // Перемещение столбца влево/вправо прямо из шапки таблицы
  const handleMoveColumnInline = (key: WeldJointFieldKey, dir: 'left' | 'right') => {
    const activeKeys = activeColumnDefs.map((c) => c.key);
    const currentVisIdx = activeKeys.indexOf(key);
    if (currentVisIdx === -1) return;
    const neighborVisIdx = dir === 'left' ? currentVisIdx - 1 : currentVisIdx + 1;
    if (neighborVisIdx < 0 || neighborVisIdx >= activeKeys.length) return;

    const neighborKey = activeKeys[neighborVisIdx];
    const nextOrder = [...columnOrder];
    const idxA = nextOrder.indexOf(key);
    const idxB = nextOrder.indexOf(neighborKey);
    if (idxA !== -1 && idxB !== -1) {
      nextOrder[idxA] = neighborKey;
      nextOrder[idxB] = key;
      setColumnOrder(nextOrder);
    }
  };

  const handleHideColumnInline = (key: WeldJointFieldKey) => {
    if (key === 'jointNumber') return;
    setVisibleColumns((prev) => prev.filter((k) => k !== key));
  };

  // Сохранение нового или отредактированного стыка с записью изменений в журнал аудита
  const handleSaveJointFromPassport = (
    savedJoint: WeldJoint,
    isSupplementary: boolean,
    usedCrossRdLrv: boolean
  ) => {
    recordUndoSnapshot(
      `Сохранение паспорта стыка № ${savedJoint.jointNumber}`
    );
    const nowIso = new Date().toISOString();
    const existing = joints.find((j) => j.id === savedJoint.id);

    if (!existing) {
      // Создание нового стыка
      const created: WeldJoint = {
        ...savedJoint,
        isSupplementary,
        updatedAt: nowIso,
        updatedBy: currentUser.fullName,
      };
      setJoints((prev) => [created, ...prev]);

      const newLogs: AuditLogEntry[] = [
        {
          id: `aud-${Date.now()}`,
          timestamp: nowIso,
          userLogin: currentUser.login,
          userFullName: currentUser.fullName,
          userRole: currentUser.role,
          jointId: created.id,
          jointNumber: created.jointNumber,
          uniqueLineId: created.uniqueLineId,
          rdCode: created.rdCode,
          fieldKey: 'jointNumber',
          fieldLabel: isSupplementary
            ? 'Добавлен дополнительный стык'
            : 'Добавлен основной стык',
          oldValue: '—',
          newValue: `Стык № ${created.jointNumber} (${created.uniqueLineId}, Ø${created.diameterMm}×${created.wallThickness})`,
          operationType: 'create_joint',
        },
      ];

      if (usedCrossRdLrv) {
        newLogs.push({
          id: `aud-cross-${Date.now()}`,
          timestamp: nowIso,
          userLogin: currentUser.login,
          userFullName: currentUser.fullName,
          userRole: currentUser.role,
          jointId: created.id,
          jointNumber: created.jointNumber,
          uniqueLineId: created.uniqueLineId,
          rdCode: created.rdCode,
          fieldKey: 'lrv1Code',
          fieldLabel: 'Разблокировка ЛРВ другого шифра РД',
          oldValue: 'Строгий фильтр по РД',
          newValue: `${created.lrv1Code} / ${created.lrv2Code}`,
          operationType: 'cross_rd_lrv',
        });
      }

      setAuditLogs((prev) => [...newLogs, ...prev]);
      return;
    }

    // Редактирование существующего стыка: проверяем каждое поле и пишем в журнал аудита
    const diffLogs: AuditLogEntry[] = [];
    for (const col of ALL_COLUMNS) {
      const k = col.key;
      const oldVal = String(existing[k] ?? '');
      const newVal = String(savedJoint[k] ?? '');
      if (oldVal !== newVal) {
        const displayOld = isDateColumnKey(k) ? formatDateDDMMYY(oldVal) : oldVal;
        const displayNew = isDateColumnKey(k) ? formatDateDDMMYY(newVal) : newVal;
        diffLogs.push({
          id: `aud-${Date.now()}-${k}`,
          timestamp: nowIso,
          userLogin: currentUser.login,
          userFullName: currentUser.fullName,
          userRole: currentUser.role,
          jointId: existing.id,
          jointNumber: savedJoint.jointNumber,
          uniqueLineId: savedJoint.uniqueLineId,
          rdCode: savedJoint.rdCode,
          fieldKey: k,
          fieldLabel: col.label,
          oldValue: displayOld || '—',
          newValue: displayNew || '—',
          operationType: 'single_edit',
        });
      }
    }

    setJoints((prev) =>
      prev.map((j) =>
        j.id === savedJoint.id
          ? { ...savedJoint, updatedAt: nowIso, updatedBy: currentUser.fullName }
          : j
      )
    );

    if (diffLogs.length > 0) {
      setAuditLogs((prev) => [...diffLogs, ...prev]);
    }
  };

  // Удаление стыка (переименование запрещено, разрешено только добавление или удаление)
  const handleDeleteJointFromPassport = (jointToDelete: WeldJoint) => {
    recordUndoSnapshot(`Удаление стыка № ${jointToDelete.jointNumber}`);
    const nowIso = new Date().toISOString();
    setJoints((prev) => prev.filter((j) => j.id !== jointToDelete.id));
    setSelectedJointIds((prev) => prev.filter((id) => id !== jointToDelete.id));

    const deleteLog: AuditLogEntry = {
      id: `aud-del-${Date.now()}`,
      timestamp: nowIso,
      userLogin: currentUser.login,
      userFullName: currentUser.fullName,
      userRole: currentUser.role,
      jointId: jointToDelete.id,
      jointNumber: jointToDelete.jointNumber,
      uniqueLineId: jointToDelete.uniqueLineId,
      rdCode: jointToDelete.rdCode,
      fieldKey: 'jointNumber',
      fieldLabel: 'Удалён сварной стык из реестра',
      oldValue: `Стык № ${jointToDelete.jointNumber} (${jointToDelete.uniqueLineId}, Ø${jointToDelete.diameterMm}×${jointToDelete.wallThickness})`,
      newValue: 'Удалён',
      operationType: 'delete_joint',
    };
    setAuditLogs((prev) => [deleteLog, ...prev]);
  };

  // Импорт массива стыков из Excel с автопривязкой к данным других разделов
  const handleImportJoints = (newJoints: WeldJoint[], sourceFileName: string) => {
    recordUndoSnapshot(`Импорт стыков из Excel (${newJoints.length} шт.)`);
    const nowIso = new Date().toISOString();

    setJoints((prev) => [...newJoints, ...prev]);

    const batchLogs: AuditLogEntry[] = newJoints.map((j, i) => ({
      id: `aud-imp-${Date.now()}-${i}`,
      timestamp: nowIso,
      userLogin: currentUser.login,
      userFullName: currentUser.fullName,
      userRole: currentUser.role,
      jointId: j.id,
      jointNumber: j.jointNumber,
      uniqueLineId: j.uniqueLineId,
      rdCode: j.rdCode,
      fieldKey: 'jointNumber',
      fieldLabel: 'Импорт из Excel',
      oldValue: '—',
      newValue: `Файл «${sourceFileName}»: стык № ${j.jointNumber} (${j.rdCode}, линия ${j.lineNumber}, Ø${j.diameterMm}×${j.wallThickness}, ${j.gostJointType})`,
      operationType: 'batch_upload',
    }));

    setAuditLogs((prev) => [...batchLogs, ...prev]);
  };

  // Быстрое создание дополнительного стыка (011, 012...) на основе выбранного стыка
  const handleQuickAddSupplementaryJoint = (baseJoint?: WeldJoint) => {
    const refJoint = baseJoint || filteredAndSortedJoints[0] || joints[0];
    if (!refJoint) return;

    const lineJointNumbers = joints
      .filter((j) => j.uniqueLineId === refJoint.uniqueLineId)
      .map((j) => j.jointNumber);

    const nextSuppNumber = suggestNextJointNumber(
      lineJointNumbers,
      refJoint.jointNumber
    );

    const draftSupp: WeldJoint = {
      ...refJoint,
      id: `j-supp-${Date.now()}`,
      jointNumber: nextSuppNumber,
      isSupplementary: true,
      weldingDate: new Date().toISOString().slice(0, 10),
      ambientTemp: siteWeather.tempC,
      vikResult: 'В работе',
      ndtResult: 'Не проводился',
      dupNdtResult: 'Не проводился',
    };

    setPassportModal({
      isOpen: true,
      mode: 'create',
      joint: draftSupp,
    });
  };

  // Применение массового редактирования (за исключением номера стыка)
  const handleApplyBulkUpdate = (patch: Partial<WeldJoint>) => {
    recordUndoSnapshot(
      `Массовое редактирование (${selectedJointIds.length} ст.)`
    );
    const { updatedJoints, auditEntries } = applyBulkUpdateToJoints(
      joints,
      selectedJointIds,
      patch,
      currentUser,
      FIELD_LABELS_MAP
    );
    setJoints(updatedJoints);
    if (auditEntries.length > 0) {
      setAuditLogs((prev) => [...auditEntries, ...prev]);
    }
    setSelectedJointIds([]);
  };

  // ============================================================================
  // ФУНКЦИИ УДАЛЕНИЯ ЛЮБОГО ЭЛЕМЕНТА СИСТЕМЫ + БЭКАП + ОБНУЛЕНИЕ (ЧИСТЫЙ ЛИСТ)
  // ============================================================================

  // 1. Удаление пользователя (учётной записи)
  const handleDeleteUserAccount = (loginToDelete: string) => {
    if (userAccounts.length <= 1) return;
    const targetAcc = userAccounts.find((a) => a.login === loginToDelete);
    if (!targetAcc) return;

    const nextAccounts = userAccounts.filter((a) => a.login !== loginToDelete);
    setUserAccounts(nextAccounts);
    if (currentUser.login === loginToDelete && nextAccounts[0]) {
      setCurrentUser(nextAccounts[0]);
    }
    appendSystemAuditEntry(
      'Удаление',
      'Учётные записи пользователей',
      targetAcc.login,
      'Удаление пользователя из системы',
      `${targetAcc.fullName} (${targetAcc.role}, ${targetAcc.department})`,
      'Удалён',
      'sys-auth-del'
    );
  };

  // 2. Удаление объекта строительства (вместе с его линиями, стыками и привязанными позициями ЛРВ)
  const handleDeleteObject = (objectName: string) => {
    recordUndoSnapshot(`Удаление объекта «${objectName}»`);
    const objectRds = new Set(
      projectLineList
        .filter((l) => l.objectName === objectName)
        .map((l) => l.rdCode)
    );
    const removedLinesCount = projectLineList.filter(
      (l) => l.objectName === objectName
    ).length;
    const removedJointsCount = joints.filter(
      (j) => j.objectName === objectName
    ).length;

    const nextLines = projectLineList.filter((l) => l.objectName !== objectName);
    const remainingRds = new Set(nextLines.map((l) => l.rdCode));

    setProjectLineList(nextLines);
    setJoints((prev) => prev.filter((j) => j.objectName !== objectName));
    setLrvCatalog((prev) =>
      prev.filter(
        (item) =>
          item.objectName !== objectName &&
          !(objectRds.has(item.rdCode) && !remainingRds.has(item.rdCode))
      )
    );
    setSelectedJointIds([]);

    if (selectedObjectName === objectName) {
      const nextRemainingObj =
        nextLines[0]?.objectName || 'ALL';
      setSelectedObjectName(nextRemainingObj);
      setSelectedRdCode('ALL');
    }

    appendSystemAuditEntry(
      'Удаление',
      objectName,
      `${removedLinesCount} лин. / ${removedJointsCount} ст.`,
      'Удаление объекта строительства',
      `Объект «${objectName}» (линий: ${removedLinesCount}, стыков: ${removedJointsCount})`,
      'Удалён'
    );
  };

  // 3. Удаление шифра РД (вместе с его линиями, стыками и позициями ЛРВ)
  const handleDeleteRdCode = (rdCode: string, objectName?: string) => {
    recordUndoSnapshot(`Удаление шифра РД «${rdCode}»`);
    const matchesTarget = (l: { rdCode: string; objectName?: string }) =>
      l.rdCode === rdCode && (!objectName || l.objectName === objectName);

    const removedLinesCount = projectLineList.filter(matchesTarget).length;
    const removedJointsCount = joints.filter(matchesTarget).length;

    setProjectLineList((prev) => prev.filter((l) => !matchesTarget(l)));
    setJoints((prev) => prev.filter((j) => !matchesTarget(j)));
    setLrvCatalog((prev) => prev.filter((item) => !matchesTarget(item)));
    setSelectedJointIds([]);

    if (selectedRdCode === rdCode) {
      setSelectedRdCode('ALL');
    }

    appendSystemAuditEntry(
      'Удаление',
      rdCode,
      `${removedLinesCount} лин. / ${removedJointsCount} ст.`,
      'Удаление шифра рабочей документации (РД)',
      `Шифр РД «${rdCode}»${objectName ? ` (${objectName})` : ''}`,
      'Удалён'
    );
  };

  // 4. Удаление линий трубопровода из лайнлиста
  const handleDeleteLineItems = (lineIds: string[]) => {
    if (lineIds.length === 0) return;
    const idSet = new Set(lineIds);
    const linesToDelete = projectLineList.filter((l) => idSet.has(l.id));
    if (linesToDelete.length === 0) return;

    recordUndoSnapshot(`Удаление линий из лайнлиста (${linesToDelete.length} шт.)`);
    const uniqueLineIdsToDelete = new Set(
      linesToDelete.map((l) => l.uniqueLineId)
    );

    setProjectLineList((prev) => prev.filter((l) => !idSet.has(l.id)));
    setJoints((prev) =>
      prev.filter((j) => !uniqueLineIdsToDelete.has(j.uniqueLineId))
    );
    setSelectedJointIds([]);

    appendSystemAuditEntry(
      'Удаление',
      linesToDelete[0]?.uniqueLineId || 'Проект (лайнлист)',
      `${linesToDelete.length} лин.`,
      'Удаление линий из Проекта (лайнлист)',
      linesToDelete
        .map((l) => l.uniqueLineId)
        .slice(0, 6)
        .join(', '),
      'Удалены'
    );
  };

  // 5. Удаление сварщика или бригады из реестра НАКС
  const handleDeleteWelder = (stamp: string) => {
    const target = welders.find((w) => w.stamp === stamp);
    if (!target) return;
    recordUndoSnapshot(`Удаление сварщика / клейма «${stamp}»`);
    setWelders((prev) => prev.filter((w) => w.stamp !== stamp));
    appendSystemAuditEntry(
      'Удаление',
      'Технология сварки (НАКС)',
      stamp,
      'Удаление сварщика / бригадного клейма',
      `${target.stamp} — ${target.fullName} (${target.certNumber})`,
      'Удалён'
    );
  };

  // 6. Удаление технологической карты (ТК)
  const handleDeleteTechCard = (id: string) => {
    const target = techCards.find((tc) => tc.id === id);
    if (!target) return;
    recordUndoSnapshot(`Удаление техкарты «${target.number}»`);
    setTechCards((prev) => prev.filter((tc) => tc.id !== id));
    appendSystemAuditEntry(
      'Удаление',
      'Технология сварки (ТК)',
      target.number,
      'Удаление технологической карты (ТК)',
      `${target.number} — ${target.title}`,
      'Удалена'
    );
  };

  // 7. Удаление сварочного материала (сертификата СМ)
  const handleDeleteWeldingMaterial = (id: string) => {
    const target = weldingMaterials.find((m) => m.id === id);
    if (!target) return;
    recordUndoSnapshot(`Удаление СМ «${target.brandAndDiameter}»`);
    setWeldingMaterials((prev) => prev.filter((m) => m.id !== id));
    appendSystemAuditEntry(
      'Удаление',
      'Технология сварки (СМ)',
      target.certificateNumber,
      'Удаление сертификата сварочных материалов',
      `${target.brandAndDiameter} (партия ${target.batchNumber})`,
      'Удалён'
    );
  };

  // 8. Удаление материала (позиций) в каталоге ЛРВ
  const handleDeleteLrvItems = (ids: string[]) => {
    if (ids.length === 0) return;
    const idSet = new Set(ids);
    const itemsToDelete = lrvCatalog.filter((item) => idSet.has(item.id));
    if (itemsToDelete.length === 0) return;

    recordUndoSnapshot(`Удаление материалов из ЛРВ (${itemsToDelete.length} поз.)`);
    setLrvCatalog((prev) => prev.filter((item) => !idSet.has(item.id)));
    appendSystemAuditEntry(
      'Удаление',
      itemsToDelete[0]?.rdCode || 'Каталог ЛРВ',
      `${itemsToDelete.length} поз.`,
      'Удаление позиций из Каталога ЛРВ',
      itemsToDelete
        .map((i) => `${i.lrvCode} (${i.shortName})`)
        .slice(0, 6)
        .join(', '),
      'Удалены'
    );
  };

  // 9. Массовое удаление выбранных сварных стыков из Реестра
  const handleBulkDeleteSelectedJoints = () => {
    if (selectedJointIds.length === 0) return;
    const idSet = new Set(selectedJointIds);
    const removedJoints = joints.filter((j) => idSet.has(j.id));
    if (removedJoints.length === 0) return;

    recordUndoSnapshot(`Массовое удаление стыков (${removedJoints.length} шт.)`);
    setJoints((prev) => prev.filter((j) => !idSet.has(j.id)));
    setSelectedJointIds([]);
    setConfirmBulkDeleteJoints(false);

    appendSystemAuditEntry(
      'Удаление',
      removedJoints[0]?.uniqueLineId || 'Реестр стыков',
      `${removedJoints.length} ст.`,
      'Массовое удаление сварных стыков',
      removedJoints
        .map((j) => `№${j.jointNumber} (${j.uniqueLineId})`)
        .slice(0, 6)
        .join(', '),
      'Удалены'
    );
  };

  // 10. Восстановление полного функционала и данных из резервной копии (.JSON Бэкап)
  const handleRestoreFullBackup = (payload: FullSystemBackupPayload) => {
    const data = payload.data;
    recordUndoSnapshot('Восстановление базы данных из резервной копии (Бэкап)');
    if (Array.isArray(data.joints)) setJoints(data.joints);
    if (Array.isArray(data.projectLineList))
      setProjectLineList(data.projectLineList);
    if (Array.isArray(data.lrvCatalog)) setLrvCatalog(data.lrvCatalog);
    if (Array.isArray(data.welders)) setWelders(data.welders);
    if (Array.isArray(data.techCards)) setTechCards(data.techCards);
    if (Array.isArray(data.weldingMaterials))
      setWeldingMaterials(data.weldingMaterials);
    if (Array.isArray(data.userAccounts) && data.userAccounts.length > 0) {
      setUserAccounts(data.userAccounts);
      setCurrentUser(data.userAccounts[0]);
    }
    if (
      data.facilityGeoOverrides &&
      typeof data.facilityGeoOverrides === 'object'
    ) {
      setFacilityGeoOverrides(data.facilityGeoOverrides);
    }
    if (Array.isArray(data.templates) && data.templates.length > 0) {
      setTemplates(data.templates);
      const matchedTpl =
        data.templates.find((t) => t.id === data.activeTemplateId) ||
        data.templates[0];
      if (matchedTpl) {
        setActiveTemplateId(matchedTpl.id);
        setColumnOrder([...matchedTpl.columnOrder]);
        setVisibleColumns([...matchedTpl.visibleColumns]);
      }
    } else if (typeof data.activeTemplateId === 'string') {
      setActiveTemplateId(data.activeTemplateId);
    }
    setSelectedObjectName('ALL');
    setSelectedRdCode('ALL');
    setSelectedJointIds([]);
    setColumnFilters({});

    const restoreAuditEntry: AuditLogEntry = {
      id: `aud-restore-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userLogin: currentUser.login,
      userFullName: currentUser.fullName,
      userRole: currentUser.role,
      jointId: 'sys-backup-restore',
      jointNumber: `${data.joints?.length ?? 0} ст.`,
      uniqueLineId: 'СИСТЕМА (БЭКАП)',
      rdCode: 'ВОССТАНОВЛЕНИЕ',
      fieldKey: 'system',
      fieldLabel: 'Восстановление полного состояния из Бэкапа (.JSON)',
      oldValue: 'Предыдущее состояние',
      newValue: `Стыков: ${data.joints?.length ?? 0}, Линий: ${
        data.projectLineList?.length ?? 0
      }, ЛРВ: ${data.lrvCatalog?.length ?? 0}, НАКС: ${
        data.welders?.length ?? 0
      }, ТК: ${data.techCards?.length ?? 0}`,
      operationType: 'batch_upload',
    };
    const baseLogs = Array.isArray(data.auditLogs) ? data.auditLogs : [];
    setAuditLogs([restoreAuditEntry, ...baseLogs]);
  };

  // 11. Скрытое авторское обнуление программы («Чистый лист»)
  const handleAuthorZeroReset = (keepAdminUser: boolean) => {
    const cleanAdminAccount: UserAccount = {
      login: 'admin_pto',
      password: '123',
      fullName: 'Администратор системы (ПТО)',
      role: 'Инженер ПТО',
      department: 'ПТО (Чистый лист)',
      sessionNumber: 1,
    };
    const nextUsers = keepAdminUser
      ? [cleanAdminAccount]
      : [USER_ACCOUNTS[0] || cleanAdminAccount];

    setJoints([]);
    setProjectLineList([]);
    setLrvCatalog([]);
    setWelders([]);
    setTechCards([]);
    setWeldingMaterials([]);
    setAuditLogs([]);
    setFacilityGeoOverrides({});
    setUserAccounts(nextUsers);
    setCurrentUser(nextUsers[0]);
    setUndoStack([]);
    setRedoStack([]);
    setSelectedJointIds([]);
    setColumnFilters({});
    setGlobalSearch('');
    setWeldingDateFrom('');
    setWeldingDateTo('');
    setSelectedObjectName('ALL');
    setSelectedRdCode('ALL');
  };

  // 12. Авторский возврат демонстрационной базы по умолчанию
  const handleAuthorRestoreDemoSeed = () => {
    setJoints(INITIAL_JOINTS);
    setProjectLineList(INITIAL_PROJECT_LINELIST);
    setLrvCatalog(INITIAL_LRV_CATALOG);
    setWelders(WELDERS_DIRECTORY);
    setTechCards(INITIAL_TECH_CARDS);
    setWeldingMaterials(INITIAL_WELDING_MATERIALS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setFacilityGeoOverrides({});
    setUserAccounts(USER_ACCOUNTS);
    setCurrentUser(USER_ACCOUNTS[0]);
    setUndoStack([]);
    setRedoStack([]);
    setSelectedJointIds([]);
    setColumnFilters({});
    setSelectedObjectName(FACILITY_OBJECTS[0].name);
    setSelectedRdCode('ALL');
  };

  const toggleSelectAllVisible = () => {
    const visibleIds = filteredAndSortedJoints.map((j) => j.id);
    const allSelected =
      visibleIds.length > 0 &&
      visibleIds.every((id) => selectedJointIds.includes(id));

    if (allSelected) {
      setSelectedJointIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      setSelectedJointIds(Array.from(new Set([...selectedJointIds, ...visibleIds])));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedJointIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const activeFilterKeys = Object.keys(columnFilters).filter(
    (k) => columnFilters[k as WeldJointFieldKey] !== undefined
  ) as WeldJointFieldKey[];

  const sectionLabels: Record<AppSection, string> = {
    registry: 'Реестр стыков и ввод данных',
    project_linelist: 'Проект (лайнлист)',
    welding_tech: 'Технология сварочного производства',
    journals: 'Журналы сварочных работ (СТО Газпром / ГОСТ)',
    readiness: 'Отчётность по готовности',
    lrv_catalog: 'Каталог ЛРВ и спецификации',
    audit_log: 'Журнал изменений (Аудит)',
    user_guide: 'Руководство пользователя (Иллюстрированный буклет PDF)',
  };

  const renderStatusText = (val: string) => {
    if (val === 'Годен') {
      return <span className="font-semibold text-emerald-700">Годен</span>;
    }
    if (val === 'Ремонт' || val === 'Вырезать') {
      return <span className="font-bold text-red-700">{val}</span>;
    }
    if (val === 'В работе') {
      return <span className="font-medium text-amber-700">В работе</span>;
    }
    return <span className="text-slate-400">{val || '—'}</span>;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f4f7fb] text-slate-900">
      {/* ЧЕРДАК ИНТЕРФЕЙСА СТРОГО ЦВЕТА #1e3799 */}
      <header className="sticky top-0 z-30 bg-[#1e3799] text-white border-b border-sky-400/20 shadow-md no-print">
        <div className="max-w-[1920px] mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
          {/* Левый верхний угол: Логотип и название (5 кликов открывают скрытую Консоль Автора) */}
          <div
            onClick={handleHeaderLogoSecretClick}
            className="flex items-center min-w-0 shrink-0 cursor-pointer select-none"
            title="ZAYCHICK — Цифровая система учёта сварки и НК"
          >
            <ZaychickLogo variant="header" size={38} />
          </div>

          {/* Середина чердака: Название текущего раздела */}
          <div className="flex items-center justify-center flex-1 min-w-0 px-2 text-center">
            <h1 className="font-display text-sm sm:text-base font-bold text-white tracking-tight truncate">
              {sectionLabels[activeSection]}
            </h1>
          </div>

          {/* Правый верхний угол: Undo / Redo (на 10 действий), Бэкап и Кнопка-бутерброд */}
          <div className="flex items-center gap-2 shrink-0">
            <div
              className="flex items-center gap-1 bg-white/10 border border-sky-300/30 rounded-lg p-1"
              role="group"
              aria-label="Отмена и повтор действий (до 10 шагов)"
            >
              <button
                type="button"
                onClick={handleUndo}
                disabled={undoStack.length === 0}
                aria-label="Отменить действие (Undo)"
                title={
                  undoStack.length > 0
                    ? `Отменить (${undoStack.length}/${MAX_HISTORY_STEPS}): ${
                        undoStack[undoStack.length - 1]?.actionLabel || ''
                      } (Ctrl+Z)`
                    : 'Нет действий для отмены (до 10 шагов)'
                }
                className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold text-white hover:bg-white/20 disabled:opacity-40 disabled:hover:bg-transparent transition-colors"
              >
                <Undo2 className="w-3.5 h-3.5 text-sky-200" />
                <span className="hidden md:inline">Отменить</span>
                <span className="font-mono text-[10px] px-1 py-0.2 rounded bg-white/15 text-sky-100">
                  {undoStack.length}/{MAX_HISTORY_STEPS}
                </span>
              </button>

              <button
                type="button"
                onClick={handleRedo}
                disabled={redoStack.length === 0}
                aria-label="Повторить действие (Redo)"
                title={
                  redoStack.length > 0
                    ? `Повторить (${redoStack.length}/${MAX_HISTORY_STEPS}): ${
                        redoStack[redoStack.length - 1]?.actionLabel || ''
                      } (Ctrl+Y)`
                    : 'Нет действий для повтора (до 10 шагов)'
                }
                className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold text-white hover:bg-white/20 disabled:opacity-40 disabled:hover:bg-transparent transition-colors"
              >
                <Redo2 className="w-3.5 h-3.5 text-sky-200" />
                <span className="hidden md:inline">Повторить</span>
                <span className="font-mono text-[10px] px-1 py-0.2 rounded bg-white/15 text-sky-100">
                  {redoStack.length}/{MAX_HISTORY_STEPS}
                </span>
              </button>
            </div>

            <button
              type="button"
              onClick={() =>
                setBackupModalState({ isOpen: true, initialTab: 'backup' })
              }
              title="Создать резервную копию (Бэкап .JSON) или восстановить данные"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-sky-300/30 text-white text-xs font-semibold transition-colors shrink-0"
            >
              <HardDriveDownload className="w-4 h-4 text-sky-300" />
              <span className="hidden lg:inline">Бэкап</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSection('user_guide')}
              title="Открыть буклет-руководство пользователя (PDF / Печать А4)"
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors shrink-0 ${
                activeSection === 'user_guide'
                  ? 'bg-white text-[#1e3799] border-white shadow-xs'
                  : 'bg-white/10 hover:bg-white/20 border-sky-300/30 text-white'
              }`}
            >
              <BookOpen className="w-4 h-4 text-sky-300" />
              <span className="hidden lg:inline">Инструкция (PDF)</span>
            </button>

            <button
              type="button"
              onClick={() => setIsDrawerOpen(true)}
              aria-label="Открыть меню выбора объекта и раздела программы"
              className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-sky-300/30 text-white text-xs font-semibold transition-colors shrink-0"
            >
              <Menu className="w-5 h-5 text-sky-300" />
              <span className="hidden sm:inline">Меню</span>
            </button>
          </div>
        </div>
      </header>

      {/* Боковое меню в кнопке-бутерброде */}
      <HamburgerDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        facilities={derivedFacilities}
        selectedObjectName={selectedObjectName}
        onSelectObjectName={setSelectedObjectName}
        selectedRdCode={selectedRdCode}
        onSelectRdCode={setSelectedRdCode}
        totalJointsCount={joints.length}
        projectLineListCount={projectLineList.length}
        auditLogsCount={auditLogs.length}
        lrvCatalogCount={lrvCatalog.length}
        weldingTechCount={`${welders.length} НАКС / ${techCards.length} ТК`}
        currentUser={currentUser}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onExportAllJoints={(fmt) => exportAllJointsToFile(joints, fmt)}
        onOpenFacilityLocation={(objName) => setLocationModalFacilityName(objName)}
        onOpenBackupModal={() =>
          setBackupModalState({ isOpen: true, initialTab: 'backup' })
        }
        onOpenAuthorResetModal={() =>
          setBackupModalState({ isOpen: true, initialTab: 'author_reset' })
        }
        onDeleteObject={handleDeleteObject}
        onDeleteRdCode={handleDeleteRdCode}
      />

      {/* ОСНОВНАЯ РАБОЧАЯ ОБЛАСТЬ */}
      <main className="flex-1 max-w-[1920px] w-full mx-auto p-3 sm:p-4 space-y-3">

        {/* РАЗДЕЛ 1: РЕЕСТР СТЫКОВ И ТАБЛИЦА ВНЕСЕНИЯ ДАННЫХ */}
        {activeSection === 'registry' && (
          <div className="space-y-3">
            {/* Верхняя полоса из двух блоков: 1) Диапазон дат сварки и действия; 2) Отдельный компактный блок справа (шаблон и иконка столбцов) */}
            <div className="flex flex-wrap xl:flex-nowrap items-center gap-2.5">
              {/* Блок 1: Диапазон дат сварки и основные действия */}
              <div className="bg-white rounded-xl border border-slate-200 px-3 py-2.5 flex flex-wrap xl:flex-nowrap items-center justify-between gap-2.5 shadow-2xs flex-1 min-w-0">
                <div className="flex flex-wrap md:flex-nowrap items-center gap-2 flex-1 min-w-0">
                  {/* Поле диапазона дат сварки, фильтрующее таблицу */}
                  <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#f4f8fe] border border-sky-200 rounded-lg text-xs whitespace-nowrap shrink-0">
                    <Calendar className="w-3.5 h-3.5 text-[#1e3799] shrink-0" />
                    <span className="font-semibold text-[#1e3799]">
                      Дата сварки:
                    </span>
                    <label className="flex items-center gap-1 text-slate-600">
                      <span>с</span>
                      <input
                        type="date"
                        value={weldingDateFrom}
                        onChange={(e) => setWeldingDateFrom(e.target.value)}
                        aria-label="Дата сварки с"
                        className="px-1.5 py-0.5 bg-white border border-slate-300 rounded text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#1e3799]"
                      />
                    </label>
                    <label className="flex items-center gap-1 text-slate-600">
                      <span>по</span>
                      <input
                        type="date"
                        value={weldingDateTo}
                        onChange={(e) => setWeldingDateTo(e.target.value)}
                        aria-label="Дата сварки по"
                        className="px-1.5 py-0.5 bg-white border border-slate-300 rounded text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#1e3799]"
                      />
                    </label>
                    {(weldingDateFrom || weldingDateTo) && (
                      <button
                        type="button"
                        onClick={() => {
                          setWeldingDateFrom('');
                          setWeldingDateTo('');
                        }}
                        title="Сбросить диапазон дат сварки"
                        aria-label="Сбросить диапазон дат сварки"
                        className="ml-0.5 px-1.5 py-0.5 rounded bg-sky-100 text-[#1e3799] hover:bg-red-100 hover:text-red-700 font-bold text-[11px] transition-colors"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                </div>

                {/* Кнопки действий: Массовое удаление, Массовое редактирование, Доп. стык (011), Новый стык */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {selectedJointIds.length > 0 &&
                    (confirmBulkDeleteJoints ? (
                      <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-red-300 bg-red-50 text-xs">
                        <span className="font-bold text-red-800">
                          Удалить {selectedJointIds.length} ст.?
                        </span>
                        <button
                          type="button"
                          onClick={handleBulkDeleteSelectedJoints}
                          className="px-2 py-0.5 rounded bg-red-600 text-white font-bold hover:bg-red-700"
                        >
                          Да
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmBulkDeleteJoints(false)}
                          className="px-2 py-0.5 rounded bg-white border border-slate-300 text-slate-700"
                        >
                          Отмена
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmBulkDeleteJoints(true)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-red-300 bg-red-50 text-red-700 hover:bg-red-100 text-xs font-semibold transition-colors whitespace-nowrap"
                        title="Удалить выделенные сварные стыки"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Удалить ({selectedJointIds.length})</span>
                      </button>
                    ))}

                  <button
                    type="button"
                    onClick={() => {
                      if (selectedJointIds.length === 0) {
                        const ids = filteredAndSortedJoints.map((j) => j.id);
                        setSelectedJointIds(ids);
                      }
                      setIsBulkEditOpen(true);
                    }}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap border ${
                      selectedJointIds.length > 0
                        ? 'bg-[#e8f1fc] border-[#1e3799] text-[#1e3799] hover:bg-sky-100'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5 text-[#1e3799]" />
                    <span>
                      Массовое ред.
                      {selectedJointIds.length > 0
                        ? ` (${selectedJointIds.length})`
                        : ''}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAddSupplementaryJoint()}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#1e3799]/30 bg-[#f0f5fc] text-[#1e3799] hover:bg-sky-100 text-xs font-semibold transition-colors whitespace-nowrap"
                    title="Добавить дополнительный стык с нумерацией 011, 012..."
                  >
                    <FilePlus2 className="w-3.5 h-3.5" />
                    <span>Доп. стык</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsImportExcelOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-600/50 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-xs font-semibold transition-colors whitespace-nowrap shadow-2xs"
                    title="Загрузка стыков из файла Excel (.xlsx, .xls) с автоматической привязкой"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Загрузить из Excel</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setPassportModal({
                        isOpen: true,
                        mode: 'create',
                        joint: null,
                      })
                    }
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#1e3799] text-white hover:bg-[#15276e] text-xs font-semibold shadow-xs transition-colors whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Добавить стык</span>
                  </button>
                </div>
              </div>

              {/* Блок 2: Отдельный компактный блок справа (выбор шаблона таблицы и иконочная кнопка "Столбцы" с подсказкой по наведению) */}
              <div className="bg-white rounded-xl border border-slate-200 px-3 py-2.5 flex items-center gap-2 shadow-2xs shrink-0">
                <Bookmark className="w-4 h-4 text-[#1e3799] shrink-0" />
                <select
                  value={activeTemplateId}
                  onChange={(e) => {
                    const found = templates.find((t) => t.id === e.target.value);
                    if (found) handleApplyTemplate(found);
                  }}
                  aria-label="Шаблон отображения столбцов"
                  className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1e3799]"
                >
                  {templates.map((t) => (
                    <option key={t.id} value={t.id}>
                      Шаблон: {t.name}
                    </option>
                  ))}
                </select>

                <div className="relative group">
                  <button
                    type="button"
                    onClick={() => setIsColumnsModalOpen(true)}
                    aria-label={`Настройка столбцов (${visibleColumns.length} из ${ALL_COLUMNS.length})`}
                    title={`Настройка столбцов (${visibleColumns.length} из ${ALL_COLUMNS.length})`}
                    className="p-1.5 rounded-lg border border-slate-300 bg-white hover:bg-[#f0f5fc] hover:border-[#1e3799] text-[#1e3799] transition-colors flex items-center justify-center"
                  >
                    <Columns className="w-4 h-4" />
                  </button>
                  <div
                    role="tooltip"
                    className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute right-0 top-full mt-1.5 z-40 px-2.5 py-1 rounded bg-slate-900 text-white text-[11px] font-medium whitespace-nowrap shadow-lg"
                  >
                    Настройка столбцов ({visibleColumns.length}/{ALL_COLUMNS.length})
                  </div>
                </div>
              </div>
            </div>

            {/* Индикатор активных Excel-фильтров, диапазона дат или выделенных строк */}
            {(activeFilterKeys.length > 0 ||
              Boolean(weldingDateFrom || weldingDateTo) ||
              selectedJointIds.length > 0) && (
              <div className="bg-[#e8f1fc] rounded-xl border border-sky-200 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  {selectedJointIds.length > 0 && (
                    <span className="font-bold text-[#1e3799]">
                      Выделено стыков: {selectedJointIds.length} шт. (номер стыка защищён от массовой замены)
                    </span>
                  )}
                  {(weldingDateFrom || weldingDateTo) && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white border border-sky-300 text-[#1e3799] font-medium">
                      <Calendar className="w-3 h-3" />
                      <span>
                        Дата сварки:{' '}
                        {weldingDateFrom ? `с ${formatDateDDMMYY(weldingDateFrom)}` : ''}{' '}
                        {weldingDateTo ? `по ${formatDateDDMMYY(weldingDateTo)}` : ''}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setWeldingDateFrom('');
                          setWeldingDateTo('');
                        }}
                        className="text-slate-400 hover:text-red-600 font-bold"
                      >
                        ✕
                      </button>
                    </span>
                  )}
                  {activeFilterKeys.map((k) => (
                    <span
                      key={k}
                      className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white border border-sky-300 text-[#1e3799] font-medium"
                    >
                      <Filter className="w-3 h-3" />
                      <span>
                        {FIELD_LABELS_MAP[k]}: {columnFilters[k]?.length} знач.
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                           setColumnFilters((prev) => ({ ...prev, [k]: undefined }))
                        }
                        className="text-slate-400 hover:text-red-600 font-bold"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  {selectedJointIds.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedJointIds([])}
                      className="text-slate-600 hover:text-slate-900 underline font-medium"
                    >
                      Снять выделение
                    </button>
                  )}
                  {(activeFilterKeys.length > 0 || weldingDateFrom || weldingDateTo) && (
                    <button
                      type="button"
                      onClick={() => {
                        setColumnFilters({});
                        setWeldingDateFrom('');
                        setWeldingDateTo('');
                      }}
                      className="inline-flex items-center gap-1 text-[#1e3799] hover:underline font-semibold"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Сбросить все фильтры</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* ОСНОВНАЯ ТАБЛИЦА СВАРНЫХ СТЫКОВ С ШАПКОЙ #1e3799 И EXCEL-ФИЛЬТРАМИ */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto min-h-[460px]">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    {/* Строка заголовков столбцов строго цвета #1e3799 */}
                    <tr className="bg-[#1e3799] text-white select-none">
                      {/* Чекбокс массового выбора */}
                      <th className="py-3 px-2.5 border-r border-white/15 w-9 text-center sticky left-0 z-20 bg-[#1e3799]">
                        <input
                          type="checkbox"
                          aria-label="Выбрать все стыки в таблице"
                          checked={
                            filteredAndSortedJoints.length > 0 &&
                            filteredAndSortedJoints.every((j) =>
                              selectedJointIds.includes(j.id)
                            )
                          }
                          onChange={toggleSelectAllVisible}
                          className="rounded border-white/40 text-sky-400 focus:ring-sky-300 cursor-pointer"
                        />
                      </th>

                      {activeColumnDefs.map((col) => {
                        const isFiltered = columnFilters[col.key] !== undefined;
                        const isSorted = sortConfig?.key === col.key;
                        const isFilterOpen = openFilterColumnKey === col.key;

                        return (
                          <th
                            key={col.key}
                            style={{ minWidth: col.minWidth }}
                            className={`relative py-2.5 px-2.5 border-r border-white/15 text-left font-semibold align-middle transition-colors ${
                              isFiltered || isFilterOpen
                                ? 'bg-[#15276e]'
                                : 'bg-[#1e3799] hover:bg-[#192f85]'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  setSortConfig((prev) =>
                                    prev?.key === col.key && prev.direction === 'asc'
                                      ? { key: col.key, direction: 'desc' }
                                      : { key: col.key, direction: 'asc' }
                                  )
                                }
                                className="text-left font-semibold text-white hover:text-sky-200 truncate flex items-center gap-1"
                                title={`Сортировать по столбцу «${col.label}»`}
                              >
                                <span>{col.shortLabel || col.label}</span>
                                {isSorted &&
                                  (sortConfig.direction === 'asc' ? (
                                    <ArrowUp className="w-3 h-3 text-sky-300 shrink-0" />
                                  ) : (
                                    <ArrowDown className="w-3 h-3 text-sky-300 shrink-0" />
                                  ))}
                              </button>

                              {/* Кнопка Excel-фильтра с автоматическим перехватом курсора */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenFilterColumnKey((prev) =>
                                    prev === col.key ? null : col.key
                                  );
                                }}
                                aria-label={`Фильтр Excel для столбца ${col.label}`}
                                title="Фильтр как в Excel (автофокус курсора)"
                                className={`p-1 rounded transition-colors shrink-0 ${
                                  isFiltered
                                    ? 'bg-sky-400 text-[#1e3799] font-bold'
                                    : 'text-sky-200 hover:bg-white/15 hover:text-white'
                                }`}
                              >
                                <Filter className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Выпадающее окно фильтра как в Excel */}
                            {isFilterOpen && (
                              <ExcelColumnFilter
                                column={col}
                                uniqueValues={getUniqueValuesForColumn(col.key)}
                                selectedValues={columnFilters[col.key]}
                                onApplyFilter={(k, vals) =>
                                  setColumnFilters((prev) => ({ ...prev, [k]: vals }))
                                }
                                sortConfig={sortConfig}
                                onSort={(k, dir) => setSortConfig({ key: k, direction: dir })}
                                onMoveColumn={handleMoveColumnInline}
                                onHideColumn={handleHideColumnInline}
                                onClose={() => setOpenFilterColumnKey(null)}
                              />
                            )}
                          </th>
                        );
                      })}
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-200">
                    {filteredAndSortedJoints.length === 0 ? (
                      <tr>
                        <td
                          colSpan={activeColumnDefs.length + 1}
                          className="py-12 px-4 text-center text-slate-500"
                        >
                          <div className="max-w-md mx-auto space-y-2">
                            <div className="font-semibold text-slate-800 text-sm">
                              По заданным условиям фильтрации стыков не найдено
                            </div>
                            <p className="text-xs text-slate-500">
                              Сбросьте активные фильтры столбцов или добавьте новый сварной стык в базу.
                            </p>
                            <button
                              type="button"
                              onClick={() => {
                                setColumnFilters({});
                                setGlobalSearch('');
                                setWeldingDateFrom('');
                                setWeldingDateTo('');
                              }}
                              className="px-3.5 py-1.5 rounded-lg bg-[#1e3799] text-white text-xs font-semibold"
                            >
                              Сбросить фильтры
                            </button>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      filteredAndSortedJoints.map((joint) => {
                        const isSelected = selectedJointIds.includes(joint.id);
                        const numVal = parseInt(joint.jointNumber, 10);
                        const isSupp =
                          joint.isSupplementary ||
                          (!Number.isNaN(numVal) && numVal % 10 !== 0);

                        return (
                          <tr
                            key={joint.id}
                            onDoubleClick={() =>
                              setPassportModal({
                                isOpen: true,
                                mode: 'edit',
                                joint,
                              })
                            }
                            className={`transition-colors ${
                              isSelected
                                ? 'bg-[#e8f1fc]'
                                : 'odd:bg-white even:bg-[#f8fafd] hover:bg-sky-50/70'
                            }`}
                          >
                            {/* Чекбокс выбора строки */}
                            <td className="py-2 px-2.5 border-r border-slate-200 text-center sticky left-0 z-10 bg-inherit">
                              <input
                                type="checkbox"
                                aria-label={`Выбрать стык ${joint.jointNumber} линии ${joint.uniqueLineId}`}
                                checked={isSelected}
                                onChange={() => toggleSelectRow(joint.id)}
                                className="rounded border-slate-300 text-[#1e3799] focus:ring-[#1e3799] cursor-pointer"
                              />
                            </td>

                            {/* Ячейки данных по активному шаблону столбцов */}
                            {activeColumnDefs.map((col) => {
                              const raw = joint[col.key];
                              const strVal = String(raw ?? '');

                              if (col.key === 'jointNumber') {
                                return (
                                  <td
                                    key={col.key}
                                    className="py-2 px-2.5 border-r border-slate-200 font-mono font-bold text-slate-900 whitespace-nowrap"
                                  >
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setPassportModal({
                                          isOpen: true,
                                          mode: 'edit',
                                          joint,
                                        })
                                      }
                                      aria-label={`Открыть паспорт стыка ${joint.jointNumber}`}
                                      title="Нажмите на номер стыка, чтобы открыть паспорт стыка"
                                      className="inline-flex items-center font-mono font-bold text-[#1e3799] hover:text-[#15276e] underline decoration-[#1e3799]/40 hover:decoration-[#1e3799] underline-offset-2 transition-colors cursor-pointer"
                                    >
                                      <span>{joint.jointNumber}</span>
                                      {isSupp && (
                                        <span
                                          className="ml-1.5 text-[10px] font-normal text-[#1e3799]"
                                          title="Дополнительный стык"
                                        >
                                          (доп.)
                                        </span>
                                      )}
                                    </button>
                                  </td>
                                );
                              }

                              if (col.key === 'uniqueLineId') {
                                return (
                                  <td
                                    key={col.key}
                                    className="py-2 px-2.5 border-r border-slate-200 font-mono font-semibold text-[#1e3799] whitespace-nowrap"
                                  >
                                    {joint.uniqueLineId}
                                  </td>
                                );
                              }

                              if (col.key === 'lrv1Code' || col.key === 'lrv2Code') {
                                return (
                                  <td
                                    key={col.key}
                                    className="py-2 px-2.5 border-r border-slate-200 font-mono text-slate-800 whitespace-nowrap"
                                  >
                                    {strVal || '—'}
                                  </td>
                                );
                              }

                              if (
                                col.key === 'vikResult' ||
                                col.key === 'ndtResult' ||
                                col.key === 'dupNdtResult'
                              ) {
                                return (
                                  <td
                                    key={col.key}
                                    className="py-2 px-2.5 border-r border-slate-200 whitespace-nowrap"
                                  >
                                    {renderStatusText(strVal)}
                                  </td>
                                );
                              }

                              if (isDateColumnKey(col.key)) {
                                return (
                                  <td
                                    key={col.key}
                                    className="py-2 px-2.5 border-r border-slate-200 font-mono text-slate-700 whitespace-nowrap"
                                  >
                                    {strVal ? (
                                      formatDateDDMMYY(strVal)
                                    ) : (
                                      <span className="text-slate-300">—</span>
                                    )}
                                  </td>
                                );
                              }

                              return (
                                <td
                                  key={col.key}
                                  className={`py-2 px-2.5 border-r border-slate-200 whitespace-nowrap ${
                                    col.isNumeric ? 'font-mono text-right' : 'text-slate-700'
                                  }`}
                                >
                                  {strVal || <span className="text-slate-300">—</span>}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Подвал таблицы со статистикой и подсказками */}
              <div className="px-4 py-2.5 bg-[#f8fafd] border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <div>
                  Отображено стыков:{' '}
                  <span className="font-mono font-bold text-slate-800">
                    {filteredAndSortedJoints.length}
                  </span>{' '}
                  из <span className="font-mono">{joints.length}</span> · Активный шаблон:{' '}
                  <span className="font-semibold text-[#1e3799]">
                    {templates.find((t) => t.id === activeTemplateId)?.name || 'Пользовательский'}
                  </span>
                </div>
                <div>
                  Нажатие на номер стыка открывает Паспорт стыка · Все изменения записываются в Аудит
                </div>
              </div>
            </div>
          </div>
        )}

        {/* РАЗДЕЛ 1А: ПРОЕКТ (ЛАЙНЛИСТ) */}
        {activeSection === 'project_linelist' && (
          <ProjectLineListView
            lineList={projectLineList}
            joints={joints}
            facilities={derivedFacilities}
            selectedObjectName={selectedObjectName}
            selectedRdCode={selectedRdCode}
            onAddLineItems={(newItems) => {
              recordUndoSnapshot(`Добавление линий в лайнлист (${newItems.length} шт.)`);
              setProjectLineList((prev) => [...newItems, ...prev]);
              appendSystemAuditEntry(
                'Создание стыка',
                newItems[0]?.uniqueLineId || 'Проект (лайнлист)',
                `${newItems.length} лин.`,
                'Добавление линий в Проект (лайнлист)',
                '—',
                newItems.map((i) => i.uniqueLineId).slice(0, 5).join(', ')
              );
            }}
            onUpdateLineItem={(updated, previousItem, cascadeRename = true) => {
              recordUndoSnapshot(`Редактирование линии ${updated.lineNumber}`);
              appendSystemAuditEntry(
                'Редактирование',
                updated.uniqueLineId,
                updated.lineNumber,
                'Редактирование линии в Проекте (лайнлист)',
                previousItem ? `${previousItem.rdCode} / ${previousItem.lineNumber}` : '—',
                `${updated.rdCode} / ${updated.lineNumber}`
              );
              const objChanged =
                previousItem && previousItem.objectName !== updated.objectName;
              const rdChanged =
                previousItem && previousItem.rdCode !== updated.rdCode;
              const contourChanged =
                previousItem && previousItem.testContour !== updated.testContour;

              const nextLineList = projectLineList.map((it) => {
                if (it.id === updated.id) return updated;
                if (!cascadeRename || !previousItem) return it;

                const nextObj =
                  objChanged && it.objectName === previousItem.objectName
                    ? updated.objectName
                    : it.objectName;
                const nextRd =
                  rdChanged && it.rdCode === previousItem.rdCode
                    ? updated.rdCode
                    : it.rdCode;
                const nextContour =
                  contourChanged &&
                  it.testContour === previousItem.testContour &&
                  (it.rdCode === previousItem.rdCode || nextRd === updated.rdCode)
                    ? updated.testContour
                    : it.testContour;

                if (
                  nextObj === it.objectName &&
                  nextRd === it.rdCode &&
                  nextContour === it.testContour
                ) {
                  return it;
                }

                return {
                  ...it,
                  objectName: nextObj,
                  rdCode: nextRd,
                  testContour: nextContour,
                  uniqueLineId: buildUniqueLineId(nextRd, it.lineNumber),
                };
              });

              setProjectLineList(nextLineList);

              if (previousItem) {
                const prevLinesByUniqueId = new Map(
                  projectLineList.map((l) => [l.uniqueLineId, l])
                );
                const nextLinesById = new Map(
                  nextLineList.map((l) => [l.id, l])
                );

                setJoints((prevJoints) =>
                  prevJoints.map((j) => {
                    const matchedOldLine =
                      prevLinesByUniqueId.get(j.uniqueLineId) ||
                      projectLineList.find(
                        (l) =>
                          l.rdCode === j.rdCode && l.lineNumber === j.lineNumber
                      );
                    if (matchedOldLine) {
                      const nextLine = nextLinesById.get(matchedOldLine.id);
                      if (nextLine) {
                        return {
                          ...j,
                          objectName: nextLine.objectName,
                          rdCode: nextLine.rdCode,
                          lineNumber: nextLine.lineNumber,
                          uniqueLineId: nextLine.uniqueLineId,
                          contour: nextLine.testContour,
                        };
                      }
                    }
                    return j;
                  })
                );

                if (cascadeRename && rdChanged) {
                  setLrvCatalog((prevCatalog) =>
                    prevCatalog.map((item) =>
                      item.rdCode === previousItem.rdCode
                        ? { ...item, rdCode: updated.rdCode }
                        : item
                    )
                  );
                  if (selectedRdCode === previousItem.rdCode) {
                    setSelectedRdCode(updated.rdCode);
                  }
                }
                if (cascadeRename && objChanged && selectedObjectName === previousItem.objectName) {
                  setSelectedObjectName(updated.objectName);
                }
              }
            }}
            onBulkUpdateLineItems={(selectedIds, patch) => {
              recordUndoSnapshot(
                `Групповое ред. лайнлиста (${selectedIds.length} стр.)`
              );
              const selectedOldLines = projectLineList.filter((l) =>
                selectedIds.includes(l.id)
              );
              const prevLinesMap = new Map(
                selectedOldLines.map((l) => [l.uniqueLineId, l])
              );
              const nextLineList = applyBulkUpdateToLineList(
                projectLineList,
                selectedIds,
                patch
              );
              setProjectLineList(nextLineList);

              if (
                patch.objectName !== undefined ||
                patch.rdCode !== undefined ||
                patch.testContour !== undefined
              ) {
                setJoints((prevJoints) =>
                  prevJoints.map((j) => {
                    const oldLine =
                      prevLinesMap.get(j.uniqueLineId) ||
                      selectedOldLines.find(
                        (l) =>
                          l.rdCode === j.rdCode && l.lineNumber === j.lineNumber
                      );
                    if (!oldLine) return j;
                    const updatedLine = nextLineList.find((l) => l.id === oldLine.id);
                    if (!updatedLine) return j;
                    return {
                      ...j,
                      objectName: updatedLine.objectName,
                      rdCode: updatedLine.rdCode,
                      uniqueLineId: updatedLine.uniqueLineId,
                      contour: updatedLine.testContour,
                    };
                  })
                );
              }

              if (patch.rdCode) {
                const newRd = patch.rdCode;
                const oldRdsReplaced = new Set(
                  selectedOldLines
                    .map((l) => l.rdCode)
                    .filter(
                      (oldRd) =>
                        oldRd !== newRd &&
                        !nextLineList.some((nl) => nl.rdCode === oldRd)
                    )
                );
                if (oldRdsReplaced.size > 0) {
                  setLrvCatalog((prevCatalog) =>
                    prevCatalog.map((item) =>
                      oldRdsReplaced.has(item.rdCode)
                        ? { ...item, rdCode: newRd }
                        : item
                    )
                  );
                  if (oldRdsReplaced.has(selectedRdCode)) {
                    setSelectedRdCode(newRd);
                  }
                }
              }
              if (patch.objectName) {
                const newObj = patch.objectName;
                const oldObjsReplaced = new Set(
                  selectedOldLines
                    .map((l) => l.objectName)
                    .filter(
                      (oldObj) =>
                        oldObj !== newObj &&
                        !nextLineList.some((nl) => nl.objectName === oldObj)
                    )
                );
                if (oldObjsReplaced.has(selectedObjectName)) {
                  setSelectedObjectName(newObj);
                }
              }
            }}
            onOpenLineInRegistry={(uniqueLineId) => {
              setSelectedObjectName('ALL');
              setSelectedRdCode('ALL');
              setColumnFilters({ uniqueLineId: [uniqueLineId] });
              setActiveSection('registry');
            }}
            onOpenFacilityLocation={(objName) =>
              setLocationModalFacilityName(objName)
            }
            onDeleteLineItems={handleDeleteLineItems}
            onDeleteObject={handleDeleteObject}
            onDeleteRdCode={handleDeleteRdCode}
          />
        )}

        {/* РАЗДЕЛ 1Б: ТЕХНОЛОГИЯ СВАРОЧНОГО ПРОИЗВОДСТВА (СВАРЩИКИ, ТК, СВАРОЧНЫЕ МАТЕРИАЛЫ) */}
        {activeSection === 'welding_tech' && (
          <WeldingTechView
            welders={welders}
            techCards={techCards}
            materials={weldingMaterials}
            onSaveWelder={(w) => {
              recordUndoSnapshot(`Сохранение сварщика / клейма ${w.stamp}`);
              setWelders((prev) =>
                prev.some((x) => (w.id && x.id === w.id) || x.stamp === w.stamp)
                  ? prev.map((x) =>
                      (w.id && x.id === w.id) || x.stamp === w.stamp ? w : x
                    )
                  : [w, ...prev]
              );
              appendSystemAuditEntry(
                'Редактирование',
                'Технология сварки (НАКС)',
                w.stamp,
                'Сохранение карточки сварщика / бригады',
                '—',
                `${w.stamp} — ${w.fullName} (${w.certNumber})`
              );
            }}
            onDeleteWelder={handleDeleteWelder}
            onSaveTechCard={(tc) => {
              recordUndoSnapshot(`Сохранение техкарты ${tc.number}`);
              setTechCards((prev) =>
                prev.some((x) => x.id === tc.id)
                  ? prev.map((x) => (x.id === tc.id ? tc : x))
                  : [tc, ...prev]
              );
              appendSystemAuditEntry(
                'Редактирование',
                'Технология сварки (ТК)',
                tc.number,
                'Сохранение технологической карты (WPS)',
                '—',
                `${tc.number} (${tc.weldingType}, Ø${tc.minDiameterMm}..${tc.maxDiameterMm})`
              );
            }}
            onDeleteTechCard={handleDeleteTechCard}
            onSaveMaterial={(mat) => {
              recordUndoSnapshot(`Сохранение СМ ${mat.brandAndDiameter}`);
              setWeldingMaterials((prev) =>
                prev.some((x) => x.id === mat.id)
                  ? prev.map((x) => (x.id === mat.id ? mat : x))
                  : [mat, ...prev]
              );
              appendSystemAuditEntry(
                'Редактирование',
                'Технология сварки (СМ)',
                mat.certificateNumber,
                'Сохранение сертификата сварочных материалов',
                '—',
                `${mat.brandAndDiameter} (партия ${mat.batchNumber})`
              );
            }}
            onDeleteMaterial={handleDeleteWeldingMaterial}
          />
        )}

        {/* РАЗДЕЛ 2: ЖУРНАЛЫ СВАРОЧНЫХ РАБОТ (СТО ГАЗПРОМ 15-1.1-002-2023 И ГОСТ 32569-2013) */}
        {activeSection === 'journals' && (
          <WeldingJournalsView
            joints={scopedJoints}
            materials={weldingMaterials}
            lrvCatalog={lrvCatalog}
            selectedObjectName={selectedObjectName}
            selectedRdCode={selectedRdCode}
            onEditJoint={(j) =>
              setPassportModal({
                isOpen: true,
                mode: 'edit',
                joint: j,
              })
            }
          />
        )}

        {/* РАЗДЕЛ 3: ОТЧЁТНОСТЬ ПО ГОТОВНОСТИ (ОБЪЕКТ, ШИФР РД, ЛИНИЯ, КОНТУР) */}
        {activeSection === 'readiness' && (
          <ReadinessReportView
            joints={scopedJoints}
            onFilterRegistryByCondition={(cond: ReadinessGroupCondition, val: string) => {
              if (cond === 'objectName') {
                setSelectedObjectName(val);
                setSelectedRdCode('ALL');
              } else if (cond === 'rdCode') {
                setSelectedRdCode(val);
              } else {
                setColumnFilters({ [cond]: [val] });
              }
              setActiveSection('registry');
            }}
          />
        )}

        {/* РАЗДЕЛ 4: КАТАЛОГ ЛРВ И СПЕЦИФИКАЦИИ (С ПРИВЯЗКОЙ К ШИФРУ РД) */}
        {activeSection === 'lrv_catalog' && (
          <LrvCatalogView
            catalog={lrvCatalog}
            facilities={derivedFacilities}
            selectedRdCode={selectedRdCode}
            onAddLrvItems={(newItems) => {
              recordUndoSnapshot(`Добавление в каталог ЛРВ (${newItems.length} поз.)`);
              setLrvCatalog((prev) => [...newItems, ...prev]);
              appendSystemAuditEntry(
                'Создание стыка',
                newItems[0]?.rdCode || 'Каталог ЛРВ',
                `${newItems.length} поз.`,
                'Добавление позиций в Каталог ЛРВ',
                '—',
                newItems.map((i) => `${i.lrvCode} (${i.shortName})`).slice(0, 5).join(', ')
              );
            }}
            onUpdateLrvItem={(updatedItem) => {
              recordUndoSnapshot(`Редактирование позиции ЛРВ ${updatedItem.lrvCode}`);
              setLrvCatalog((prev) =>
                prev.map((item) => (item.id === updatedItem.id ? updatedItem : item))
              );
              appendSystemAuditEntry(
                'Редактирование',
                updatedItem.rdCode || 'Каталог ЛРВ',
                updatedItem.lrvCode,
                'Редактирование позиции Каталога ЛРВ',
                '—',
                `${updatedItem.lrvCode} — ${updatedItem.shortName} (Ø${updatedItem.diameterMm}×${updatedItem.wallThickness}, ${updatedItem.material})`
              );
            }}
            onDeleteLrvItems={handleDeleteLrvItems}
          />
        )}

        {/* РАЗДЕЛ 5: ЖУРНАЛ ИЗМЕНЕНИЙ (АУДИТ) */}
        {activeSection === 'audit_log' && <AuditHistoryView logs={auditLogs} />}

        {/* РАЗДЕЛ 6: РУКОВОДСТВО ПОЛЬЗОВАТЕЛЯ (СТИЛЬНЫЙ БУКЛЕТ PDF ПО РОЛЯМ) */}
        {activeSection === 'user_guide' && <UserGuideBookletView />}
      </main>

      {/* МОДАЛЬНЫЕ ОКНА */}
      <ColumnTemplatesModal
        isOpen={isColumnsModalOpen}
        onClose={() => setIsColumnsModalOpen(false)}
        columnOrder={columnOrder}
        visibleColumns={visibleColumns}
        onChangeColumns={(order, vis) => {
          setColumnOrder(order);
          setVisibleColumns(vis);
        }}
        templates={templates}
        activeTemplateId={activeTemplateId}
        onApplyTemplate={handleApplyTemplate}
        onSaveNewTemplate={handleSaveNewTemplate}
        onDeleteTemplate={handleDeleteTemplate}
      />

      <BulkEditModal
        isOpen={isBulkEditOpen}
        onClose={() => setIsBulkEditOpen(false)}
        selectedJoints={joints.filter((j) => selectedJointIds.includes(j.id))}
        welders={welders}
        inspectors={INSPECTORS_DIRECTORY}
        facilityCoords={{
          latitude: currentFacility.latitude,
          longitude: currentFacility.longitude,
        }}
        onApplyBulkUpdate={handleApplyBulkUpdate}
      />

      <JointPassportModal
        isOpen={passportModal.isOpen}
        mode={passportModal.mode}
        initialJoint={passportModal.joint}
        allJoints={joints}
        facilities={derivedFacilities}
        projectLineList={projectLineList}
        lrvCatalog={lrvCatalog}
        welders={welders}
        techCards={techCards}
        weldingMaterials={weldingMaterials}
        inspectors={INSPECTORS_DIRECTORY}
        auditLogsForJoint={
          passportModal.joint
            ? auditLogs.filter((a) => a.jointId === passportModal.joint?.id)
            : []
        }
        defaultObjectName={
          selectedObjectName === 'ALL'
            ? derivedFacilities[0]?.name || EMPTY_FACILITY_FALLBACK.name
            : selectedObjectName
        }
        defaultRdCode={
          selectedRdCode === 'ALL'
            ? currentFacility.rdCodes[0]?.code ||
              EMPTY_FACILITY_FALLBACK.rdCodes[0].code
            : selectedRdCode
        }
        onSave={handleSaveJointFromPassport}
        onNavigateJoint={(target) =>
          setPassportModal((prev) => ({
            ...prev,
            joint: target,
          }))
        }
        onDeleteJoint={handleDeleteJointFromPassport}
        onOpenFacilityLocation={(objName) => setLocationModalFacilityName(objName)}
        onClose={() =>
          setPassportModal({
            isOpen: false,
            mode: 'create',
            joint: null,
          })
        }
      />

      <ImportJointsExcelModal
        isOpen={isImportExcelOpen}
        onClose={() => setIsImportExcelOpen(false)}
        projectLineList={projectLineList}
        lrvCatalog={lrvCatalog}
        techCards={techCards}
        existingJoints={joints}
        defaultObjectName={
          selectedObjectName === 'ALL'
            ? derivedFacilities[0]?.name || EMPTY_FACILITY_FALLBACK.name
            : selectedObjectName
        }
        defaultRdCode={
          selectedRdCode === 'ALL'
            ? currentFacility.rdCodes[0]?.code ||
              EMPTY_FACILITY_FALLBACK.rdCodes[0].code
            : selectedRdCode
        }
        onImportJoints={handleImportJoints}
      />

      <FacilityLocationModal
        isOpen={Boolean(locationModalFacilityName)}
        facility={activeLocationFacility}
        facilities={derivedFacilities}
        presets={FACILITY_LOCATION_PRESETS}
        onSaveLocation={handleSaveFacilityLocation}
        onClose={() => setLocationModalFacilityName(null)}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        currentUser={currentUser}
        accounts={userAccounts}
        onRegisterAccount={(newAcc) => {
          setUserAccounts((prev) => [...prev, newAcc]);
          const entry: AuditLogEntry = {
            id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            timestamp: new Date().toISOString(),
            userLogin: newAcc.login,
            userFullName: newAcc.fullName,
            userRole: newAcc.role,
            jointId: 'sys-auth',
            uniqueLineId: 'Регистрация пользователя',
            jointNumber: `Сессия #${newAcc.sessionNumber}`,
            rdCode: newAcc.department,
            fieldKey: 'auth_register',
            fieldLabel: 'Регистрация новой учётной записи',
            oldValue: '—',
            newValue: `${newAcc.fullName} (${newAcc.login}, ${newAcc.role})`,
            operationType: 'create_joint',
          };
          setAuditLogs((prev) => [entry, ...prev]);
        }}
        onDeleteAccount={handleDeleteUserAccount}
        onAuthenticate={(acc) => setCurrentUser(acc)}
      />

      <BackupAndResetModal
        isOpen={backupModalState.isOpen}
        initialMode={backupModalState.initialTab}
        onClose={() =>
          setBackupModalState((prev) => ({ ...prev, isOpen: false }))
        }
        currentUser={currentUser}
        currentPayload={{
          joints,
          projectLineList,
          lrvCatalog,
          auditLogs,
          welders,
          techCards,
          weldingMaterials,
          userAccounts,
          facilityGeoOverrides,
          templates,
          activeTemplateId,
        }}
        onRestoreBackup={handleRestoreFullBackup}
        onAuthorZeroReset={handleAuthorZeroReset}
        onAuthorRestoreDemoSeed={handleAuthorRestoreDemoSeed}
      />
    </div>
  );
}
