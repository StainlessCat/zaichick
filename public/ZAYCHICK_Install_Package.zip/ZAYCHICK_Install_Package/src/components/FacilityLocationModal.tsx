import React, { useEffect, useState } from 'react';
import { Check, CloudSun, Compass, MapPin, X } from 'lucide-react';
import { FacilityLocationPreset, FacilityObject } from '../types/welding';
import {
  estimateAmbientTempByCoordsAndDate,
  formatDateDDMMYY,
  getFacilityWeatherStationName,
} from '../utils/weldingLogic';

interface FacilityLocationModalProps {
  isOpen: boolean;
  facility: FacilityObject | null;
  facilities: FacilityObject[];
  presets: FacilityLocationPreset[];
  onSaveLocation: (
    objectName: string,
    location: {
      region: string;
      weatherStation: string;
      latitude: number;
      longitude: number;
    }
  ) => void;
  onClose: () => void;
}

export const FacilityLocationModal: React.FC<FacilityLocationModalProps> = ({
  isOpen,
  facility,
  facilities,
  presets,
  onSaveLocation,
  onClose,
}) => {
  const [selectedObjName, setSelectedObjName] = useState('');
  const [region, setRegion] = useState('');
  const [weatherStation, setWeatherStation] = useState('');
  const [latitude, setLatitude] = useState(70.37);
  const [longitude, setLongitude] = useState(68.43);
  const [previewDate, setPreviewDate] = useState('2026-10-20');

  useEffect(() => {
    if (!isOpen) return;
    const target = facility || facilities[0];
    if (target) {
      setSelectedObjName(target.name);
      setRegion(target.region);
      setWeatherStation(getFacilityWeatherStationName(target));
      setLatitude(target.latitude);
      setLongitude(target.longitude);
    }
  }, [isOpen, facility, facilities]);

  if (!isOpen) return null;

  const handleSelectObject = (name: string) => {
    setSelectedObjName(name);
    const found = facilities.find((f) => f.name === name);
    if (found) {
      setRegion(found.region);
      setWeatherStation(getFacilityWeatherStationName(found));
      setLatitude(found.latitude);
      setLongitude(found.longitude);
    }
  };

  const handleApplyPreset = (preset: FacilityLocationPreset) => {
    setRegion(preset.region);
    setWeatherStation(preset.weatherStation);
    setLatitude(preset.latitude);
    setLongitude(preset.longitude);
  };

  const previewTemp = estimateAmbientTempByCoordsAndDate(
    latitude,
    longitude,
    previewDate
  );
  const formattedTemp = previewTemp > 0 ? `+${previewTemp}` : `${previewTemp}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedObjName) return;
    onSaveLocation(selectedObjName, {
      region: region.trim() || 'Промышленная площадка',
      weatherStation: weatherStation.trim() || 'Метеопункт объекта',
      latitude: Number(latitude),
      longitude: Number(longitude),
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Выбор местоположения объекта и метеопункта"
    >
      <div
        className="fixed inset-0 bg-slate-900/45 backdrop-blur-[1px]"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 bg-[#1e3799] text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <MapPin className="w-5 h-5 text-sky-300" />
            <div>
              <h2 className="text-sm font-bold">
                Метеопункт и местоположение объекта строительства
              </h2>
              <p className="text-xs text-sky-200">
                По данным метеопункта объекта система автоматически определяет температуру окружающей среды на дату сварки
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть окно выбора местоположения объекта"
            className="p-1.5 rounded-lg text-sky-100 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-6 space-y-4 overflow-y-auto text-xs flex-1"
        >
          {/* 1. Выбор объекта из лайнлиста */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Объект строительства (из лайнлиста)
            </label>
            <select
              value={selectedObjName}
              onChange={(e) => handleSelectObject(e.target.value)}
              aria-label="Объект для настройки местоположения"
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-[#1e3799]"
            >
              {facilities.map((f) => (
                <option key={f.id} value={f.name}>
                  {f.name} ({getFacilityWeatherStationName(f)} · {f.region})
                </option>
              ))}
            </select>
          </div>

          {/* 2. Справочник площадок / метеопунктов */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Compass className="w-4 h-4 text-[#1e3799]" />
              <span>Быстрый выбор метеопункта / месторождения:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {presets.map((preset) => {
                const isSelected =
                  Math.abs(preset.latitude - latitude) < 0.05 &&
                  Math.abs(preset.longitude - longitude) < 0.05;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleApplyPreset(preset)}
                    className={`p-2.5 rounded-lg border text-left transition-colors flex items-start justify-between gap-2 ${
                      isSelected
                        ? 'bg-[#e8f1fc] border-[#1e3799] text-[#1e3799]'
                        : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-xs">{preset.title}</div>
                      <div className="text-[11px] text-slate-500">{preset.region}</div>
                    </div>
                    <span className="font-mono text-[11px] font-bold text-[#1e3799] shrink-0">
                      {preset.weatherStation}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Название метеопункта, регион и координаты */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Название метеопункта *
              </label>
              <input
                type="text"
                value={weatherStation}
                onChange={(e) => setWeatherStation(e.target.value)}
                aria-label="Название метеопункта"
                className="w-full px-3 py-2 bg-white border border-[#1e3799] rounded-md font-semibold text-[#1e3799]"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Регион / Площадка
              </label>
              <input
                type="text"
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                aria-label="Регион объекта"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Широта (° с.ш.)
              </label>
              <input
                type="number"
                step="0.01"
                min={40}
                max={78}
                value={latitude}
                onChange={(e) => setLatitude(Number(e.target.value))}
                aria-label="Широта объекта"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md font-mono font-bold text-[#1e3799]"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Долгота (° в.д.)
              </label>
              <input
                type="number"
                step="0.01"
                min={25}
                max={175}
                value={longitude}
                onChange={(e) => setLongitude(Number(e.target.value))}
                aria-label="Долгота объекта"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md font-mono font-bold text-[#1e3799]"
              />
            </div>
          </div>

          {/* 4. Предпросмотр автоматической температуры по метеопункту объекта */}
          <div className="p-3.5 rounded-xl bg-[#e8f1fc] border border-sky-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-[#1e3799] text-white">
                <CloudSun className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-[#1e3799]">
                  Автоматический расчёт температуры среды для объекта
                </div>
                <div className="text-[11px] text-slate-600">
                  Источник данных: {weatherStation || 'Метеопункт площадки'} ({region})
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="date"
                value={previewDate}
                onChange={(e) => setPreviewDate(e.target.value)}
                aria-label="Дата для проверки температуры"
                className="px-2.5 py-1.5 bg-white border border-sky-300 rounded font-mono text-xs"
              />
              <span className="px-3 py-1.5 rounded-lg bg-[#1e3799] text-white font-mono font-bold text-xs">
                {formatDateDDMMYY(previewDate)}: {formattedTemp} °C
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#1e3799] text-white font-semibold hover:bg-[#15276e]"
            >
              <Check className="w-4 h-4" />
              <span>Сохранить местоположение объекта</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
