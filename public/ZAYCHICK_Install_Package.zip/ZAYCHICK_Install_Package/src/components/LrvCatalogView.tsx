import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Database,
  Edit3,
  FileSpreadsheet,
  Filter,
  Lock,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { FacilityObject, LRVItem } from '../types/welding';
import {
  getLrvItemDn1,
  getLrvItemDn2,
  mmToNominalBoreDn,
} from '../utils/weldingLogic';
import {
  applyTableColumnFiltersAndSort,
  TableColumnFilterHeader,
} from './TableColumnFilterPopover';

interface LrvCatalogViewProps {
  catalog: LRVItem[];
  facilities: FacilityObject[];
  selectedRdCode: string;
  onAddLrvItems: (items: LRVItem[]) => void;
  onUpdateLrvItem?: (item: LRVItem) => void;
  onDeleteLrvItems?: (ids: string[]) => void;
}

export const LrvCatalogView: React.FC<LrvCatalogViewProps> = ({
  catalog,
  facilities,
  selectedRdCode,
  onAddLrvItems,
  onUpdateLrvItem,
  onDeleteLrvItems,
}) => {
  const allRds = useMemo(
    () =>
      facilities.flatMap((f) =>
        f.rdCodes.map((r) => ({
          objectName: f.name,
          code: r.code,
          title: r.title,
        }))
      ),
    [facilities]
  );

  const [rdFilter, setRdFilter] = useState<string>(selectedRdCode);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingLrvId, setEditingLrvId] = useState<string | null>(null);
  const [showExcelCleaner, setShowExcelCleaner] = useState(false);
  const [selectedLrvIds, setSelectedLrvIds] = useState<string[]>([]);
  const [confirmDeleteLrvId, setConfirmDeleteLrvId] = useState<string | null>(
    null
  );
  const [confirmBulkDeleteLrv, setConfirmBulkDeleteLrv] = useState(false);

  // Excel-фильтры по каждому столбцу таблицы ЛРВ и сортировка
  const [columnFilters, setColumnFilters] = useState<Record<string, string[]>>({});
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  } | null>(null);

  // Форма новой или редактируемой позиции ЛРВ (с поддержкой DN1/DN2, двух диаметров Ø1/Ø2 и двух толщин S1/S2)
  const [newRd, setNewRd] = useState(allRds[0]?.code || '');
  const [newLrvCode, setNewLrvCode] = useState('ЛРВ-001ТХ3-0501');
  const [newShortName, setNewShortName] = useState('Переход К 219х10-159х8');
  const [newMaterial, setNewMaterial] = useState('09Г2С');
  const [newNtd, setNewNtd] = useState('ГОСТ 17378-2001');
  const [newManufacturer, setNewManufacturer] = useState('ПАО «ЧТПЗ»');
  const [newDn1, setNewDn1] = useState<number>(200);
  const [newDiameter1, setNewDiameter1] = useState(219);
  const [newThickness1, setNewThickness1] = useState(10);
  const [hasSecondDimension, setHasSecondDimension] = useState(true);
  const [newDn2, setNewDn2] = useState<number>(150);
  const [newDiameter2, setNewDiameter2] = useState<number>(159);
  const [newThickness2, setNewThickness2] = useState<number>(8);
  const [newQty, setNewQty] = useState(16);
  const [newUnit, setNewUnit] = useState<'шт' | 'м'>('шт');

  useEffect(() => {
    if (!editingLrvId && !newRd && allRds.length > 0) {
      setNewRd(allRds[0].code);
    }
  }, [allRds, editingLrvId, newRd]);

  const handleStartEditLrv = (item: LRVItem) => {
    setFormError('');
    setEditingLrvId(item.id);
    setNewRd(item.rdCode);
    setNewLrvCode(item.lrvCode);
    setNewShortName(item.shortName);
    setNewMaterial(item.material);
    setNewNtd(item.ntd);
    setNewManufacturer(item.manufacturer || '');
    setNewDn1(getLrvItemDn1(item) || 150);
    setNewDiameter1(item.diameterMm);
    setNewThickness1(item.wallThickness);
    const has2 = Boolean(item.diameterMm2 || item.wallThickness2);
    setHasSecondDimension(has2);
    setNewDn2(getLrvItemDn2(item) || 100);
    setNewDiameter2(item.diameterMm2 || 108);
    setNewThickness2(item.wallThickness2 || 6);
    setNewQty(item.specQty);
    setNewUnit(item.unit);
    setShowExcelCleaner(false);
    setShowAddForm(true);
  };

  // Буфер очистки выгрузки из Excel
  const [rawExcelText, setRawExcelText] = useState(
    `ЛРВ-001ТХ3-0490 ; Переход К 159х8-108х6 ; ст. 09Г2С ; ГОСТ 17378-2001 ; 159 ; 8 ; 108 ; 6 ; 15 ; шт\nЛРВ-001ТХ3-0495 ; Тройник переходной 219х10-159х8 ; 09Г2С ; ГОСТ 17376-2001 ; 219 ; 10 ; 159 ; 8 ; 8 ; шт`
  );

  // Базовая выборка по шифру РД
  const rdScopedCatalog = useMemo(() => {
    return catalog.filter((item) => {
      if (rdFilter !== 'ALL' && item.rdCode !== rdFilter) return false;
      return true;
    });
  }, [catalog, rdFilter]);

  const lrvColumnGetters = useMemo<Record<string, (item: LRVItem) => string>>(
    () => ({
      lrvCode: (item) => item.lrvCode,
      rdCode: (item) => item.rdCode,
      shortName: (item) => item.shortName,
      material: (item) => item.material,
      ntd: (item) => item.ntd,
      manufacturer: (item) => item.manufacturer || '',
      dn1: (item) => {
        const val = getLrvItemDn1(item);
        return val !== undefined ? String(val) : '';
      },
      diameterMm: (item) => String(item.diameterMm),
      wallThickness: (item) => item.wallThickness.toFixed(1),
      // Для элементов с одним диаметром вторые поля строго пустые ("")
      dn2: (item) => {
        const val = getLrvItemDn2(item);
        return val !== undefined ? String(val) : '';
      },
      diameterMm2: (item) =>
        item.diameterMm2 !== undefined ? String(item.diameterMm2) : '',
      wallThickness2: (item) =>
        item.wallThickness2 !== undefined ? item.wallThickness2.toFixed(1) : '',
      specQty: (item) => `${item.specQty} ${item.unit}`,
    }),
    []
  );

  const lrvColumnLabels: Record<string, string> = {
    lrvCode: 'Код ЛРВ',
    rdCode: 'Шифр РД',
    shortName: 'Краткое наименование',
    material: 'Материал (Сталь)',
    ntd: 'НТД',
    manufacturer: 'Завод-изготовитель',
    dn1: 'DN 1',
    diameterMm: 'Диаметр Ø1, мм',
    wallThickness: 'Толщина стенки S1, мм',
    dn2: 'DN 2',
    diameterMm2: 'Диаметр Ø2, мм',
    wallThickness2: 'Толщина стенки S2, мм',
    specQty: 'Кол-во по спец.',
  };

  const filteredCatalog = useMemo(
    () =>
      applyTableColumnFiltersAndSort(
        rdScopedCatalog,
        columnFilters,
        lrvColumnGetters,
        sortConfig
      ),
    [rdScopedCatalog, columnFilters, lrvColumnGetters, sortConfig]
  );

  const handleApplyColumnFilter = (
    colKey: string,
    vals: string[] | undefined
  ) => {
    setColumnFilters((prev) => {
      const next = { ...prev };
      if (vals === undefined) {
        delete next[colKey];
      } else {
        next[colKey] = vals;
      }
      return next;
    });
  };

  const handleSortColumn = (colKey: string, direction: 'asc' | 'desc') => {
    setSortConfig({ key: colKey, direction });
  };

  const [formError, setFormError] = useState('');

  const handleAddSingleItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanCode = newLrvCode.trim();
    if (!cleanCode) {
      setFormError('Укажите код ЛРВ.');
      return;
    }

    if (
      catalog.some(
        (existing) =>
          existing.id !== editingLrvId &&
          existing.lrvCode.toLowerCase() === cleanCode.toLowerCase()
      )
    ) {
      setFormError(
        `Код ЛРВ «${cleanCode}» уже существует в каталоге. Дублирование кодов ЛРВ запрещено.`
      );
      return;
    }

    const rdEntry = allRds.find((r) => r.code === newRd) || allRds[0];
    const d1 = Number(String(newDiameter1).replace(',', '.'));
    const s1 = Number(String(newThickness1).replace(',', '.'));
    const d2 =
      hasSecondDimension && newDiameter2
        ? Number(String(newDiameter2).replace(',', '.'))
        : undefined;
    const s2 =
      hasSecondDimension && newThickness2
        ? Number(String(newThickness2).replace(',', '.'))
        : undefined;

    if (Number.isNaN(d1) || d1 < 10 || d1 > 2520) {
      setFormError('Диаметр Ø1 должен быть в пределах от 10 до 2520 мм.');
      return;
    }
    if (Number.isNaN(s1) || s1 < 1 || s1 >= d1 / 2) {
      setFormError(
        `Толщина стенки S1 (${s1} мм) должна быть от 1 мм и меньше половины диаметра (${
          d1 / 2
        } мм).`
      );
      return;
    }
    if (hasSecondDimension && d2 !== undefined) {
      if (Number.isNaN(d2) || d2 < 10 || d2 > 2520) {
        setFormError('Диаметр Ø2 должен быть в пределах от 10 до 2520 мм.');
        return;
      }
      if (s2 !== undefined && (Number.isNaN(s2) || s2 < 1 || s2 >= d2 / 2)) {
        setFormError(
          `Толщина стенки S2 (${s2} мм) должна быть от 1 мм и меньше половины диаметра Ø2 (${
            d2 / 2
          } мм).`
        );
        return;
      }
    }

    const computedDn1 = Number(newDn1) || mmToNominalBoreDn(d1);
    const computedDn2 =
      hasSecondDimension && d2 !== undefined
        ? Number(newDn2) || mmToNominalBoreDn(d2)
        : undefined;

    const item: LRVItem = {
      id: editingLrvId || `lrv-${Date.now()}`,
      lrvCode: cleanCode,
      rdCode: rdEntry?.code || newRd.trim() || 'НОВЫЙ-ШИФР-РД',
      objectName: rdEntry?.objectName || 'Новый объект',
      shortName: newShortName.trim(),
      material: newMaterial.trim(),
      ntd: newNtd.trim(),
      manufacturer: newManufacturer.trim() || undefined,
      dn1: computedDn1,
      diameterMm: d1,
      wallThickness: s1,
      dn2: computedDn2,
      diameterMm2: d2,
      wallThickness2: s2,
      specQty: Math.max(0.01, Number(String(newQty).replace(',', '.')) || 1),
      unit: newUnit,
    };

    if (editingLrvId && onUpdateLrvItem) {
      onUpdateLrvItem(item);
    } else {
      onAddLrvItems([item]);
    }
    setEditingLrvId(null);
    setShowAddForm(false);
  };

  const handleCleanAndImportExcel = (e: React.FormEvent) => {
    e.preventDefault();
    const rdEntry = allRds.find((r) => r.code === newRd) || allRds[0];
    const lines = rawExcelText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    const existingCodes = new Set(
      catalog.map((c) => c.lrvCode.trim().toLowerCase())
    );

    const parsed: LRVItem[] = [];
    lines.forEach((line, i) => {
      const parts = line.split(/[;\t]/).map((p) => p.trim());
      const rawCode = parts[0] || `ЛРВ-АВТО-${Date.now()}-${i + 1}`;
      if (existingCodes.has(rawCode.toLowerCase())) {
        return; // Пропускаем дубликаты кодов ЛРВ
      }
      existingCodes.add(rawCode.toLowerCase());

      const shortName = parts[1] || 'Деталь трубопровода';

      const dualMatch = shortName.match(
        /(\d+)[xх×](\d+(?:[.,]\d+)?)\s*-\s*(\d+)[xх×](\d+(?:[.,]\d+)?)/i
      );
      const isTenCol = parts.length >= 9;

      const d1 =
        Number((parts[4] || '').replace(',', '.')) ||
        (dualMatch ? Number(dualMatch[1]) : 159);
      const s1 =
        Number((parts[5] || '').replace(',', '.')) ||
        (dualMatch ? Number(dualMatch[2].replace(',', '.')) : 8);
      const d2 = isTenCol
        ? Number((parts[6] || '').replace(',', '.')) || undefined
        : dualMatch
        ? Number(dualMatch[3])
        : undefined;
      const s2 = isTenCol
        ? Number((parts[7] || '').replace(',', '.')) || undefined
        : dualMatch
        ? Number(dualMatch[4].replace(',', '.'))
        : undefined;
      const qtyIdx = isTenCol ? 8 : 6;
      const unitIdx = isTenCol ? 9 : 7;

      const safeD1 = d1 >= 10 && d1 <= 2520 ? d1 : 159;
      const safeS1 = s1 >= 1 && s1 < safeD1 / 2 ? s1 : 8;

      parsed.push({
        id: `lrv-imp-${Date.now()}-${i}`,
        lrvCode: rawCode,
        rdCode: rdEntry?.code || newRd || 'НОВЫЙ-ШИФР-РД',
        objectName: rdEntry?.objectName || 'Новый объект',
        shortName,
        material: (parts[2] || '09Г2С').replace(/^ст\.?\s*/i, ''),
        ntd: parts[3] || 'ГОСТ 17375-2001',
        dn1: mmToNominalBoreDn(safeD1),
        diameterMm: safeD1,
        wallThickness: safeS1,
        dn2: d2 !== undefined ? mmToNominalBoreDn(d2) : undefined,
        diameterMm2: d2,
        wallThickness2: s2,
        specQty: Math.max(
          0.01,
          Number((parts[qtyIdx] || '').replace(',', '.')) || 10
        ),
        unit: parts[unitIdx] === 'м' ? 'м' : 'шт',
      });
    });

    if (parsed.length > 0) {
      onAddLrvItems(parsed);
      setShowExcelCleaner(false);
    }
  };

  const activeFilterKeys = Object.keys(columnFilters);

  return (
    <div className="space-y-4">
      {/* Верхняя панель каталога ЛРВ */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-[#1e3799]" />
            <h2 className="font-display text-base font-bold text-slate-900">
              Каталог кодов ЛРВ и спецификаций с привязкой к шифрам РД
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Раздельные столбцы условного прохода (DN 1 / DN 2), диаметров (Ø1 / Ø2) и толщин стенок (S1 / S2) · Для элементов с одним диаметром вторые поля пустые · Фильтрация как в Excel
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onDeleteLrvItems &&
            selectedLrvIds.length > 0 &&
            (confirmBulkDeleteLrv ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-red-300 bg-red-50 text-xs">
                <span className="font-bold text-red-800">
                  Удалить {selectedLrvIds.length} поз. ЛРВ?
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteLrvItems(selectedLrvIds);
                    setSelectedLrvIds([]);
                    setConfirmBulkDeleteLrv(false);
                  }}
                  className="px-2 py-0.5 rounded bg-red-600 text-white font-bold hover:bg-red-700"
                >
                  Да, удалить
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmBulkDeleteLrv(false)}
                  className="px-2 py-0.5 rounded bg-white border border-slate-300 text-slate-700"
                >
                  Отмена
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmBulkDeleteLrv(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-300 bg-red-50 text-red-700 text-xs font-semibold hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Удалить материалы ({selectedLrvIds.length})</span>
              </button>
            ))}

          <button
            type="button"
            onClick={() => {
              setShowExcelCleaner((v) => !v);
              setShowAddForm(false);
              setEditingLrvId(null);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#1e3799]/30 bg-[#e8f1fc] text-[#1e3799] text-xs font-semibold hover:bg-sky-100 transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Импорт и очистка из Excel</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingLrvId(null);
              setShowAddForm((v) => !v);
              setShowExcelCleaner(false);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1e3799] text-white text-xs font-semibold hover:bg-[#15276e] transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Добавить позицию ЛРВ</span>
          </button>
        </div>
      </div>

      {/* Модуль импорта и очистки выгрузки из Excel */}
      {showExcelCleaner && (
        <form
          onSubmit={handleCleanAndImportExcel}
          className="bg-white rounded-xl border border-[#1e3799]/30 p-5 space-y-4 shadow-sm"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-[#1e3799]">
              Пакетная очистка и загрузка базы материалов из Excel / Системы закупок
            </h3>
            <span className="text-[11px] text-slate-500">
              Автораспознавание DN, Ø1×S1 и Ø2×S2 (для одноразмерных деталей вторые поля остаются пустыми)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-5">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Привязать загружаемые коды ЛРВ к Шифру РД *
              </label>
              {allRds.length > 0 ? (
                <select
                  value={newRd}
                  onChange={(e) => setNewRd(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-xs font-mono"
                >
                  {allRds.map((r) => (
                    <option key={r.code} value={r.code}>
                      {r.code}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  required
                  value={newRd}
                  onChange={(e) => setNewRd(e.target.value)}
                  placeholder="Введите шифр РД (напр.: 0092.049.Р.13/1-ТХ3)"
                  className="w-full px-3 py-2 bg-white border border-[#1e3799] rounded-md text-xs font-mono"
                />
              )}
            </div>
            <div className="md:col-span-7">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Строки из Excel (Код ЛРВ ; Наименование ; Сталь ; НТД ; Ø1 ; S1 ; [Ø2 ; S2 ;] Кол-во ; Ед.)
              </label>
              <textarea
                rows={3}
                value={rawExcelText}
                onChange={(e) => setRawExcelText(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md text-xs font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowExcelCleaner(false)}
              className="px-3 py-1.5 rounded border border-slate-300 text-xs text-slate-600"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#1e3799] text-white text-xs font-semibold hover:bg-[#15276e]"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Очистить и добавить в каталог ЛРВ</span>
            </button>
          </div>
        </form>
      )}

      {/* Форма ручного добавления или редактирования одной позиции ЛРВ */}
      {showAddForm && (
        <form
          onSubmit={handleAddSingleItem}
          className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-sm"
        >
          {formError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-300 text-red-800 text-xs font-semibold">
              {formError}
            </div>
          )}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-xs font-bold text-[#1e3799]">
              {editingLrvId
                ? `Редактирование позиции ЛРВ (${newLrvCode})`
                : 'Новая позиция спецификации ЛРВ (с поддержкой DN 1 / DN 2 и двух диаметров Ø1 / Ø2)'}
            </h3>
            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={hasSecondDimension}
                onChange={(e) => setHasSecondDimension(e.target.checked)}
                className="rounded border-slate-300 text-[#1e3799] focus:ring-[#1e3799]"
              />
              <span>Переход / переходной тройник (второй проход DN 2, диаметр Ø2 и толщина S2)</span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs text-slate-600 mb-1">Шифр РД *</label>
              {allRds.length > 0 ? (
                <select
                  value={newRd}
                  onChange={(e) => setNewRd(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
                >
                  {allRds.map((r) => (
                    <option key={r.code} value={r.code}>
                      {r.code}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  required
                  value={newRd}
                  onChange={(e) => setNewRd(e.target.value)}
                  placeholder="Введите шифр РД..."
                  className="w-full px-3 py-1.5 bg-white border border-[#1e3799] rounded text-xs font-mono"
                />
              )}
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">Код ЛРВ *</label>
              <input
                type="text"
                required
                value={newLrvCode}
                onChange={(e) => setNewLrvCode(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">Краткое наименование *</label>
              <input
                type="text"
                required
                value={newShortName}
                onChange={(e) => setNewShortName(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-9 gap-3">
            <div>
              <label className="block text-xs text-slate-600 mb-1">Марка стали</label>
              <input
                type="text"
                value={newMaterial}
                onChange={(e) => setNewMaterial(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">НТД (ГОСТ / ТУ)</label>
              <input
                type="text"
                value={newNtd}
                onChange={(e) => setNewNtd(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">Завод-изготовитель</label>
              <input
                type="text"
                value={newManufacturer}
                onChange={(e) => setNewManufacturer(e.target.value)}
                placeholder="ПАО «ЧТПЗ»"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">DN 1</label>
              <input
                type="number"
                value={newDn1}
                onChange={(e) => setNewDn1(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">Диаметр Ø1, мм</label>
              <input
                type="number"
                value={newDiameter1}
                onChange={(e) => {
                  const d = Number(e.target.value);
                  setNewDiameter1(d);
                  const autoDn = mmToNominalBoreDn(d);
                  if (autoDn !== undefined) setNewDn1(autoDn);
                }}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-600 mb-1">Толщина S1, мм</label>
              <input
                type="number"
                step="0.5"
                value={newThickness1}
                onChange={(e) => setNewThickness1(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
            </div>
            {hasSecondDimension && (
              <>
                <div>
                  <label className="block text-xs text-[#1e3799] font-semibold mb-1">
                    DN 2
                  </label>
                  <input
                    type="number"
                    value={newDn2}
                    onChange={(e) => setNewDn2(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 bg-[#f4f8fe] border border-[#1e3799]/40 rounded text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#1e3799] font-semibold mb-1">
                    Диаметр Ø2, мм
                  </label>
                  <input
                    type="number"
                    value={newDiameter2}
                    onChange={(e) => {
                      const d = Number(e.target.value);
                      setNewDiameter2(d);
                      const autoDn = mmToNominalBoreDn(d);
                      if (autoDn !== undefined) setNewDn2(autoDn);
                    }}
                    className="w-full px-2.5 py-1.5 bg-[#f4f8fe] border border-[#1e3799]/40 rounded text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#1e3799] font-semibold mb-1">
                    Толщина S2, мм
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={newThickness2}
                    onChange={(e) => setNewThickness2(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 bg-[#f4f8fe] border border-[#1e3799]/40 rounded text-xs font-mono"
                  />
                </div>
              </>
            )}
            <div>
              <label className="block text-xs text-slate-600 mb-1">Кол-во по спец.</label>
              <div className="flex gap-1">
                <input
                  type="number"
                  value={newQty}
                  onChange={(e) => setNewQty(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded text-xs font-mono"
                />
                <select
                  value={newUnit}
                  onChange={(e) => setNewUnit(e.target.value as 'шт' | 'м')}
                  className="px-2 py-1.5 bg-white border border-slate-300 rounded text-xs"
                >
                  <option value="шт">шт</option>
                  <option value="м">м</option>
                </select>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 rounded border border-slate-300 text-xs text-slate-600"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded bg-[#1e3799] text-white text-xs font-semibold hover:bg-[#15276e]"
            >
              Сохранить позицию
            </button>
          </div>
        </form>
      )}

      {/* Фильтр по Шифру РД (строго из лайнлиста) */}
      <div className="bg-white rounded-xl border border-slate-200 p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-700">
            Фильтр по Шифру РД (из лайнлиста):
          </span>
          <select
            value={rdFilter}
            onChange={(e) => setRdFilter(e.target.value)}
            aria-label="Фильтр по Шифру РД (из лайнлиста)"
            className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-md text-xs font-mono"
          >
            <option value="ALL">Все шифры РД лайнлиста ({catalog.length} поз.)</option>
            {allRds.map((r) => (
              <option key={r.code} value={r.code}>
                {r.code} ({r.objectName})
              </option>
            ))}
          </select>
        </div>

        <span className="inline-flex items-center gap-1 text-xs text-[#1e3799] bg-[#e8f1fc] px-2.5 py-1 rounded border border-sky-200">
          <Lock className="w-3.5 h-3.5" />
          <span>Объекты и Шифры РД берутся строго из раздела «Проект (лайнлист)»</span>
        </span>
      </div>

      {/* Индикатор активных Excel-фильтров каталога ЛРВ */}
      {activeFilterKeys.length > 0 && (
        <div className="bg-[#e8f1fc] rounded-xl border border-sky-200 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            {activeFilterKeys.map((k) => (
              <span
                key={k}
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white border border-sky-300 text-[#1e3799] font-medium"
              >
                <Filter className="w-3 h-3" />
                <span>
                  {lrvColumnLabels[k] || k}: {columnFilters[k]?.length} знач.
                </span>
                <button
                  type="button"
                  onClick={() => handleApplyColumnFilter(k, undefined)}
                  className="text-slate-400 hover:text-red-600 font-bold"
                >
                  ✕
                </button>
              </span>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setColumnFilters({})}
            className="inline-flex items-center gap-1 text-[#1e3799] hover:underline font-semibold"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Сбросить фильтры столбцов</span>
          </button>
        </div>
      )}

      {/* Таблица каталога ЛРВ с шапкой #1e3799, Excel-фильтрами и раздельными столбцами DN 1/DN 2, Ø1/Ø2 и S1/S2 */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto min-h-[380px]">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#1e3799] text-white text-left">
                {onDeleteLrvItems && (
                  <th className="py-2.5 px-2.5 border-r border-white/15 w-9 text-center">
                    <input
                      type="checkbox"
                      aria-label="Выбрать все материалы в ЛРВ"
                      checked={
                        filteredCatalog.length > 0 &&
                        filteredCatalog.every((item) =>
                          selectedLrvIds.includes(item.id)
                        )
                      }
                      onChange={() => {
                        const visIds = filteredCatalog.map((i) => i.id);
                        const allChecked =
                          visIds.length > 0 &&
                          visIds.every((id) => selectedLrvIds.includes(id));
                        if (allChecked) {
                          setSelectedLrvIds((prev) =>
                            prev.filter((id) => !visIds.includes(id))
                          );
                        } else {
                          setSelectedLrvIds((prev) =>
                            Array.from(new Set([...prev, ...visIds]))
                          );
                        }
                      }}
                      className="rounded border-white/40 text-sky-400 focus:ring-sky-300 cursor-pointer"
                    />
                  </th>
                )}
                <TableColumnFilterHeader
                  columnKey="lrvCode"
                  label="Код ЛРВ"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.lrvCode}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="rdCode"
                  label="Шифр РД"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.rdCode}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="shortName"
                  label="Краткое наименование"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.shortName}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="material"
                  label="Материал (Сталь)"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.material}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="ntd"
                  label="НТД (ГОСТ / ТУ)"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.ntd}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="manufacturer"
                  label="Завод-изготовитель"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.manufacturer}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                />
                <TableColumnFilterHeader
                  columnKey="dn1"
                  label="Условный проход DN 1"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.dn1}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="diameterMm"
                  label="Диаметр Ø1, мм"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.diameterMm}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="wallThickness"
                  label="Толщина стенки S1, мм"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.wallThickness}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="dn2"
                  label="Условный проход DN 2"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.dn2}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="diameterMm2"
                  label="Диаметр Ø2, мм"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.diameterMm2}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="wallThickness2"
                  label="Толщина стенки S2, мм"
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.wallThickness2}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                <TableColumnFilterHeader
                  columnKey="specQty"
                  label="Кол-во по спец."
                  rows={rdScopedCatalog}
                  getValue={lrvColumnGetters.specQty}
                  activeFilters={columnFilters}
                  onApplyFilter={handleApplyColumnFilter}
                  sortConfig={sortConfig}
                  onSort={handleSortColumn}
                  align="right"
                />
                {onDeleteLrvItems && (
                  <th className="py-2.5 px-3 font-semibold text-center whitespace-nowrap">
                    Действие
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredCatalog.map((item) => {
                const isTransition = Boolean(item.diameterMm2 || item.wallThickness2);
                const dn1Val = getLrvItemDn1(item);
                const dn2Val = getLrvItemDn2(item);
                const isSelected = selectedLrvIds.includes(item.id);

                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-[#e8f1fc]/50 transition-colors ${
                      isSelected
                        ? 'bg-[#e8f1fc]'
                        : 'odd:bg-white even:bg-slate-50/60'
                    }`}
                  >
                    {onDeleteLrvItems && (
                      <td className="py-2.5 px-2.5 border-r border-slate-200 text-center">
                        <input
                          type="checkbox"
                          aria-label={`Выбрать позицию ЛРВ ${item.lrvCode}`}
                          checked={isSelected}
                          onChange={() =>
                            setSelectedLrvIds((prev) =>
                              prev.includes(item.id)
                                ? prev.filter((id) => id !== item.id)
                                : [...prev, item.id]
                            )
                          }
                          className="rounded border-slate-300 text-[#1e3799] focus:ring-[#1e3799] cursor-pointer"
                        />
                      </td>
                    )}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono font-bold text-[#1e3799] whitespace-nowrap">
                      {item.lrvCode}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200">
                      <div className="font-mono text-slate-900 whitespace-nowrap">
                        {item.rdCode}
                      </div>
                      <div className="text-[11px] text-slate-500">{item.objectName}</div>
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 font-semibold text-slate-900">
                      <span>{item.shortName}</span>
                      {isTransition && (
                        <span className="ml-2 text-[11px] font-normal text-[#1e3799]">
                          (2 размера)
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-slate-800 whitespace-nowrap">
                      {item.material}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 text-slate-700 whitespace-nowrap">
                      {item.ntd}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 text-slate-700 whitespace-nowrap">
                      {item.manufacturer || '—'}
                    </td>
                    {/* Условный проход DN 1 */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right font-semibold text-slate-900">
                      {dn1Val !== undefined ? dn1Val : ''}
                    </td>
                    {/* Диаметр Ø1, мм */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right text-slate-900">
                      {item.diameterMm}
                    </td>
                    {/* Толщина стенки S1, мм */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right text-slate-900">
                      {item.wallThickness.toFixed(1)}
                    </td>
                    {/* Условный проход DN 2 — для элементов с одним диаметром строго пусто */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right font-semibold text-[#1e3799]">
                      {dn2Val !== undefined ? dn2Val : ''}
                    </td>
                    {/* Диаметр Ø2, мм — для элементов с одним диаметром строго пусто */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right font-semibold text-[#1e3799]">
                      {item.diameterMm2 !== undefined ? item.diameterMm2 : ''}
                    </td>
                    {/* Толщина стенки S2, мм — для элементов с одним диаметром строго пусто */}
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right font-semibold text-[#1e3799]">
                      {item.wallThickness2 !== undefined
                        ? item.wallThickness2.toFixed(1)
                        : ''}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 font-mono text-right font-semibold text-slate-900 whitespace-nowrap">
                      {item.specQty} {item.unit}
                    </td>
                    {onDeleteLrvItems && (
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        {confirmDeleteLrvId === item.id ? (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteLrvItems([item.id]);
                                setConfirmDeleteLrvId(null);
                                setSelectedLrvIds((prev) =>
                                  prev.filter((id) => id !== item.id)
                                );
                              }}
                              className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold hover:bg-red-700"
                            >
                              Удалить
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteLrvId(null)}
                              className="px-1.5 py-0.5 rounded border border-slate-300 text-slate-600 text-[10px]"
                            >
                              Отмена
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleStartEditLrv(item)}
                              className="p-1.5 rounded text-[#1e3799] hover:bg-sky-50 transition-colors"
                              title={`Редактировать материал ЛРВ «${item.lrvCode}»`}
                              aria-label={`Редактировать материал ЛРВ ${item.lrvCode}`}
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteLrvId(item.id)}
                              className="p-1.5 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                              title={`Удалить материал ЛРВ «${item.lrvCode}»`}
                              aria-label={`Удалить материал ЛРВ ${item.lrvCode}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
