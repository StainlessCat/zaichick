import React, { useState } from 'react';
import { KeyRound, Trash2, UserPlus, Users, X } from 'lucide-react';
import { UserAccount } from '../types/welding';
import { ZaychickLogo } from './ZaychickLogo';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  accounts: UserAccount[];
  onAuthenticate: (account: UserAccount) => void;
  onRegisterAccount?: (account: UserAccount) => void;
  onDeleteAccount?: (login: string) => void;
}

const ROLE_PRESETS = [
  'Главный инженер ПТО',
  'Ведущий инженер ПТО (Лайнлист / РД)',
  'Инженер ПТО (Каталог ЛРВ и входной контроль)',
  'Главный сварщик (НАКС / Техкарты)',
  'Инженер ПТО (Реестр стыков и сводка)',
  'Производитель работ СМР (Участок №1)',
  'Производитель работ СМР (Участок №2)',
  'Инженер СК / ВИК (Строительный контроль)',
  'Дефектоскопист ЛНК (РК / УЗК / ПВК)',
  'Инженер по комплектации ИД (Печать журналов)',
];

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  accounts,
  onAuthenticate,
  onRegisterAccount,
  onDeleteAccount,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [login, setLogin] = useState(currentUser.login);
  const [password, setPassword] = useState('123');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState(ROLE_PRESETS[4]);
  const [department, setDepartment] = useState('Производственно-технический отдел');
  const [errorMsg, setErrorMsg] = useState('');
  const [confirmDeleteLogin, setConfirmDeleteLogin] = useState<string | null>(null);

  if (!isOpen) return null;

  const getNextSessionNumber = () => {
    const maxSession = accounts.reduce(
      (max, acc) => Math.max(max, acc.sessionNumber || 0),
      30
    );
    return maxSession + 1;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanLogin = login.trim();
    const cleanPassword = password.trim();

    if (!cleanLogin || !cleanPassword) {
      setErrorMsg('Введите пару логин и пароль для входа в систему');
      return;
    }

    if (mode === 'register') {
      if (cleanPassword.length < 3) {
        setErrorMsg('Пароль должен содержать не менее 3 символов');
        return;
      }
      if (!fullName.trim()) {
        setErrorMsg('Укажите ФИО регистрируемого специалиста');
        return;
      }
      const existing = accounts.find(
        (a) => a.login.toLowerCase() === cleanLogin.toLowerCase()
      );
      if (existing) {
        setErrorMsg(`Логин «${cleanLogin}» уже зарегистрирован в системе`);
        return;
      }

      const newAcc: UserAccount = {
        login: cleanLogin,
        password: cleanPassword,
        fullName: fullName.trim(),
        role: role.trim() || 'Инженер ПТО / СМР',
        department: department.trim() || 'Производственно-технический отдел',
        sessionNumber: getNextSessionNumber(),
      };

      setErrorMsg('');
      onRegisterAccount?.(newAcc);
      onAuthenticate(newAcc);
      onClose();
      return;
    }

    const found = accounts.find(
      (a) =>
        a.login.toLowerCase() === cleanLogin.toLowerCase() &&
        a.password === cleanPassword
    );

    if (found) {
      setErrorMsg('');
      onAuthenticate(found);
      onClose();
    } else {
      // Если введён новый корпоративный логин с паролем >= 3 символов — автоматически регистрируем в пуле
      if (cleanPassword.length >= 3) {
        const autoAcc: UserAccount = {
          login: cleanLogin,
          password: cleanPassword,
          fullName: fullName.trim() || `Инженер (${cleanLogin})`,
          role: role.trim() || 'Инженер ПТО / СМР',
          department: department.trim() || 'Производственно-технический отдел',
          sessionNumber: getNextSessionNumber(),
        };
        setErrorMsg('');
        onRegisterAccount?.(autoAcc);
        onAuthenticate(autoAcc);
        onClose();
      } else {
        setErrorMsg(
          'Неверный логин или пароль (тестовый пароль для учётных записей: 123)'
        );
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Авторизация и регистрация пользователей"
    >
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-[1px]"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        <div className="px-6 py-4 bg-[#1e3799] text-white flex items-center justify-between shrink-0">
          <ZaychickLogo variant="header" size={34} />
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть окно входа"
            className="p-1.5 rounded-lg text-sky-100 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                Многопользовательский доступ «ZAYCHICK»
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Все действия протоколируются в журнале аудита под личным логином и ролью
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg('');
              }}
              className={`py-1.5 px-3 rounded-md text-xs font-semibold transition-colors ${
                mode === 'login'
                  ? 'bg-[#1e3799] text-white shadow-2xs'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Вход по логину
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setLogin('');
                setPassword('123');
                setFullName('');
                setErrorMsg('');
              }}
              className={`py-1.5 px-3 rounded-md text-xs font-semibold transition-colors ${
                mode === 'register'
                  ? 'bg-[#1e3799] text-white shadow-2xs'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Регистрация специалиста
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Логин пользователя *
              </label>
              <input
                type="text"
                required
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                placeholder="Напр.: morozov_ig"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#1e3799] focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Пароль *
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Введите пароль (123)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#1e3799] focus:bg-white"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div className="space-y-3 pt-1 border-t border-slate-200">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ФИО специалиста (для журналов и аудита) *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Напр.: Морозов Игорь Геннадьевич"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#1e3799] focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Должность / Роль в системе
                  </label>
                  <input
                    type="text"
                    list="role-presets-list"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="Выберите или введите должность"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#1e3799] focus:bg-white"
                  />
                  <datalist id="role-presets-list">
                    {ROLE_PRESETS.map((r) => (
                      <option key={r} value={r} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Подразделение / Служба
                  </label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="Напр.: Лаборатория НК (ЛНК)"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#1e3799] focus:bg-white"
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#1e3799] text-white text-xs font-semibold hover:bg-[#15276e] transition-colors"
          >
            {mode === 'register' ? (
              <>
                <UserPlus className="w-4 h-4" />
                <span>Зарегистрировать и войти в сессию</span>
              </>
            ) : (
              <>
                <KeyRound className="w-4 h-4" />
                <span>Войти по логину и паролю</span>
              </>
            )}
          </button>

          {/* Быстрый выбор и удаление учётной записи для совместной работы специалистов */}
          <div className="pt-3 border-t border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500">
              <span>Зарегистрированные специалисты ({accounts.length} чел.):</span>
              <span className="font-mono">Пароль по умолч.: 123</span>
            </div>
            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
              {accounts.map((acc) => {
                const isCurrent = acc.login === currentUser.login;
                const isConfirming = confirmDeleteLogin === acc.login;
                return (
                  <div
                    key={acc.login}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-left text-xs transition-colors ${
                      isCurrent
                        ? 'bg-[#e8f1fc] border-[#1e3799] text-[#1e3799]'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setLogin(acc.login);
                        setPassword(acc.password);
                        onAuthenticate(acc);
                        onClose();
                      }}
                      className="flex-1 text-left min-w-0 pr-2"
                    >
                      <div className="font-semibold truncate">{acc.fullName}</div>
                      <div className="text-[11px] text-slate-500 truncate">
                        Логин: <span className="font-mono">{acc.login}</span> · {acc.role}
                      </div>
                    </button>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {!isConfirming ? (
                        <>
                          <span className="font-mono text-[10px] text-slate-500">
                            Сессия #{acc.sessionNumber}
                          </span>
                          {onDeleteAccount && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (accounts.length <= 1) {
                                  setErrorMsg(
                                    'Нельзя удалить единственную оставшуюся учётную запись в системе.'
                                  );
                                  return;
                                }
                                setConfirmDeleteLogin(acc.login);
                              }}
                              title={`Удалить пользователя ${acc.fullName}`}
                              aria-label={`Удалить пользователя ${acc.fullName}`}
                              className="p-1.5 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </>
                      ) : (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteAccount?.(acc.login);
                              setConfirmDeleteLogin(null);
                            }}
                            className="px-2 py-1 rounded bg-red-600 text-white text-[11px] font-bold hover:bg-red-700"
                          >
                            Удалить
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmDeleteLogin(null);
                            }}
                            className="px-2 py-1 rounded bg-white border border-slate-300 text-slate-700 text-[11px] font-semibold"
                          >
                            Отмена
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-[#1e3799]" />
              <span>Активных сессий в пуле: {Math.max(32, accounts.length + 28)}</span>
            </span>
            <span className="font-mono">СУБД: до 100 000 строк</span>
          </div>
        </form>
      </div>
    </div>
  );
};
