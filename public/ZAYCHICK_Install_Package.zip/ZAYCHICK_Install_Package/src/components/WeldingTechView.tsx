import React, { useState } from 'react';
import {
  Award,
  Check,
  Edit3,
  FileCheck2,
  Flame,
  PackageCheck,
  Plus,
  ShieldCheck,
  ThermometerSnowflake,
  Trash2,
  Users,
  Wrench,
  X,
} from 'lucide-react';
import {
  PreheatRegimeRule,
  TechCardItem,
  WelderProfile,
  WeldingMaterialCertificate,
  WeldingType,
} from '../types/welding';
import { formatDateDDMMYY } from '../utils/weldingLogic';
import {
  applyTableColumnFiltersAndSort,
  TableColumnFilterHeader,
} from './TableColumnFilterPopover';

interface WeldingTechViewProps {
  welders: WelderProfile[];
  onSaveWelder: (welder: WelderProfile) => void;
  onDeleteWelder?: (stamp: string) => void;
  techCards: TechCardItem[];
  onSaveTechCard: (card: TechCardItem) => void;
  onDeleteTechCard?: (id: string) => void;
  materials: WeldingMaterialCertificate[];
  onSaveMaterial: (material: WeldingMaterialCertificate) => void;
  onDeleteMaterial?: (id: string) => void;
}

type TechTab = 'welders' | 'tech_cards' | 'materials';

export const WeldingTechView: React.FC<WeldingTechViewProps> = ({
  welders,
  onSaveWelder,
  onDeleteWelder,
  techCards,
  onSaveTechCard,
  onDeleteTechCard,
  materials,
  onSaveMaterial,
  onDeleteMaterial,
}) => {
  const [activeTab, setActiveTab] = useState<TechTab>('welders');
  const [confirmDeleteWelderStamp, setConfirmDeleteWelderStamp] = useState<
    string | null
  >(null);
  const [confirmDeleteTcId, setConfirmDeleteTcId] = useState<string | null>(null);
  const [confirmDeleteMatId, setConfirmDeleteMatId] = useState<string | null>(null);

  // Excel-фильтры для таблиц сварщиков и сварочных материалов
  const [welderFilters, setWelderFilters] = useState<Record<string, string[]>>({});
  const [welderSort, setWelderSort] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  } | null>(null);

  const [materialFilters, setMaterialFilters] = useState<Record<string, string[]>>({});
  const [materialSort, setMaterialSort] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  } | null>(null);

  const welderGetters: Record<string, (w: WelderProfile) => string> = {
    stamp: (w) => w.stamp,
    type: (w) =>
      w.isBrigade
        ? `Бригада (${(w.brigadeMembers || []).join(', ')})`
        : 'Личное клеймо',
    fullName: (w) => w.fullName,
    certNumber: (w) => w.certNumber,
    dates: (w) =>
      `${formatDateDDMMYY(w.certIssueDate) || '—'} — ${
        formatDateDDMMYY(w.certExpiryDate) || '—'
      }`,
    attestationArea: (w) => w.attestationArea || w.allowedMethods.join(', '),
    admissionSheet: (w) =>
      `${w.admissionSheetNumber || '—'}${
        w.admissionSheetDate ? ` от ${formatDateDDMMYY(w.admissionSheetDate)}` : ''
      }`,
    crewForeman: (w) => w.crewForeman,
  };

  const filteredWelders = applyTableColumnFiltersAndSort(
    welders,
    welderFilters,
    welderGetters,
    welderSort
  );

  const handleApplyWelderFilter = (colKey: string, vals: string[] | undefined) => {
    setWelderFilters((prev) => {
      const next = { ...prev };
      if (vals === undefined) delete next[colKey];
      else next[colKey] = vals;
      return next;
    });
  };

  const materialGetters: Record<string, (m: WeldingMaterialCertificate) => string> = {
    brandAndDiameter: (m) => m.brandAndDiameter,
    materialType: (m) => m.materialType,
    weldingMethod: (m) => m.weldingMethod,
    batchNumber: (m) => m.batchNumber,
    certificateNumber: (m) => m.certificateNumber,
    incomingControlAct: (m) => m.incomingControlAct,
    incomingControlDate: (m) => formatDateDDMMYY(m.incomingControlDate),
    status: (m) => m.status,
  };

  const filteredMaterials = applyTableColumnFiltersAndSort(
    materials,
    materialFilters,
    materialGetters,
    materialSort
  );

  const handleApplyMaterialFilter = (colKey: string, vals: string[] | undefined) => {
    setMaterialFilters((prev) => {
      const next = { ...prev };
      if (vals === undefined) delete next[colKey];
      else next[colKey] = vals;
      return next;
    });
  };

  // Модальное окно сварщика / бригады
  const [welderModal, setWelderModal] = useState<{
    isOpen: boolean;
    isBrigade: boolean;
    item: WelderProfile | null;
  }>({ isOpen: false, isBrigade: false, item: null });

  const [welderForm, setWelderForm] = useState<WelderProfile>({
    id: '',
    stamp: '',
    isBrigade: false,
    brigadeMembers: [],
    fullName: '',
    certNumber: '',
    certIssueDate: '2025-05-10',
    certExpiryDate: '2027-05-10',
    attestationArea: 'РАД, РД · НГДО (п. 3, 4) · М01 · Ø57–530 мм, S 4.0–20.0 мм',
    admissionSheetNumber: 'ДЛ-045/26-030',
    admissionSheetDate: '2026-10-10',
    allowedMethods: ['РАД', 'РД', 'РАД+РД'],
    crewForeman: 'Мастер СМР Громов И.А.',
  });

  // Модальное окно технологической карты (ТК)
  const [tcModal, setTcModal] = useState<{
    isOpen: boolean;
    item: TechCardItem | null;
  }>({ isOpen: false, item: null });

  const [tcForm, setTcForm] = useState<TechCardItem>({
    id: '',
    number: '',
    title: '',
    weldingType: 'РАД+РД',
    ntd: 'СТО Газпром 15-1.1-002-2023',
    steelGroup: 'М01 (09Г2С, Ст20)',
    minDiameterMm: 57,
    maxDiameterMm: 325,
    minWallThicknessMm: 4,
    maxWallThicknessMm: 16,
    recommendedMaterials: 'Св-08Г2С Ø2.0 / УОНИ-13/55 Ø3.0',
    preheatRules: [
      {
        ambientMinC: -60,
        ambientMaxC: -5,
        minPreheatTempC: 150,
        conditionLabel: 'При T возд. ниже -5 °C: подогрев ≥ +150 °C',
      },
      {
        ambientMinC: -4.9,
        ambientMaxC: 5,
        minPreheatTempC: 100,
        conditionLabel: 'При T возд. от -5 °C до +5 °C: подогрев ≥ +100 °C',
      },
      {
        ambientMinC: 5.1,
        ambientMaxC: 50,
        minPreheatTempC: 0,
        conditionLabel: 'При T возд. выше +5 °C: подогрев не требуется',
      },
    ],
  });

  // Модальное окно сварочных материалов и ВК
  const [matModal, setMatModal] = useState<{
    isOpen: boolean;
    item: WeldingMaterialCertificate | null;
  }>({ isOpen: false, item: null });

  const [matForm, setMatForm] = useState<WeldingMaterialCertificate>({
    id: '',
    brandAndDiameter: '',
    materialType: 'Комбинированный комплект (РАД+РД)',
    weldingMethod: 'РАД+РД',
    batchNumber: '',
    certificateNumber: '',
    incomingControlAct: '',
    incomingControlDate: '2026-10-12',
    status: 'Допущен в производство',
  });

  const personalWelders = welders.filter((w) => !w.isBrigade);

  const openWelderModal = (item: WelderProfile | null, isBrigade = false) => {
    setModalError('');
    if (item) {
      setWelderForm({
        ...item,
        brigadeMembers: item.brigadeMembers || [],
      });
      setWelderModal({ isOpen: true, isBrigade: Boolean(item.isBrigade), item });
    } else {
      setWelderForm({
        id: `w-${Date.now()}`,
        stamp: isBrigade ? 'БР-03' : '',
        isBrigade,
        brigadeMembers: [],
        fullName: '',
        certNumber: '',
        certIssueDate: '2025-05-15',
        certExpiryDate: '2027-05-15',
        attestationArea: isBrigade
          ? 'Бригадное клеймо (РАД+РД · М01 · Ø159–530 мм)'
          : 'РАД, РД · НГДО (п. 3, 4) · М01 · Ø57–426 мм, S 4.0–18.0 мм',
        admissionSheetNumber: isBrigade ? 'ДЛ-045/26-Б03' : 'ДЛ-045/26-035',
        admissionSheetDate: '2026-10-10',
        allowedMethods: ['РАД', 'РД', 'РАД+РД'],
        crewForeman: 'Мастер СМР Громов И.А.',
      });
      setWelderModal({ isOpen: true, isBrigade, item: null });
    }
  };

  const toggleBrigadeMemberInForm = (stamp: string) => {
    const current = welderForm.brigadeMembers || [];
    const next = current.includes(stamp)
      ? current.filter((s) => s !== stamp)
      : [...current, stamp];
    const members = next
      .map((st) => personalWelders.find((w) => w.stamp === st))
      .filter((w): w is WelderProfile => Boolean(w));

    setWelderForm((prev) => ({
      ...prev,
      brigadeMembers: next,
      fullName: members.map((m) => m.fullName).join(', '),
      certNumber: members.map((m) => m.certNumber).join(', '),
      crewForeman: members[0]?.crewForeman || prev.crewForeman,
    }));
  };

  const [modalError, setModalError] = useState('');

  const handleWelderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    const cleanStamp = welderForm.stamp.trim();
    if (!cleanStamp) {
      setModalError('Укажите личное или бригадное клеймо.');
      return;
    }

    // Проверка на дубликат клейма при создании или изменении клейма сварщика
    if (
      welders.some(
        (w) =>
          w.id !== welderForm.id &&
          w.stamp.trim().toLowerCase() === cleanStamp.toLowerCase()
      )
    ) {
      setModalError(
        `Клеймо «${cleanStamp}» уже зарегистрировано в справочнике. Дублирование клейм запрещено.`
      );
      return;
    }

    // Проверка хронологии дат удостоверения НАКС
    if (
      welderForm.certIssueDate &&
      welderForm.certExpiryDate &&
      welderForm.certExpiryDate < welderForm.certIssueDate
    ) {
      setModalError(
        'Дата окончания удостоверения НАКС не может быть раньше даты выдачи.'
      );
      return;
    }

    if (
      welderForm.certIssueDate &&
      welderForm.admissionSheetDate &&
      welderForm.admissionSheetDate < welderForm.certIssueDate
    ) {
      setModalError(
        'Дата допускного листа не может быть раньше даты выдачи удостоверения НАКС.'
      );
      return;
    }

    onSaveWelder({
      ...welderForm,
      stamp: cleanStamp,
    });
    setWelderModal({ isOpen: false, isBrigade: false, item: null });
  };

  const openTcModal = (item: TechCardItem | null) => {
    setModalError('');
    if (item) {
      setTcForm({
        ...item,
        preheatRules: item.preheatRules.map((r) => ({ ...r })),
      });
      setTcModal({ isOpen: true, item });
    } else {
      setTcForm({
        id: `tc-${Date.now()}`,
        number: 'ТК-045-РАД/РД-05',
        title: 'Сварка технологических трубопроводов из стали 09Г2С',
        weldingType: 'РАД+РД',
        ntd: 'СТО Газпром 15-1.1-002-2023',
        steelGroup: 'М01 (09Г2С, 09Г2С-15)',
        minDiameterMm: 89,
        maxDiameterMm: 325,
        minWallThicknessMm: 5,
        maxWallThicknessMm: 16,
        recommendedMaterials: 'Св-08Г2С Ø2.0 / УОНИ-13/55 Ø3.0',
        preheatRules: [
          {
            ambientMinC: -60,
            ambientMaxC: -5,
            minPreheatTempC: 150,
            conditionLabel: 'При T возд. ниже -5 °C: подогрев ≥ +150 °C',
          },
          {
            ambientMinC: -4.9,
            ambientMaxC: 5,
            minPreheatTempC: 100,
            conditionLabel: 'При T возд. от -5 °C до +5 °C: подогрев ≥ +100 °C',
          },
          {
            ambientMinC: 5.1,
            ambientMaxC: 50,
            minPreheatTempC: 0,
            conditionLabel: 'При T возд. выше +5 °C: подогрев не требуется',
          },
        ],
      });
      setTcModal({ isOpen: true, item: null });
    }
  };

  const updatePreheatRule = (
    idx: number,
    patch: Partial<PreheatRegimeRule>
  ) => {
    setTcForm((prev) => {
      const nextRules = prev.preheatRules.map((r, i) => {
        if (i !== idx) return r;
        const updated = { ...r, ...patch };
        updated.conditionLabel =
          updated.minPreheatTempC > 0
            ? `При T возд. от ${updated.ambientMinC} °C до ${updated.ambientMaxC} °C: подогрев ≥ +${updated.minPreheatTempC} °C`
            : `При T возд. от ${updated.ambientMinC} °C до ${updated.ambientMaxC} °C: подогрев не требуется`;
        return updated;
      });
      return { ...prev, preheatRules: nextRules };
    });
  };

  const handleTcSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    const cleanNum = tcForm.number.trim();
    if (!cleanNum) {
      setModalError('Укажите номер (шифр) технологической карты.');
      return;
    }

    if (
      !tcModal.item &&
      techCards.some((t) => t.number.trim().toLowerCase() === cleanNum.toLowerCase())
    ) {
      setModalError(`Технологическая карта «${cleanNum}» уже существует.`);
      return;
    }

    if (
      tcForm.minDiameterMm < 10 ||
      tcForm.maxDiameterMm > 2520 ||
      tcForm.minDiameterMm > tcForm.maxDiameterMm
    ) {
      setModalError(
        'Минимальный диаметр должен быть от 10 мм и не превышать максимальный диаметр (до 2520 мм).'
      );
      return;
    }

    if (
      tcForm.minWallThicknessMm < 1 ||
      tcForm.maxWallThicknessMm > 150 ||
      tcForm.minWallThicknessMm > tcForm.maxWallThicknessMm
    ) {
      setModalError(
        'Минимальная толщина стенки должна быть от 1 мм и не превышать максимальную толщину (до 150 мм).'
      );
      return;
    }

    onSaveTechCard({
      ...tcForm,
      number: cleanNum,
    });
    setTcModal({ isOpen: false, item: null });
  };

  const openMatModal = (item: WeldingMaterialCertificate | null) => {
    setModalError('');
    if (item) {
      setMatForm({ ...item });
      setMatModal({ isOpen: true, item });
    } else {
      setMatForm({
        id: `wm-${Date.now()}`,
        brandAndDiameter: 'Св-08Г2С Ø2.0 / LB-52U Ø2.6',
        materialType: 'Комбинированный комплект (РАД+РД)',
        weldingMethod: 'РАД+РД',
        batchNumber: 'Пл. 71902 / Партия 114',
        certificateNumber: 'Серт. № НАКС-СМ-9820',
        incomingControlAct: 'Акт ВК № 175/26-СМ',
        incomingControlDate: '2026-10-15',
        status: 'Допущен в производство',
      });
      setMatModal({ isOpen: true, item: null });
    }
  };

  const handleMatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    if (!matForm.brandAndDiameter.trim()) {
      setModalError('Укажите марку и диаметр сварочного материала.');
      return;
    }
    onSaveMaterial({
      ...matForm,
      brandAndDiameter: matForm.brandAndDiameter.trim(),
    });
    setMatModal({ isOpen: false, item: null });
  };

  return (
    <div className="space-y-4">
      {/* Верхняя панель с переключателями 3 подразделов технологии сварки */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-[#1e3799] font-bold text-sm">
            <Wrench className="w-4 h-4" />
            <span>
              Технология сварочного производства — Сварщики (НАКС), Технологические карты (ТК) и Сварочные материалы
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Автоподстановка ФИО и удостоверений по клейму (включая бригадные клейма) · Контроль температуры подогрева по ТК · Сертификаты и входной контроль СМ
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('welders')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'welders'
                ? 'bg-[#1e3799] text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Сварщики и бригады ({welders.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tech_cards')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'tech_cards'
                ? 'bg-[#1e3799] text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Технологические карты ТК ({techCards.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('materials')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'materials'
                ? 'bg-[#1e3799] text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5" />
            <span>Сварочные материалы и ВК ({materials.length})</span>
          </button>
        </div>
      </div>

      {/* ВКЛАДКА 1: СВАРЩИКИ И БРИГАДНЫЕ КЛЕЙМА */}
      {activeTab === 'welders' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70">
            <div>
              <h3 className="text-xs font-bold text-slate-900">
                Реестр аттестованных сварщиков (НАКС), допускных листов и бригадных клейм
              </h3>
              <p className="text-[11px] text-slate-500">
                При выборе клейма (или нескольких сварщиков / бригадного клейма) в Паспорте стыка ФИО и номера удостоверений подтягиваются автоматически
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => openWelderModal(null, true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#1e3799] text-[#1e3799] bg-sky-50 hover:bg-sky-100 text-xs font-semibold transition-colors"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Создать бригадное клеймо</span>
              </button>
              <button
                type="button"
                onClick={() => openWelderModal(null, false)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1e3799] text-white hover:bg-[#15276e] text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Добавить сварщика</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto min-h-[340px]">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-[#1e3799] text-white text-xs">
                  <TableColumnFilterHeader
                    columnKey="stamp"
                    label="Клеймо"
                    rows={welders}
                    getValue={welderGetters.stamp}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="type"
                    label="Тип"
                    rows={welders}
                    getValue={welderGetters.type}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="fullName"
                    label="ФИО сварщика / Состав бригады"
                    rows={welders}
                    getValue={welderGetters.fullName}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="certNumber"
                    label="№ удостоверения НАКС"
                    rows={welders}
                    getValue={welderGetters.certNumber}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="dates"
                    label="Дата выдачи / Срок"
                    rows={welders}
                    getValue={welderGetters.dates}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="attestationArea"
                    label="Область аттестации"
                    rows={welders}
                    getValue={welderGetters.attestationArea}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="admissionSheet"
                    label="Допускной лист (№ и дата)"
                    rows={welders}
                    getValue={welderGetters.admissionSheet}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="crewForeman"
                    label="Мастер / Прораб"
                    rows={welders}
                    getValue={welderGetters.crewForeman}
                    activeFilters={welderFilters}
                    onApplyFilter={handleApplyWelderFilter}
                    sortConfig={welderSort}
                    onSort={(k, dir) => setWelderSort({ key: k, direction: dir })}
                  />
                  <th className="py-2.5 px-3 font-semibold text-center">Действие</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredWelders.map((w) => (
                  <tr key={w.stamp} className="hover:bg-sky-50/40">
                    <td className="py-2.5 px-3 font-mono font-bold text-[#1e3799]">
                      {w.stamp}
                    </td>
                    <td className="py-2.5 px-3">
                      {w.isBrigade ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-300 font-semibold text-[11px]">
                          Бригада ({(w.brigadeMembers || []).join(', ')})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-sky-50 text-[#1e3799] border border-sky-200 font-medium text-[11px]">
                          Личное клеймо
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {w.fullName}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-800">
                      {w.certNumber}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700 whitespace-nowrap">
                      {formatDateDDMMYY(w.certIssueDate) || '—'} —{' '}
                      <span className="font-semibold text-emerald-700">
                        {formatDateDDMMYY(w.certExpiryDate) || '—'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-700 max-w-xs">
                      {w.attestationArea || w.allowedMethods.join(', ')}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-800 whitespace-nowrap">
                      {w.admissionSheetNumber || '—'}{' '}
                      {w.admissionSheetDate
                        ? `от ${formatDateDDMMYY(w.admissionSheetDate)}`
                        : ''}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700">{w.crewForeman}</td>
                    <td className="py-2.5 px-3 text-center whitespace-nowrap">
                      {confirmDeleteWelderStamp === w.stamp ? (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteWelder?.(w.stamp);
                              setConfirmDeleteWelderStamp(null);
                            }}
                            className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold hover:bg-red-700"
                          >
                            Удалить
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteWelderStamp(null)}
                            className="px-1.5 py-0.5 rounded border border-slate-300 text-slate-600 text-[10px]"
                          >
                            Отмена
                          </button>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openWelderModal(w, Boolean(w.isBrigade))}
                            className="p-1.5 rounded text-slate-500 hover:text-[#1e3799] hover:bg-sky-50"
                            title="Редактировать данные сварщика / бригады"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          {onDeleteWelder && (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteWelderStamp(w.stamp)}
                              className="p-1.5 rounded text-slate-400 hover:text-red-600 hover:bg-red-50"
                              title={`Удалить сварщика / бригаду «${w.stamp}»`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ВКЛАДКА 2: ТЕХНОЛОГИЧЕСКИЕ КАРТЫ (ТК) И РЕЖИМЫ ПОДОГРЕВА */}
      {activeTab === 'tech_cards' && (
        <div className="space-y-3">
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-xs font-bold text-slate-900">
                Технологические карты на сварку (ТК) — Параметры свариваемых элементов, сварочные материалы и режимы подогрева
              </h3>
              <p className="text-[11px] text-slate-500">
                В Паспорте стыка выбор ТК выполняется из выпадающего списка, а введённая вручную температура подогрева автоматически проверяется по правилам выбранной ТК
              </p>
            </div>
            <button
              type="button"
              onClick={() => openTcModal(null)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1e3799] text-white hover:bg-[#15276e] text-xs font-semibold transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Добавить технологическую карту (ТК)</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
            {techCards.map((tc) => (
              <div
                key={tc.id}
                className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="px-4 py-3 bg-[#1e3799] text-white flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Flame className="w-4 h-4 text-amber-300 shrink-0" />
                      <span className="font-mono font-bold text-sm truncate">
                        {tc.number}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-white/15 text-[11px] font-mono">
                        {tc.weldingType}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => openTcModal(tc)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white/15 hover:bg-white/25 text-xs font-medium"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Изменить</span>
                      </button>
                      {onDeleteTechCard &&
                        (confirmDeleteTcId === tc.id ? (
                          <div className="inline-flex items-center gap-1 bg-white/95 px-2 py-0.5 rounded">
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteTechCard(tc.id);
                                setConfirmDeleteTcId(null);
                              }}
                              className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold hover:bg-red-700"
                            >
                              Удалить ТК
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteTcId(null)}
                              className="px-1.5 py-0.5 rounded text-slate-700 text-[10px] font-semibold"
                            >
                              Отмена
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteTcId(tc.id)}
                            className="p-1.5 rounded bg-white/15 hover:bg-red-600 text-white transition-colors"
                            title={`Удалить техкарту «${tc.number}»`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        ))}
                    </div>
                  </div>

                  <div className="p-4 space-y-3 text-xs">
                    <div className="font-semibold text-slate-900">{tc.title}</div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200/80">
                      <div>
                        <div className="text-[10px] text-slate-500">Диаметры элементов</div>
                        <div className="font-mono font-bold text-[#1e3799]">
                          Ø {tc.minDiameterMm} – {tc.maxDiameterMm} мм
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500">Толщины стенки S</div>
                        <div className="font-mono font-bold text-[#1e3799]">
                          {tc.minWallThicknessMm} – {tc.maxWallThicknessMm} мм
                        </div>
                      </div>
                      <div className="col-span-2 sm:col-span-1">
                        <div className="text-[10px] text-slate-500">Группа сталей / НТД</div>
                        <div className="font-medium text-slate-800 truncate" title={tc.steelGroup}>
                          {tc.steelGroup}
                        </div>
                      </div>
                    </div>

                    <div>
                      <span className="text-slate-500">Применяемые сварочные материалы: </span>
                      <span className="font-mono font-semibold text-slate-900">
                        {tc.recommendedMaterials}
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#1e3799]">
                        <ThermometerSnowflake className="w-3.5 h-3.5" />
                        <span>Режимы подогрева в зависимости от температуры воздуха:</span>
                      </div>
                      <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg overflow-hidden">
                        {tc.preheatRules.map((rule, idx) => (
                          <div
                            key={idx}
                            className="px-3 py-1.5 bg-sky-50/40 flex items-center justify-between gap-2 text-[11px]"
                          >
                            <span className="text-slate-700 font-mono">
                              T возд.: от {rule.ambientMinC > 0 ? `+${rule.ambientMinC}` : rule.ambientMinC} °C до{' '}
                              {rule.ambientMaxC > 0 ? `+${rule.ambientMaxC}` : rule.ambientMaxC} °C
                            </span>
                            <span
                              className={`font-mono font-bold px-2 py-0.5 rounded ${
                                rule.minPreheatTempC > 0
                                  ? 'bg-amber-100 text-amber-900'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {rule.minPreheatTempC > 0
                                ? `Подогрев ≥ +${rule.minPreheatTempC} °C`
                                : 'Не требуется'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ВКЛАДКА 3: СВАРОЧНЫЕ МАТЕРИАЛЫ, СЕРТИФИКАТЫ И ВХОДНОЙ КОНТРОЛЬ */}
      {activeTab === 'materials' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70">
            <div>
              <h3 className="text-xs font-bold text-slate-900">
                Перечень сварочных материалов с номерами сертификатов и датами проведения входного контроля (ВК)
              </h3>
              <p className="text-[11px] text-slate-500">
                Все даты проведения входного контроля отображаются строго в формате ДД.ММ.ГГ
              </p>
            </div>
            <button
              type="button"
              onClick={() => openMatModal(null)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1e3799] text-white hover:bg-[#15276e] text-xs font-semibold transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Добавить сварочный материал</span>
            </button>
          </div>

          <div className="overflow-x-auto min-h-[340px]">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-[#1e3799] text-white text-xs">
                  <TableColumnFilterHeader
                    columnKey="brandAndDiameter"
                    label="Марка и диаметр СМ"
                    rows={materials}
                    getValue={materialGetters.brandAndDiameter}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="materialType"
                    label="Вид материалов"
                    rows={materials}
                    getValue={materialGetters.materialType}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="weldingMethod"
                    label="Способ сварки"
                    rows={materials}
                    getValue={materialGetters.weldingMethod}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="batchNumber"
                    label="Партия / Плавка"
                    rows={materials}
                    getValue={materialGetters.batchNumber}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="certificateNumber"
                    label="№ сертификата качества"
                    rows={materials}
                    getValue={materialGetters.certificateNumber}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="incomingControlAct"
                    label="Акт входного контроля"
                    rows={materials}
                    getValue={materialGetters.incomingControlAct}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="incomingControlDate"
                    label="Дата ВК (ДД.ММ.ГГ)"
                    rows={materials}
                    getValue={materialGetters.incomingControlDate}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <TableColumnFilterHeader
                    columnKey="status"
                    label="Статус"
                    rows={materials}
                    getValue={materialGetters.status}
                    activeFilters={materialFilters}
                    onApplyFilter={handleApplyMaterialFilter}
                    sortConfig={materialSort}
                    onSort={(k, dir) => setMaterialSort({ key: k, direction: dir })}
                  />
                  <th className="py-2.5 px-3 font-semibold text-center">Действие</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredMaterials.map((m) => (
                  <tr key={m.id} className="hover:bg-sky-50/40">
                    <td className="py-2.5 px-3 font-mono font-bold text-[#1e3799]">
                      {m.brandAndDiameter}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700">{m.materialType}</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-800">
                      {m.weldingMethod}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">{m.batchNumber}</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                      {m.certificateNumber}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">
                      {m.incomingControlAct}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-[#1e3799]">
                      {formatDateDDMMYY(m.incomingControlDate)}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold text-[11px]">
                        <ShieldCheck className="w-3 h-3" />
                        {m.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center whitespace-nowrap">
                      {confirmDeleteMatId === m.id ? (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteMaterial?.(m.id);
                              setConfirmDeleteMatId(null);
                            }}
                            className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold hover:bg-red-700"
                          >
                            Удалить
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteMatId(null)}
                            className="px-1.5 py-0.5 rounded border border-slate-300 text-slate-600 text-[10px]"
                          >
                            Отмена
                          </button>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openMatModal(m)}
                            className="p-1.5 rounded text-slate-500 hover:text-[#1e3799] hover:bg-sky-50"
                            title="Редактировать запись сварочного материала"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          {onDeleteMaterial && (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteMatId(m.id)}
                              className="p-1.5 rounded text-slate-400 hover:text-red-600 hover:bg-red-50"
                              title={`Удалить сварочный материал «${m.brandAndDiameter}»`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* МОДАЛЬНОЕ ОКНО СВАРЩИКА / БРИГАДНОГО КЛЕЙМА */}
      {welderModal.isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Данные сварщика или бригадного клейма"
        >
          <div
            className="fixed inset-0 bg-slate-900/45 backdrop-blur-[1px]"
            onClick={() => setWelderModal({ isOpen: false, isBrigade: false, item: null })}
          />
          <div className="relative z-10 w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-[#1e3799] text-white">
              <div className="flex items-center gap-2.5">
                <Award className="w-5 h-5 text-sky-300" />
                <h2 className="text-sm font-bold">
                  {welderModal.isBrigade
                    ? 'Формирование / Редактирование бригадного клейма'
                    : 'Карточка аттестации сварщика (НАКС и допускной лист)'}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setWelderModal({ isOpen: false, isBrigade: false, item: null })}
                className="p-1 rounded text-sky-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleWelderSubmit} className="p-6 space-y-4 text-xs">
              {modalError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-300 text-red-800 text-xs font-semibold">
                  {modalError}
                </div>
              )}
              {welderModal.isBrigade && (
                <div className="p-3 rounded-lg bg-[#e8f1fc] border border-sky-200 space-y-2">
                  <div className="font-bold text-[#1e3799]">
                    Выберите сварщиков, входящих в состав бригады (ФИО и удостоверения объединятся автоматически):
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {personalWelders.map((pw) => {
                      const checked = (welderForm.brigadeMembers || []).includes(pw.stamp);
                      return (
                        <button
                          key={pw.stamp}
                          type="button"
                          onClick={() => toggleBrigadeMemberInForm(pw.stamp)}
                          className={`px-2.5 py-1.5 rounded-md border font-mono text-xs transition-colors ${
                            checked
                              ? 'bg-[#1e3799] text-white border-[#1e3799] font-bold'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          {pw.stamp} · {pw.fullName}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {welderModal.isBrigade ? 'Бригадное клеймо *' : 'Личное клеймо сварщика *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={welderForm.stamp}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, stamp: e.target.value }))
                    }
                    placeholder={welderModal.isBrigade ? 'БР-01' : 'А142'}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono font-bold text-[#1e3799]"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">
                    ФИО сварщика (или состав бригады) *
                  </label>
                  <input
                    type="text"
                    required
                    value={welderForm.fullName}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, fullName: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    № удостоверения НАКС *
                  </label>
                  <input
                    type="text"
                    required
                    value={welderForm.certNumber}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, certNumber: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="flex justify-between font-medium text-slate-700 mb-1">
                    <span>Дата выдачи</span>
                    <span className="font-mono text-[#1e3799]">
                      {formatDateDDMMYY(welderForm.certIssueDate)}
                    </span>
                  </label>
                  <input
                    type="date"
                    value={welderForm.certIssueDate || ''}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, certIssueDate: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="flex justify-between font-medium text-slate-700 mb-1">
                    <span>Срок действия до</span>
                    <span className="font-mono text-[#1e3799]">
                      {formatDateDDMMYY(welderForm.certExpiryDate)}
                    </span>
                  </label>
                  <input
                    type="date"
                    value={welderForm.certExpiryDate || ''}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, certExpiryDate: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Область аттестации (способ сварки, группа сталей, диапазон диаметров и толщин)
                </label>
                <input
                  type="text"
                  value={welderForm.attestationArea || ''}
                  onChange={(e) =>
                    setWelderForm((prev) => ({ ...prev, attestationArea: e.target.value }))
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    № допускного листа
                  </label>
                  <input
                    type="text"
                    value={welderForm.admissionSheetNumber || ''}
                    onChange={(e) =>
                      setWelderForm((prev) => ({
                        ...prev,
                        admissionSheetNumber: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="flex justify-between font-medium text-slate-700 mb-1">
                    <span>Дата допускного листа</span>
                    <span className="font-mono text-[#1e3799]">
                      {formatDateDDMMYY(welderForm.admissionSheetDate)}
                    </span>
                  </label>
                  <input
                    type="date"
                    value={welderForm.admissionSheetDate || ''}
                    onChange={(e) =>
                      setWelderForm((prev) => ({
                        ...prev,
                        admissionSheetDate: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Ответственный мастер / прораб
                  </label>
                  <input
                    type="text"
                    value={welderForm.crewForeman}
                    onChange={(e) =>
                      setWelderForm((prev) => ({ ...prev, crewForeman: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-200">
                <div>
                  {welderModal.item && onDeleteWelder && (
                    <button
                      type="button"
                      onClick={() => {
                        if (welderModal.item) {
                          onDeleteWelder(welderModal.item.stamp);
                          setWelderModal({ isOpen: false, isBrigade: false, item: null });
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-300 bg-red-50 text-red-700 hover:bg-red-100 font-semibold"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Удалить сварщика</span>
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setWelderModal({ isOpen: false, isBrigade: false, item: null })}
                    className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold"
                  >
                    Отмена
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#1e3799] text-white font-semibold hover:bg-[#15276e]"
                  >
                    <Check className="w-4 h-4" />
                    <span>Сохранить</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* МОДАЛЬНОЕ ОКНО ТЕХНОЛОГИЧЕСКОЙ КАРТЫ (ТК) */}
      {tcModal.isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Технологическая карта на сварку"
        >
          <div
            className="fixed inset-0 bg-slate-900/45 backdrop-blur-[1px]"
            onClick={() => setTcModal({ isOpen: false, item: null })}
          />
          <div className="relative z-10 w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 bg-[#1e3799] text-white shrink-0">
              <div className="flex items-center gap-2.5">
                <FileCheck2 className="w-5 h-5 text-sky-300" />
                <h2 className="text-sm font-bold">
                  Технологическая карта на сварку (ТК) и режимы подогрева
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setTcModal({ isOpen: false, item: null })}
                className="p-1 rounded text-sky-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={handleTcSubmit}
              className="p-6 space-y-4 text-xs overflow-y-auto flex-1"
            >
              {modalError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-300 text-red-800 text-xs font-semibold">
                  {modalError}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Шифр ТК *
                  </label>
                  <input
                    type="text"
                    required
                    value={tcForm.number}
                    onChange={(e) =>
                      setTcForm((prev) => ({ ...prev, number: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono font-bold text-[#1e3799]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Способ сварки
                  </label>
                  <select
                    value={tcForm.weldingType}
                    onChange={(e) =>
                      setTcForm((prev) => ({
                        ...prev,
                        weldingType: e.target.value as WeldingType,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  >
                    <option value="РАД+РД">РАД+РД</option>
                    <option value="РАД">РАД</option>
                    <option value="РД">РД</option>
                    <option value="МП">МП</option>
                    <option value="АФ">АФ</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Группа и марки сталей
                  </label>
                  <input
                    type="text"
                    value={tcForm.steelGroup}
                    onChange={(e) =>
                      setTcForm((prev) => ({ ...prev, steelGroup: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Наименование технологической карты
                </label>
                <input
                  type="text"
                  value={tcForm.title}
                  onChange={(e) =>
                    setTcForm((prev) => ({ ...prev, title: e.target.value }))
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Мин. диаметр, мм
                  </label>
                  <input
                    type="number"
                    value={tcForm.minDiameterMm}
                    onChange={(e) =>
                      setTcForm((prev) => ({
                        ...prev,
                        minDiameterMm: Number(e.target.value),
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Макс. диаметр, мм
                  </label>
                  <input
                    type="number"
                    value={tcForm.maxDiameterMm}
                    onChange={(e) =>
                      setTcForm((prev) => ({
                        ...prev,
                        maxDiameterMm: Number(e.target.value),
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Мин. толщина S, мм
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={tcForm.minWallThicknessMm}
                    onChange={(e) =>
                      setTcForm((prev) => ({
                        ...prev,
                        minWallThicknessMm: Number(e.target.value),
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Макс. толщина S, мм
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={tcForm.maxWallThicknessMm}
                    onChange={(e) =>
                      setTcForm((prev) => ({
                        ...prev,
                        maxWallThicknessMm: Number(e.target.value),
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Применяемые сварочные материалы
                </label>
                <input
                  type="text"
                  value={tcForm.recommendedMaterials}
                  onChange={(e) =>
                    setTcForm((prev) => ({
                      ...prev,
                      recommendedMaterials: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                />
              </div>

              <div className="space-y-2">
                <div className="font-bold text-[#1e3799]">
                  Режимы температуры подогрева в зависимости от T окружающей среды:
                </div>
                {tcForm.preheatRules.map((rule, idx) => (
                  <div
                    key={idx}
                    className="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200"
                  >
                    <div>
                      <label className="block text-[10px] text-slate-500">
                        T возд. от (°C)
                      </label>
                      <input
                        type="number"
                        value={rule.ambientMinC}
                        onChange={(e) =>
                          updatePreheatRule(idx, {
                            ambientMinC: Number(e.target.value),
                          })
                        }
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500">
                        T возд. до (°C)
                      </label>
                      <input
                        type="number"
                        value={rule.ambientMaxC}
                        onChange={(e) =>
                          updatePreheatRule(idx, {
                            ambientMaxC: Number(e.target.value),
                          })
                        }
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500">
                        Мин. подогрев (°C)
                      </label>
                      <input
                        type="number"
                        value={rule.minPreheatTempC}
                        onChange={(e) =>
                          updatePreheatRule(idx, {
                            minPreheatTempC: Number(e.target.value),
                          })
                        }
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono font-bold text-[#1e3799]"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-200">
                <div>
                  {tcModal.item && onDeleteTechCard && (
                    <button
                      type="button"
                      onClick={() => {
                        if (tcModal.item) {
                          onDeleteTechCard(tcModal.item.id);
                          setTcModal({ isOpen: false, item: null });
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-300 bg-red-50 text-red-700 hover:bg-red-100 font-semibold"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Удалить техкарту</span>
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTcModal({ isOpen: false, item: null })}
                    className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold"
                  >
                    Отмена
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#1e3799] text-white font-semibold hover:bg-[#15276e]"
                  >
                    <Check className="w-4 h-4" />
                    <span>Сохранить ТК</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* МОДАЛЬНОЕ ОКНО СВАРОЧНЫХ МАТЕРИАЛОВ И ВК */}
      {matModal.isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Сертификат и входной контроль сварочных материалов"
        >
          <div
            className="fixed inset-0 bg-slate-900/45 backdrop-blur-[1px]"
            onClick={() => setMatModal({ isOpen: false, item: null })}
          />
          <div className="relative z-10 w-full max-w-xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-[#1e3799] text-white">
              <div className="flex items-center gap-2.5">
                <PackageCheck className="w-5 h-5 text-sky-300" />
                <h2 className="text-sm font-bold">
                  Сварочный материал — Сертификат и дата входного контроля
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setMatModal({ isOpen: false, item: null })}
                className="p-1 rounded text-sky-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleMatSubmit} className="p-6 space-y-4 text-xs">
              {modalError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-300 text-red-800 text-xs font-semibold">
                  {modalError}
                </div>
              )}
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Марка и диаметр сварочного материала *
                </label>
                <input
                  type="text"
                  required
                  value={matForm.brandAndDiameter}
                  onChange={(e) =>
                    setMatForm((prev) => ({
                      ...prev,
                      brandAndDiameter: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono font-bold text-[#1e3799]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Номер сертификата качества *
                  </label>
                  <input
                    type="text"
                    required
                    value={matForm.certificateNumber}
                    onChange={(e) =>
                      setMatForm((prev) => ({
                        ...prev,
                        certificateNumber: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Партия / Плавка
                  </label>
                  <input
                    type="text"
                    value={matForm.batchNumber}
                    onChange={(e) =>
                      setMatForm((prev) => ({ ...prev, batchNumber: e.target.value }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    № акта входного контроля (ВК)
                  </label>
                  <input
                    type="text"
                    value={matForm.incomingControlAct}
                    onChange={(e) =>
                      setMatForm((prev) => ({
                        ...prev,
                        incomingControlAct: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="flex justify-between font-medium text-slate-700 mb-1">
                    <span>Дата входного контроля</span>
                    <span className="font-mono font-bold text-[#1e3799]">
                      {formatDateDDMMYY(matForm.incomingControlDate)}
                    </span>
                  </label>
                  <input
                    type="date"
                    value={matForm.incomingControlDate}
                    onChange={(e) =>
                      setMatForm((prev) => ({
                        ...prev,
                        incomingControlDate: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-200">
                <div>
                  {matModal.item && onDeleteMaterial && (
                    <button
                      type="button"
                      onClick={() => {
                        if (matModal.item) {
                          onDeleteMaterial(matModal.item.id);
                          setMatModal({ isOpen: false, item: null });
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-300 bg-red-50 text-red-700 hover:bg-red-100 font-semibold"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Удалить материал</span>
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setMatModal({ isOpen: false, item: null })}
                    className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold"
                  >
                    Отмена
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#1e3799] text-white font-semibold hover:bg-[#15276e]"
                  >
                    <Check className="w-4 h-4" />
                    <span>Сохранить</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
