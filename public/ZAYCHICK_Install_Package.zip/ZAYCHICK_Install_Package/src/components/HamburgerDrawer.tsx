import React, { useState } from 'react';
import {
  BookOpen,
  Building2,
  ClipboardList,
  Database,
  Download,
  FileSpreadsheet,
  HardDriveDownload,
  History,
  Layers,
  PieChart,
  Trash2,
  X,
  CheckCircle2,
  FolderKanban,
  UserCheck,
  KeyRound,
  Flame,
  MapPin,
  Plus,
} from 'lucide-react';
import { AppSection, FacilityObject, UserAccount } from '../types/welding';
import { ZaychickLogo } from './ZaychickLogo';

interface HamburgerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeSection: AppSection;
  onSelectSection: (section: AppSection) => void;
  facilities: FacilityObject[];
  selectedObjectName: string; // 'ALL' or facility.name
  onSelectObjectName: (name: string) => void;
  selectedRdCode: string; // 'ALL' or rdCode
  onSelectRdCode: (rd: string) => void;
  totalJointsCount: number;
  projectLineListCount: number;
  auditLogsCount: number;
  lrvCatalogCount: number;
  weldingTechCount?: string;
  currentUser: UserAccount;
  onOpenLoginModal: () => void;
  onExportAllJoints: (format: 'xlsx' | 'csv') => void;
  onOpenFacilityLocation: (objectName: string) => void;
  onOpenBackupModal: () => void;
  onOpenAuthorResetModal: () => void;
  onDeleteObject: (objectName: string) => void;
  onDeleteRdCode: (rdCode: string) => void;
}

export const HamburgerDrawer: React.FC<HamburgerDrawerProps> = ({
  isOpen,
  onClose,
  activeSection,
  onSelectSection,
  facilities,
  selectedObjectName,
  onSelectObjectName,
  selectedRdCode,
  onSelectRdCode,
  totalJointsCount,
  projectLineListCount,
  auditLogsCount,
  lrvCatalogCount,
  weldingTechCount,
  currentUser,
  onOpenLoginModal,
  onExportAllJoints,
  onOpenFacilityLocation,
  onOpenBackupModal,
  onOpenAuthorResetModal,
  onDeleteObject,
  onDeleteRdCode,
}) => {
  const [confirmDeleteObj, setConfirmDeleteObj] = useState<string | null>(null);
  const [confirmDeleteRd, setConfirmDeleteRd] = useState<string | null>(null);

  if (!isOpen) return null;

  const navItems: {
    id: AppSection;
    title: string;
    subtitle: string;
    badge?: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'registry',
      title: 'Реестр стыков и ввод данных',
      subtitle: 'Таблица 37 полей, Excel-фильтры, шаблоны и групповая правка',
      badge: `${totalJointsCount}`,
      icon: <ClipboardList className="w-5 h-5" />,
    },
    {
      id: 'project_linelist',
      title: 'Проект (лайнлист)',
      subtitle: 'Перечень технологических линий, НТД, % контроля, статус и испытания',
      badge: `${projectLineListCount}`,
      icon: <FolderKanban className="w-5 h-5" />,
    },
    {
      id: 'welding_tech',
      title: 'Технология сварочного производства',
      subtitle: 'Сварщики и бригады (НАКС, допускные), техкарты ТК и сертификаты СМ с ВК',
      badge: weldingTechCount || 'ТК / НАКС',
      icon: <Flame className="w-5 h-5" />,
    },
    {
      id: 'journals',
      title: 'Журналы сварочных работ',
      subtitle: 'СТО Газпром 15-1.1-002-2023 и ГОСТ 32569-2013 (строго по НТД)',
      badge: '2 формы',
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      id: 'readiness',
      title: 'Отчётность по готовности',
      subtitle: 'Аналитика по условиям: Объект, Шифр РД, Линия, Контур',
      icon: <PieChart className="w-5 h-5" />,
    },
    {
      id: 'lrv_catalog',
      title: 'Каталог ЛРВ и спецификации',
      subtitle: 'База закупочных кодов ЛРВ с привязкой к Шифру РД',
      badge: `${lrvCatalogCount}`,
      icon: <Database className="w-5 h-5" />,
    },
    {
      id: 'audit_log',
      title: 'Журнал изменений (Аудит)',
      subtitle: 'Протоколирование: кто, когда и какое поле стыка изменил',
      badge: `${auditLogsCount}`,
      icon: <History className="w-5 h-5" />,
    },
    {
      id: 'user_guide',
      title: 'Руководство пользователя (Буклет PDF)',
      subtitle: 'Пошаговый регламент для Инженера ПТО, Технолога и Дефектоскописта ЛНК',
      badge: '6 стр. А4',
      icon: <BookOpen className="w-5 h-5" />,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label="Навигация, профиль пользователя и выбор объекта"
    >
      {/* Затемнение фона */}
      <div
        className="fixed inset-0 bg-slate-900/45 backdrop-blur-[1px] transition-opacity"
        onClick={onClose}
      />

      {/* Боковая панель справа (соответствует кнопке-бутерброду в правом верхнем углу) */}
      <div className="relative z-10 flex flex-col w-full max-w-md bg-white text-slate-900 shadow-2xl border-l border-slate-200 h-full overflow-hidden">
        {/* Шапка панели цвета #1e3799 */}
        <div className="flex items-center justify-between px-5 py-4 bg-[#1e3799] text-white shrink-0">
          <ZaychickLogo variant="header" size={34} />
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть меню навигации"
            className="p-2 rounded-lg text-sky-100 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Блок 1: Профиль пользователя (перенесён в бутерброд) */}
          <div className="p-3.5 rounded-xl bg-[#f4f8fe] border border-sky-200/80 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-lg bg-[#1e3799] text-white flex items-center justify-center shrink-0">
                <UserCheck className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {currentUser.fullName}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  <span className="font-mono text-[#1e3799]">{currentUser.login}</span> ·{' '}
                  {currentUser.role}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenLoginModal();
              }}
              aria-label="Сменить пользователя или войти по логину и паролю"
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 hover:border-[#1e3799] text-xs font-semibold text-[#1e3799] transition-colors shrink-0"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Сменить</span>
            </button>
          </div>

          {/* Блок 2: Основной раздел программы */}
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-2.5">
              <Layers className="w-3.5 h-3.5 text-[#1e3799]" />
              <span>Основной раздел программы</span>
            </div>
            <nav className="space-y-1.5" aria-label="Разделы системы">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelectSection(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-start gap-3.5 p-3 rounded-lg text-left transition-colors border ${
                      isActive
                        ? 'bg-[#e8f1fc] border-[#1e3799]/30 text-[#1e3799]'
                        : 'bg-white border-slate-200/80 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div
                      className={`p-2 rounded-md shrink-0 mt-0.5 ${
                        isActive ? 'bg-[#1e3799] text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold truncate">{item.title}</span>
                        {item.badge && (
                          <span className="text-xs font-mono text-slate-500 shrink-0">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5 leading-snug">
                        {item.subtitle}
                      </p>
                    </div>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Блок выгрузки всех данных таблицы в .XLSX или .CSV */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                <Download className="w-3.5 h-3.5 text-[#1e3799]" />
                <span>Скачать все данные таблицы ({totalJointsCount} ст.)</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">37 полей</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onExportAllJoints('xlsx')}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[#1e3799] text-white hover:bg-[#15276e] text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Скачать .XLSX</span>
              </button>
              <button
                type="button"
                onClick={() => onExportAllJoints('csv')}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 hover:border-[#1e3799] hover:text-[#1e3799] text-xs font-semibold transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Скачать .CSV</span>
              </button>
            </div>
            <div className="pt-1 space-y-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenBackupModal();
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-[#e8f1fc] border border-[#1e3799]/40 text-[#1e3799] hover:bg-sky-100 text-xs font-semibold transition-colors cursor-pointer"
              >
                <HardDriveDownload className="w-3.5 h-3.5" />
                <span>Бэкап и восстановление базы (.JSON)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAuthorResetModal();
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:border-red-400 hover:text-red-700 text-[11px] font-semibold transition-colors cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                <span>Консоль Автора («Чистый лист» / Сброс)</span>
              </button>

              <a
                href="/ZAYCHICK_Install_Package.zip"
                download="ZAYCHICK_Install_Package.zip"
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-emerald-700 text-white hover:bg-emerald-800 text-xs font-semibold transition-colors shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Скачать дистрибутив программы (.ZIP)</span>
              </a>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Блок 3: Выбор и удаление объекта и подобъекта (Шифра РД) */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                <Building2 className="w-3.5 h-3.5 text-[#1e3799]" />
                <span>Выбор объекта строительства</span>
              </div>
              {selectedObjectName !== 'ALL' && (
                <button
                  type="button"
                  onClick={() => {
                    onSelectObjectName('ALL');
                    onSelectRdCode('ALL');
                  }}
                  className="text-xs font-medium text-[#1e3799] hover:underline"
                >
                  Показать все объекты
                </button>
              )}
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  onSelectObjectName('ALL');
                  onSelectRdCode('ALL');
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg border text-left text-sm transition-colors ${
                  selectedObjectName === 'ALL'
                    ? 'bg-[#1e3799] text-white border-[#1e3799] font-semibold'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>Все объекты (Сводный режим)</span>
                {selectedObjectName === 'ALL' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
              </button>

              {facilities.map((fac) => {
                const isObjSelected = selectedObjectName === fac.name;
                const isConfirmingObj = confirmDeleteObj === fac.name;
                return (
                  <div
                    key={fac.id}
                    className={`rounded-lg border transition-colors ${
                      isObjSelected
                        ? 'border-[#1e3799] bg-[#f4f8fe]'
                        : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between p-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onSelectObjectName(fac.name);
                          onSelectRdCode('ALL');
                        }}
                        className="flex-1 text-left"
                      >
                        <div className="text-sm font-semibold text-slate-900">{fac.name}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {fac.region} · {fac.latitude.toFixed(2)}°N, {fac.longitude.toFixed(2)}°E · Шифров РД: {fac.rdCodes.length}
                        </div>
                      </button>

                      <div className="flex items-center gap-1 shrink-0">
                        {!isConfirmingObj ? (
                          <>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenFacilityLocation(fac.name);
                              }}
                              title="Нажмите для выбора местоположения объекта и настройки авто-температуры воздуха"
                              aria-label={`Выбрать местоположение объекта ${fac.name}`}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-white border border-sky-200 hover:border-[#1e3799] text-[#1e3799] text-[11px] font-semibold transition-colors shadow-2xs"
                            >
                              <MapPin className="w-3.5 h-3.5" />
                              <span>Гео / t°</span>
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setConfirmDeleteObj(fac.name);
                              }}
                              title={`Удалить объект «${fac.name}» со всеми его шифрами РД, линиями и стыками`}
                              aria-label={`Удалить объект ${fac.name}`}
                              className="p-1.5 rounded-md bg-white border border-slate-200 text-slate-400 hover:text-red-600 hover:border-red-300 hover:bg-red-50 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteObject(fac.name);
                                setConfirmDeleteObj(null);
                              }}
                              className="px-2 py-1 rounded bg-red-600 text-white text-[11px] font-bold hover:bg-red-700"
                            >
                              Удалить объект
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setConfirmDeleteObj(null);
                              }}
                              className="px-2 py-1 rounded bg-white border border-slate-300 text-slate-700 text-[11px] font-semibold"
                            >
                              Отмена
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Подобъекты (Шифры РД) объекта — всегда видны для выбора и удаления */}
                    {fac.rdCodes.length > 0 && (
                      <div className="px-3 pb-3 pt-1 border-t border-sky-200/70 space-y-1.5">
                        <div className="flex items-center justify-between gap-1.5 text-[11px] font-medium text-slate-500 py-1">
                          <div className="flex items-center gap-1.5">
                            <FolderKanban className="w-3.5 h-3.5 text-[#1e3799]" />
                            <span>Шифры РД объекта ({fac.rdCodes.length}):</span>
                          </div>
                          {isObjSelected && selectedRdCode !== 'ALL' && (
                            <button
                              type="button"
                              onClick={() => onSelectRdCode('ALL')}
                              className="text-[11px] text-[#1e3799] hover:underline font-semibold"
                            >
                              Все РД объекта
                            </button>
                          )}
                        </div>
                        {fac.rdCodes.map((rd) => {
                          const isConfirmingRd = confirmDeleteRd === rd.code;
                          const isRdActive = selectedRdCode === rd.code;
                          return (
                            <div
                              key={rd.code}
                              className={`w-full flex items-center justify-between gap-2 px-2.5 py-2 rounded text-xs transition-colors border ${
                                isRdActive
                                  ? 'bg-[#1e3799] text-white border-[#1e3799] font-semibold'
                                  : 'bg-white text-slate-800 border-slate-200 hover:bg-sky-50'
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => {
                                  onSelectObjectName(fac.name);
                                  onSelectRdCode(rd.code);
                                }}
                                className="flex-1 text-left min-w-0"
                              >
                                <div className="font-mono text-[11px] break-all">
                                  {rd.code}
                                </div>
                                <div
                                  className={`text-[11px] mt-0.5 ${
                                    isRdActive ? 'text-sky-100' : 'text-slate-500'
                                  }`}
                                >
                                  {rd.title}
                                </div>
                              </button>

                              {!isConfirmingRd ? (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setConfirmDeleteRd(rd.code);
                                  }}
                                  title={`Удалить шифр РД «${rd.code}»`}
                                  aria-label={`Удалить шифр РД ${rd.code}`}
                                  className={`p-1.5 rounded shrink-0 transition-colors ${
                                    isRdActive
                                      ? 'text-sky-200 hover:text-white hover:bg-red-600'
                                      : 'text-slate-400 hover:text-red-600 hover:bg-red-50'
                                  }`}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <div className="flex items-center gap-1 shrink-0">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onDeleteRdCode(rd.code);
                                      setConfirmDeleteRd(null);
                                    }}
                                    className="px-2 py-1 rounded bg-red-600 text-white text-[10px] font-bold hover:bg-red-700"
                                  >
                                    Удалить РД
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setConfirmDeleteRd(null);
                                    }}
                                    className="px-2 py-1 rounded bg-white border border-slate-300 text-slate-700 text-[10px] font-semibold"
                                  >
                                    Отмена
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    onSelectSection('project_linelist');
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-dashed border-[#1e3799]/40 bg-sky-50/60 hover:bg-sky-100/70 text-[#1e3799] text-xs font-semibold transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Добавить новый объект или РД в лайнлисте</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Подвал бокового меню (двойной клик открывает скрытую консоль Автора) */}
        <div
          onDoubleClick={() => {
            onClose();
            onOpenAuthorResetModal();
          }}
          title="Двойной клик — служебная консоль Автора"
          className="px-5 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between shrink-0 select-none cursor-default"
        >
          <span>Локальный сервер · Open-Source стек</span>
          <span className="font-mono">До 100 000 строк · 30+ сессий</span>
        </div>
      </div>
    </div>
  );
};
