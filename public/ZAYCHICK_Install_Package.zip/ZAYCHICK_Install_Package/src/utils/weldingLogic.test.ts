import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ALL_COLUMNS,
  applyBulkUpdateToJoints,
  applyBulkUpdateToLineList,
  buildUniqueLineId,
  calculateReadinessReport,
  computeLineListItemStatus,
  deriveFacilitiesFromLineList,
  detectLrvElementType,
  estimateAmbientTempByCoordsAndDate,
  extractRdSuffix,
  extractSurnameOnly,
  filterLrvByDiameter,
  filterLrvCatalogByRd,
  findWelderByStamp,
  formatDateDDMMYY,
  formatGost32569JournalRow,
  formatStoGazpromJournalRow,
  formatTimestampDDMMYY,
  getFacilityWeatherStationName,
  getLrvItemDn1,
  getLrvItemDn2,
  GOST_16037_JOINT_TYPES,
  GOST_32569_2013_JOURNAL_COLUMNS,
  isAngularWeldJoint,
  isWeldingDateInRange,
  MAX_HISTORY_STEPS,
  mmToInchDiameter,
  mmToNominalBoreDn,
  NAKS_WELDING_POSITIONS,
  normalizeStampString,
  parseProjectLineListRecords,
  performRedoStep,
  performUndoStep,
  pushHistorySnapshot,
  resolveWeldersSelection,
  searchLrvCatalogItems,
  searchWeldersByStampOrName,
  sortJointsChronologically,
  STO_GAZPROM_15_1_1_002_2023_COLUMNS,
  suggestNextJointNumber,
  validateElementsDiameterMatch,
  validatePreheatTemperature,
  validateWeldingTypeWithTechCard,
  isJointCurrentlyInRepair,
  isJointFullyAccepted,
  FIELD_LABELS_MAP,
} from './weldingLogic';
import {
  AuditLogEntry,
  LRVItem,
  ProjectLineItem,
  TechCardItem,
  UserAccount,
  WelderProfile,
  WeldingMaterialCertificate,
  WeldJoint,
} from '../types/welding';
import {
  INITIAL_JOINTS,
  INITIAL_LRV_CATALOG,
  INITIAL_WELDING_MATERIALS,
} from '../data/seedData';
import { parseAndValidateJointsImport } from './jointImportUtils';
import type { FullSystemBackupPayload } from '../components/BackupAndResetModal';

test('formatDateDDMMYY, formatTimestampDDMMYY, and isWeldingDateInRange work accurately', () => {
  assert.equal(formatDateDDMMYY('2026-10-12'), '12.10.26');
  assert.equal(formatDateDDMMYY('15.04.2026'), '15.04.26');
  assert.equal(formatDateDDMMYY('18.10.26'), '18.10.26');
  assert.equal(formatTimestampDDMMYY('2026-10-21T09:15:12Z'), '21.10.26 09:15');

  // Без границ диапазона проходят даже пустые даты сварки
  assert.equal(isWeldingDateInRange('', '', ''), true);
  assert.equal(isWeldingDateInRange('2026-10-15', '', ''), true);

  // С активным диапазоном пустая дата сварки отсекается
  assert.equal(isWeldingDateInRange('', '2026-10-10', '2026-10-20'), false);
  assert.equal(isWeldingDateInRange('2026-10-15', '2026-10-10', '2026-10-20'), true);
  assert.equal(isWeldingDateInRange('15.10.26', '2026-10-10', '2026-10-20'), true);
  assert.equal(isWeldingDateInRange('2026-10-09', '2026-10-10', '2026-10-20'), false);
  assert.equal(isWeldingDateInRange('2026-10-21', '2026-10-10', '2026-10-20'), false);
});

test('extractRdSuffix and buildUniqueLineId follow exact specification after last dot', () => {
  const rd = '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3';
  assert.equal(extractRdSuffix(rd), '001-ТХ3');
  assert.equal(buildUniqueLineId(rd, 'ФП1.2/1'), '001-ТХ3-ФП1.2/1');

  const rdLatin = '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3';
  assert.equal(buildUniqueLineId(rdLatin, 'ФП1.2/1'), '001-TX3-ФП1.2/1');
});

test('suggestNextJointNumber generates main joints by 10s (010, 020) and supplementary joints (011, 012)', () => {
  assert.equal(suggestNextJointNumber([]), '010');
  assert.equal(suggestNextJointNumber(['010', '020', '030']), '040');
  assert.equal(suggestNextJointNumber(['010', '020'], '010'), '011');
  assert.equal(suggestNextJointNumber(['010', '011', '020'], '010'), '012');
});

test('filterLrvCatalogByRd strictly isolates LRV items by RD code unless overridden', () => {
  const sampleCatalog: LRVItem[] = [
    {
      id: '1',
      lrvCode: 'ЛРВ-TX3-0041',
      rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
      objectName: 'УКПГ-2В',
      shortName: 'Отвод 90°',
      material: '09Г2С',
      ntd: 'ГОСТ 17375-2001',
      diameterMm: 159,
      wallThickness: 8,
      specQty: 31,
      unit: 'шт',
    },
    {
      id: '2',
      lrvCode: 'ЛРВ-TX1-0098',
      rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.002-TX1',
      objectName: 'УКПГ-2В',
      shortName: 'Отвод 90°',
      material: '09Г2С',
      ntd: 'ГОСТ 17375-2001',
      diameterMm: 159,
      wallThickness: 8,
      specQty: 18,
      unit: 'шт',
    },
  ];

  const strictFiltered = filterLrvCatalogByRd(
    sampleCatalog,
    '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    false
  );
  assert.equal(strictFiltered.length, 1);
  assert.equal(strictFiltered[0].lrvCode, 'ЛРВ-TX3-0041');

  const unlocked = filterLrvCatalogByRd(
    sampleCatalog,
    '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    true
  );
  assert.equal(unlocked.length, 2);
});

test('sortJointsChronologically orders joints strictly by weldingDate ascending', () => {
  const baseJoint = {
    id: 'j1',
    objectName: 'УКПГ-2В',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    contour: 'КВД-1',
    lineNumber: 'ФП1.2/1',
    uniqueLineId: '001-TX3-ФП1.2/1',
    jointNumber: '020',
    jointType: 'Монтажный',
    diameterMm: 159,
    diameterInch: '6"',
    wallThickness: 8,
    lrv1Code: 'ЛРВ-1',
    elem1Name: 'Труба',
    elem1Material: '09Г2С',
    elem1Ntd: 'ГОСТ 8732-78',
    lrv2Code: 'ЛРВ-2',
    elem2Name: 'Отвод 90°',
    elem2Material: '09Г2С',
    elem2Ntd: 'ГОСТ 17375-2001',
    weldingType: 'РАД+РД',
    weldingDate: '2026-10-18',
    welderStamp: 'А142',
    weldingMaterials: 'Св-08Г2С',
    ambientTemp: '-6',
    responsiblePerson: 'Иванов И.И.',
    welderFullName: 'Петров П.П.',
    welderCertNumber: 'НАКС-01',
    techCardNumber: 'ТК-01',
    vikResult: 'Годен',
    vikDate: '2026-10-18',
    vikInspector: 'Сидоров С.С.',
    ndtType: 'РК',
    ndtDate: '2026-10-19',
    ndtResult: 'Годен',
    ndtInspector: 'Сидоров С.С.',
    dupNdtType: 'Не требуется',
    dupNdtDate: '',
    dupNdtResult: 'Не проводился',
    dupNdtInspector: '',
    updatedAt: '2026-10-19',
    updatedBy: 'Инженер ПТО',
  } satisfies WeldJoint;

  const joints: WeldJoint[] = [
    { ...baseJoint, id: '1', jointNumber: '030', weldingDate: '2026-10-25' },
    { ...baseJoint, id: '2', jointNumber: '010', weldingDate: '2026-10-12' },
    { ...baseJoint, id: '3', jointNumber: '020', weldingDate: '2026-10-19' },
  ];

  const sorted = sortJointsChronologically(joints);
  assert.deepEqual(
    sorted.map((j) => j.weldingDate),
    ['2026-10-12', '2026-10-19', '2026-10-25']
  );
});

test('applyBulkUpdateToJoints updates selected joints, ignores jointNumber, and creates audit entries', () => {
  const j1: WeldJoint = {
    id: 'j1',
    objectName: 'УКПГ-2В',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    contour: 'КВД-1',
    lineNumber: 'ФП1.2/1',
    uniqueLineId: '001-TX3-ФП1.2/1',
    jointNumber: '010',
    jointType: 'Монтажный',
    diameterMm: 159,
    diameterInch: '6"',
    wallThickness: 8,
    lrv1Code: 'ЛРВ-1',
    elem1Name: 'Труба',
    elem1Material: '09Г2С',
    elem1Ntd: 'ГОСТ 8732-78',
    lrv2Code: 'ЛРВ-2',
    elem2Name: 'Отвод 90°',
    elem2Material: '09Г2С',
    elem2Ntd: 'ГОСТ 17375-2001',
    weldingType: 'РАД',
    weldingDate: '2026-10-15',
    welderStamp: 'А142',
    weldingMaterials: 'Св-08Г2С',
    ambientTemp: '-4',
    responsiblePerson: 'Иванов И.И.',
    welderFullName: 'Петров П.П.',
    welderCertNumber: 'НАКС-01',
    techCardNumber: 'ТК-01',
    vikResult: 'Годен',
    vikDate: '2026-10-15',
    vikInspector: 'Сидоров С.С.',
    ndtType: 'РК',
    ndtDate: '2026-10-16',
    ndtResult: 'Годен',
    ndtInspector: 'Сидоров С.С.',
    dupNdtType: 'Не требуется',
    dupNdtDate: '',
    dupNdtResult: 'Не проводился',
    dupNdtInspector: '',
    updatedAt: '2026-10-16',
    updatedBy: 'Инженер ПТО',
  };
  const j2: WeldJoint = { ...j1, id: 'j2', jointNumber: '020' };

  const { updatedJoints, auditEntries } = applyBulkUpdateToJoints(
    [j1, j2],
    ['j1', 'j2'],
    {
      jointNumber: '999', // must be ignored!
      diameterMm: 219,
      diameterInch: mmToInchDiameter(219),
      welderStamp: 'К089',
    },
    { login: 'pto_lead', fullName: 'Соколов А.В.', role: 'Ведущий инженер ПТО' },
    FIELD_LABELS_MAP
  );

  assert.equal(updatedJoints[0].jointNumber, '010');
  assert.equal(updatedJoints[1].jointNumber, '020');
  assert.equal(updatedJoints[0].diameterMm, 219);
  assert.equal(updatedJoints[1].welderStamp, 'К089');
  assert.equal(auditEntries.length, 6); // 3 changed fields * 2 joints
});

test('calculateReadinessReport computes completion percentages and estimateAmbientTempByCoordsAndDate works', () => {
  const temp = estimateAmbientTempByCoordsAndDate(70.37, 68.43, '2026-10-20');
  assert.equal(typeof temp, 'number');

  const rows = calculateReadinessReport([], 'objectName');
  assert.equal(rows.length, 0);
});

test('computeLineListItemStatus, parseProjectLineListRecords, deriveFacilitiesFromLineList, and applyBulkUpdateToLineList work for Project Line List', () => {
  const parsed = parseProjectLineListRecords(
    [
      {
        'Название объекта': 'УКПГ-2В Бованенковское НГКМ',
        'Шифр РД': '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
        'Номер линии': 'МТ-09/1',
        'Наименование линии': 'Линия подачи ингибитора метанола',
        Продукт: 'Метанол',
        'Контур испытания': 'Контур подачи метанола КМ-1',
        'НТД на сварку': 'СТО Газпром 15-1.1-002-2023',
        'НТД на контроль': 'СТО Газпром 15-1.3-004-2023',
        'Уровень качества': 'Уровень А',
        'Категория трубопровода': 'I (В)',
        'Рабочее давление': '16.0 МПа',
        Температура: '-40...+50 °C',
        'Процент контроля РК': '100%',
        'Процент контроля УЗК': '100%',
        'Процент контроля ПВК': '100%',
        Статус: '',
        'Дата испытания': '26.10.26',
      },
    ],
    'УКПГ-2В Бованенковское НГКМ',
    '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3'
  );

  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].uniqueLineId, '001-TX3-МТ-09/1');
  assert.equal(parsed[0].qualityLevel, 'Уровень А');
  assert.equal(parsed[0].rkPercent, 100);
  assert.equal(parsed[0].pvkPercent, 100);
  assert.equal(parsed[0].testDate, '2026-10-26');

  const derived = deriveFacilitiesFromLineList(parsed);
  assert.equal(derived.length, 1);
  assert.equal(derived[0].name, 'УКПГ-2В Бованенковское НГКМ');
  assert.equal(derived[0].rdCodes.length, 1);
  assert.equal(derived[0].rdCodes[0].code, '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3');
  assert.deepEqual(derived[0].rdCodes[0].contours, ['Контур подачи метанола КМ-1']);

  const bulkUpdated = applyBulkUpdateToLineList(parsed, [parsed[0].id], {
    qualityLevel: 'Уровень В',
    workingPressure: '14.5 МПа',
    lineNumber: 'ИГНОР', // should be ignored by bulk update
  });
  assert.equal(bulkUpdated[0].qualityLevel, 'Уровень В');
  assert.equal(bulkUpdated[0].workingPressure, '14.5 МПа');
  assert.equal(bulkUpdated[0].lineNumber, 'МТ-09/1');

  const sampleJoint: WeldJoint = {
    id: 'j-mt-1',
    objectName: 'УКПГ-2В Бованенковское НГКМ',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    contour: 'Контур подачи метанола КМ-1',
    lineNumber: 'МТ-09/1',
    uniqueLineId: '001-TX3-МТ-09/1',
    jointNumber: '010',
    jointType: 'Цеховой',
    diameterMm: 57,
    diameterInch: '2"',
    wallThickness: 5,
    lrv1Code: 'ЛРВ-1',
    elem1Name: 'Труба',
    elem1Material: '12Х18Н10Т',
    elem1Ntd: 'ГОСТ 9941-81',
    lrv2Code: 'ЛРВ-2',
    elem2Name: 'Отвод',
    elem2Material: '12Х18Н10Т',
    elem2Ntd: 'ГОСТ 17375-2001',
    weldingType: 'РАД',
    weldingDate: '2026-10-10',
    welderStamp: 'Т304',
    weldingMaterials: 'Св-04Х19Н11М3',
    ambientTemp: '+16',
    responsiblePerson: 'Тимофеев В.П.',
    welderFullName: 'Захаров М.О.',
    welderCertNumber: 'НАКС-2',
    techCardNumber: 'ТК-2',
    vikResult: 'Годен',
    vikDate: '2026-10-10',
    vikInspector: 'Воронов А.С.',
    ndtType: 'РК',
    ndtDate: '2026-10-11',
    ndtResult: 'Годен',
    ndtInspector: 'Воронов А.С.',
    dupNdtType: 'ПВК',
    dupNdtDate: '2026-10-11',
    dupNdtResult: 'Годен',
    dupNdtInspector: 'Кузнецова Е.В.',
    updatedAt: '2026-10-11',
    updatedBy: 'Инженер ПТО',
  };

  const statusReady = computeLineListItemStatus(parsed[0], [sampleJoint]);
  assert.equal(statusReady.isCompleted, true);
  assert.equal(statusReady.weldedJoints, 1);
  assert.equal(statusReady.controlledJoints, 1);

  const inWorkJoint: WeldJoint = { ...sampleJoint, id: 'j-mt-2', jointNumber: '020', weldingDate: '' };
  const statusInWork = computeLineListItemStatus(parsed[0], [sampleJoint, inWorkJoint]);
  assert.equal(statusInWork.isCompleted, false);
  assert.equal(statusInWork.weldedJoints, 1);
  assert.equal(statusInWork.totalJoints, 2);

  // Проверка допустимости пустых значений для Уровня качества и Категории трубопровода
  const parsedEmptyQualityAndCat = parseProjectLineListRecords(
    [
      {
        'Название объекта': 'УКПГ-2В Бованенковское НГКМ',
        'Шифр РД': '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
        'Номер линии': 'ДР-99/1',
        'Наименование линии': 'Дренаж безнапорный',
        'Уровень качества': '',
        'Категория трубопровода': '',
      },
    ],
    'УКПГ-2В Бованенковское НГКМ',
    '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3'
  );
  assert.equal(parsedEmptyQualityAndCat[0].qualityLevel, '');
  assert.equal(parsedEmptyQualityAndCat[0].pipelineCategory, '');
});

test('resolveWeldersSelection, validatePreheatTemperature, validateElementsDiameterMatch, and filterLrvByDiameter work accurately', () => {
  const sampleWelders: WelderProfile[] = [
    {
      stamp: 'А142',
      fullName: 'Коваленко Д.С.',
      certNumber: 'НАКС-ЗСР-I-104928',
      certIssueDate: '12.03.25',
      certExpiryDate: '12.03.27',
      attestationArea: 'РАД, РД (НГДО п.3, ОХНВП п.16)',
      admissionSheetNumber: 'ДЛ-2026/014',
      admissionSheetDate: '15.01.26',
      allowedMethods: ['РАД', 'РД'],
      crewForeman: 'Тимофеев В.П.',
    },
    {
      stamp: 'К089',
      fullName: 'Сафин Р.М.',
      certNumber: 'НАКС-ЗСР-I-108311',
      certIssueDate: '20.05.25',
      certExpiryDate: '20.05.27',
      attestationArea: 'РАД, РД, МП (НГДО п.3, СК п.1)',
      admissionSheetNumber: 'ДЛ-2026/019',
      admissionSheetDate: '18.01.26',
      allowedMethods: ['РАД', 'РД', 'МП'],
      crewForeman: 'Тимофеев В.П.',
    },
    {
      stamp: 'БР-01',
      fullName: 'Бригада №1 (Коваленко Д.С. / Сафин Р.М.)',
      certNumber: 'НАКС-ЗСР-I-104928 / НАКС-ЗСР-I-108311',
      certIssueDate: '12.03.25',
      certExpiryDate: '12.03.27',
      attestationArea: 'Комбинированная сварка РАД+РД Ø159–1420 мм',
      admissionSheetNumber: 'ДЛ-БР-2026/01',
      admissionSheetDate: '20.01.26',
      allowedMethods: ['РАД+РД'],
      crewForeman: 'Тимофеев В.П.',
      isBrigade: true,
      brigadeMembers: ['А142', 'К089'],
    },
  ];

  // Сварка двумя сварщиками с бригадным клеймом
  const resolved = resolveWeldersSelection(['А142', 'К089'], 'БР-01', sampleWelders);
  assert.equal(resolved.welderStamp, 'БР-01 (А142, К089)');
  assert.equal(resolved.welderFullName, 'Коваленко Д.С., Сафин Р.М.');
  assert.equal(
    resolved.welderCertNumber,
    'НАКС-ЗСР-I-104928, НАКС-ЗСР-I-108311'
  );

  // Контроль температуры подогрева по ТК и температуре воздуха
  const sampleTc: TechCardItem = {
    id: 'tc-1',
    number: 'ТК-159-09Г2С-01',
    title: 'РАД+РД труб 09Г2С',
    weldingType: 'РАД+РД',
    ntd: 'СТО Газпром 15-1.1-002-2023',
    steelGroup: 'М01 (09Г2С)',
    minDiameterMm: 57,
    maxDiameterMm: 325,
    minWallThicknessMm: 4,
    maxWallThicknessMm: 16,
    recommendedMaterials: 'Св-08Г2С + УОНИ-13/55',
    preheatRules: [
      {
        ambientMinC: 5,
        ambientMaxC: 45,
        minPreheatTempC: 0,
        conditionLabel: 'При T возд. ≥ +5 °C',
      },
      {
        ambientMinC: -15,
        ambientMaxC: 4,
        minPreheatTempC: 120,
        conditionLabel: 'При T возд. от -15 до +4 °C',
      },
    ],
  };

  const validPreheat = validatePreheatTemperature('+140', '-6', sampleTc);
  assert.equal(validPreheat.isValid, true);
  assert.equal(validPreheat.requiredMinC, 120);

  const invalidLowPreheat = validatePreheatTemperature('+80', '-6', sampleTc);
  assert.equal(invalidLowPreheat.isValid, false);
  assert.equal(invalidLowPreheat.requiredMinC, 120);

  // Проверка обязательного равенства диаметров Элемента 1 и Элемента 2
  assert.equal(validateElementsDiameterMatch(159, 159).isMatch, true);
  assert.equal(validateElementsDiameterMatch(159, 219).isMatch, false);

  // Фильтрация ЛРВ с учётом второго диаметра переходов и тройников
  const reducerLrv: LRVItem = {
    id: 'lrv-red',
    lrvCode: 'ЛРВ-TX3-0046',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    objectName: 'УКПГ-2В',
    shortName: 'Переход К 219×10-159×8',
    material: '09Г2С',
    ntd: 'ГОСТ 17378-2001',
    diameterMm: 219,
    wallThickness: 10,
    diameterMm2: 159,
    wallThickness2: 8,
    specQty: 14,
    unit: 'шт',
  };
  assert.equal(filterLrvByDiameter([reducerLrv], 159).length, 1);
  assert.equal(filterLrvByDiameter([reducerLrv], 219).length, 1);
  assert.equal(filterLrvByDiameter([reducerLrv], 325).length, 0);

  // Проверка названия метеопункта объекта
  assert.equal(
    getFacilityWeatherStationName({ name: 'УКПГ-2В Бованенковское НГКМ' }),
    'Метеопункт Бованенково'
  );
  assert.equal(
    getFacilityWeatherStationName({
      name: 'УКПГ-2В Бованенковское НГКМ',
      weatherStation: 'Метеостанция Ямал-Север',
    }),
    'Метеостанция Ямал-Север'
  );

  // Проверка вида сварки по технологической карте
  const wtMatch = validateWeldingTypeWithTechCard('РАД+РД', sampleTc);
  assert.equal(wtMatch.isValid, true);
  const wtMismatch = validateWeldingTypeWithTechCard('МП', sampleTc);
  assert.equal(wtMismatch.isValid, false);
  assert.equal(wtMismatch.expectedType, 'РАД+РД');

  // Проверка определения типа элемента и многокритериального поиска в базе ЛРВ
  const valveLrv: LRVItem = {
    id: 'lrv-valve',
    lrvCode: 'ЛРВ-001ТХ3-0501',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    objectName: 'УКПГ-2В',
    shortName: 'Кран шаровый DN150 159х8',
    material: '09Г2С',
    ntd: 'ГОСТ 21345-2005',
    diameterMm: 159,
    wallThickness: 8,
    specQty: 6,
    unit: 'шт',
  };
  const pipeLrv: LRVItem = {
    id: 'lrv-pipe',
    lrvCode: 'ЛРВ-001ТХ3-0415',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-TX3',
    objectName: 'УКПГ-2В',
    shortName: 'Труба БШ 159х8',
    material: '09Г2С',
    ntd: 'ГОСТ 8732-78',
    diameterMm: 159,
    wallThickness: 8,
    specQty: 148,
    unit: 'м',
  };
  const catalogList = [reducerLrv, valveLrv, pipeLrv];

  assert.equal(detectLrvElementType(valveLrv.shortName), 'Кран');
  assert.equal(detectLrvElementType(reducerLrv.shortName), 'Переход');
  assert.equal(detectLrvElementType(pipeLrv.shortName), 'Труба');

  // Поиск по типу элемента "Кран"
  assert.equal(searchLrvCatalogItems(catalogList, '', 'Кран').length, 1);
  // Поиск по НТД "21345"
  assert.equal(searchLrvCatalogItems(catalogList, '21345', 'Все типы').length, 1);
  // Поиск по диаметру "219"
  assert.equal(searchLrvCatalogItems(catalogList, '219', 'Все типы').length, 1);
  // Поиск по краткому наименованию и диаметру "труба 159"
  assert.equal(searchLrvCatalogItems(catalogList, 'труба 159', 'Все типы').length, 1);

  // Проверка живого поиска сварщиков и бригад по номеру клейма (включая латиницу/кириллицу и регистр)
  assert.equal(normalizeStampString('a142'), 'А142');
  assert.equal(normalizeStampString('k089'), 'К089');
  assert.equal(findWelderByStamp(sampleWelders, 'a142', false)?.stamp, 'А142');
  assert.equal(findWelderByStamp(sampleWelders, 'бр-01', true)?.stamp, 'БР-01');

  const searchByDigits = searchWeldersByStampOrName(sampleWelders, '089');
  assert.equal(searchByDigits.length, 2); // К089 и БР-01 (в составе которой К089)
  assert.equal(searchByDigits[0].stamp, 'К089');

  const searchWithExclude = searchWeldersByStampOrName(
    sampleWelders.filter((w) => !w.isBrigade),
    '',
    ['А142']
  );
  assert.equal(searchWithExclude.length, 1);
  assert.equal(searchWithExclude[0].stamp, 'К089');
});

test('nominal bore DN1/DN2, ГОСТ 16037-80 joint types, НАКС positions, and 10-step Undo/Redo work accurately', () => {
  assert.equal(mmToNominalBoreDn(159), 150);
  assert.equal(mmToNominalBoreDn(219), 200);
  assert.equal(mmToNominalBoreDn(57), 50);
  assert.equal(mmToNominalBoreDn(undefined), undefined);

  const singleDiamItem: LRVItem = {
    id: 'lrv-single',
    lrvCode: 'ЛРВ-1',
    rdCode: 'РД-1',
    objectName: 'УКПГ',
    shortName: 'Труба 159х8',
    material: '09Г2С',
    ntd: 'ГОСТ 8732-78',
    diameterMm: 159,
    wallThickness: 8,
    specQty: 10,
    unit: 'м',
  };
  assert.equal(getLrvItemDn1(singleDiamItem), 150);
  assert.equal(getLrvItemDn2(singleDiamItem), undefined); // strictly undefined for 1-diameter items

  const dualDiamItem: LRVItem = {
    ...singleDiamItem,
    id: 'lrv-dual',
    shortName: 'Переход 219х10-159х8',
    diameterMm: 219,
    wallThickness: 10,
    diameterMm2: 159,
    wallThickness2: 8,
  };
  assert.equal(getLrvItemDn1(dualDiamItem), 200);
  assert.equal(getLrvItemDn2(dualDiamItem), 150);

  // Проверка наличия столбцов Длина эл. 1/2, Вид сварки, Тип сварного соединения и Положение в ALL_COLUMNS
  assert.equal(
    ALL_COLUMNS.find((c) => c.key === 'elem1Length')?.label,
    'Длина эл. 1, м'
  );
  assert.equal(
    ALL_COLUMNS.find((c) => c.key === 'elem2Length')?.label,
    'Длина эл. 2, м'
  );
  assert.equal(
    ALL_COLUMNS.find((c) => c.key === 'weldingType')?.label,
    'Вид сварки'
  );
  assert.equal(
    ALL_COLUMNS.find((c) => c.key === 'gostJointType')?.label,
    'Тип сварного соединения'
  );
  assert.equal(
    ALL_COLUMNS.find((c) => c.key === 'weldingPosition')?.label,
    'Положение'
  );

  // Проверка справочников ГОСТ 16037-80 и НАКС
  assert.equal(
    GOST_16037_JOINT_TYPES.some((g) => g.code === 'С17'),
    true
  );
  assert.equal(
    NAKS_WELDING_POSITIONS.some((p) => p.code === 'В1'),
    true
  );

  // Проверка стека Undo / Redo на 10 действий
  assert.equal(MAX_HISTORY_STEPS, 10);
  let undoStack: number[] = [];
  for (let i = 1; i <= 15; i++) {
    undoStack = pushHistorySnapshot(undoStack, i, MAX_HISTORY_STEPS).undoStack;
  }
  assert.equal(undoStack.length, 10);
  assert.deepEqual(undoStack, [6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);

  let redoStack: number[] = [];
  let current = 16;
  const undoRes1 = performUndoStep(undoStack, redoStack, current, MAX_HISTORY_STEPS);
  assert.equal(undoRes1.targetState, 15);
  assert.equal(undoRes1.undoStack.length, 9);
  assert.deepEqual(undoRes1.redoStack, [16]);

  const redoRes1 = performRedoStep(
    undoRes1.undoStack,
    undoRes1.redoStack,
    undoRes1.targetState!,
    MAX_HISTORY_STEPS
  );
  assert.equal(redoRes1.targetState, 16);
  assert.equal(redoRes1.undoStack.length, 10);
  assert.equal(redoRes1.redoStack.length, 0);

  // Проверка 17 граф журнала по ГОСТ 32569-2013 на соответствие прикрепленному файлу
  assert.equal(GOST_32569_2013_JOURNAL_COLUMNS.length, 17);
  assert.equal(GOST_32569_2013_JOURNAL_COLUMNS[0].label, '№ п/п');
  assert.equal(
    GOST_32569_2013_JOURNAL_COLUMNS[1].label,
    'Обозначение сварного соединения по исполнительному чертежу, тип сварного соединения ГОСТ 16037'
  );
  assert.equal(
    GOST_32569_2013_JOURNAL_COLUMNS[16].label,
    'Результаты измерения ферритной фазы в металле шва, N заключения, дата'
  );

  const sampleJoint = INITIAL_JOINTS[0];
  const gostRow = formatGost32569JournalRow(
    sampleJoint,
    0,
    INITIAL_WELDING_MATERIALS
  );
  assert.equal(gostRow.cells.length, 17);
  assert.equal(gostRow.col1, '1');
  // Во 2 столбце без номера линии и без справочных подписей ("010, С17")
  assert.equal(gostRow.col2, '010, С17');
  assert.equal(gostRow.col3.includes('Клеймо'), false);
  assert.equal(gostRow.col6.includes('T раб. зоны'), false);
  // В 4 столбце без скобок, у наименования элемента убраны диаметр и толщина стенки, НТД и сертификат через запятую, каждый элемент с новой строки
  assert.equal(gostRow.col4.includes('('), false);
  assert.equal(gostRow.col4.includes(')'), false);
  assert.equal(gostRow.col4.includes('159х8'), false);
  assert.equal(
    gostRow.col4,
    '09Г2С Труба БШ, ГОСТ 8732-78, Пл.40812-Т01\n09Г2С Отвод 90°, ГОСТ 17375-2001, ОТВ-26-089'
  );
  assert.equal(gostRow.col5, `${sampleJoint.diameterMm}х${sampleJoint.wallThickness}`);
  // 2. В 8 столбце каждый сварочный материал с новой строки
  assert.equal(
    gostRow.col8,
    'Св-08Г2С Ø2.0, ГОСТ 2246-70, 10492-26\nУОНИ-13/55 Ø3.0, ГОСТ 9466-75, НАКС-СМ-8841'
  );
  // 5. В 9 столбце без слова "Подогрев" и без номера техкарты
  assert.equal(gostRow.col9, '+130 °С');
  assert.equal(gostRow.col9.toLowerCase().includes('подогрев'), false);
  // 4. Вместо "Не требуется" пишется "н/п"
  assert.equal(gostRow.col11, 'н/п');
  assert.equal(gostRow.col12, 'н/п');
  assert.equal(gostRow.col13, 'н/п');
  assert.equal(gostRow.col14, 'н/п');
  assert.equal(gostRow.col17, 'н/п');
  assert.equal(
    gostRow.cells.some((c) => c.toLowerCase().includes('не требуется')),
    false
  );
});

test('49-column СТО Газпром 15-1.1-002-2023 journal form, element length (col 10), and angular weld "Я" / "н/п" (col 14) work accurately', () => {
  assert.equal(STO_GAZPROM_15_1_1_002_2023_COLUMNS.length, 49);
  assert.equal(STO_GAZPROM_15_1_1_002_2023_COLUMNS[0].label, 'Сквозной порядковый номер');
  assert.equal(STO_GAZPROM_15_1_1_002_2023_COLUMNS[9].label, 'Длина элемента, м');
  assert.equal(
    STO_GAZPROM_15_1_1_002_2023_COLUMNS[13].label,
    'дополнительная маркировка сварного соединения'
  );
  assert.equal(STO_GAZPROM_15_1_1_002_2023_COLUMNS[48].label, 'Примечание');

  // Проверка определения углового сварного шва
  assert.equal(isAngularWeldJoint('У4'), true);
  assert.equal(isAngularWeldJoint('У17'), true);
  assert.equal(isAngularWeldJoint('У19'), true);
  assert.equal(isAngularWeldJoint('С17'), false);
  assert.equal(isAngularWeldJoint('С21'), false);
  assert.equal(isAngularWeldJoint('Т8'), false);
  assert.equal(isAngularWeldJoint('Н1'), false);

  // Стыковой шов (j-101, С17) -> графа 10 = "11.8\n0.35", графа 14 = "н/п"
  const buttJoint = INITIAL_JOINTS[0];
  assert.equal(buttJoint.gostJointType, 'С17');
  const stoButtRow = formatStoGazpromJournalRow(buttJoint, 0, INITIAL_LRV_CATALOG);
  assert.equal(stoButtRow.cells.length, 49);
  assert.equal(stoButtRow.col1, '1');
  assert.equal(stoButtRow.col10, '11.8\n0.35');
  assert.equal(stoButtRow.col14, 'н/п');

  // Угловой шов (j-103, У4) -> графа 10 = "4.2\n0.18", графа 14 = "Я"
  const angularJoint = INITIAL_JOINTS.find((j) => j.id === 'j-103')!;
  assert.equal(angularJoint.gostJointType, 'У4');
  const stoAngularRow = formatStoGazpromJournalRow(angularJoint, 2, INITIAL_LRV_CATALOG);
  assert.equal(stoAngularRow.col10, '4.2\n0.18');
  assert.equal(stoAngularRow.col14, 'Я');
});

test('STO Gazprom rules: extractSurnameOnly, col 6 manufacturer, col 16 no position, cols 19/36 surname only, cols 20/37 blank, cols 31/32 repair logic', () => {
  // 1. extractSurnameOnly
  assert.equal(extractSurnameOnly('Мастер СМР Громов И.А.'), 'Громов');
  assert.equal(extractSurnameOnly('Прораб СМР Тимофеев В.П.'), 'Тимофеев');
  assert.equal(extractSurnameOnly('Громов И.А.'), 'Громов');
  assert.equal(extractSurnameOnly('Иванов И.И.'), 'Иванов');
  assert.equal(extractSurnameOnly('Сидоров'), 'Сидоров');
  assert.equal(extractSurnameOnly(''), 'н/п');
  assert.equal(extractSurnameOnly(undefined), 'н/п');

  const sampleJoint = INITIAL_JOINTS[0]; // j-101, responsiblePerson: 'Мастер СМР Громов И.А.'
  const row = formatStoGazpromJournalRow(sampleJoint, 0, INITIAL_LRV_CATALOG);

  // Столбец 6: ГОСТ, марка стали, завод-изготовитель
  assert.ok(row.col6.includes('ПАО «ЧТПЗ»') || row.col6.includes('АО «СОТ»'));
  assert.ok(row.col6.includes('09Г2С'));

  // Столбец 16: Без положения при сварке (только номер ТК)
  assert.equal(row.col16, sampleJoint.techCardNumber);
  assert.equal(row.col16.includes('В1'), false);
  assert.equal(row.col16.includes(','), false);

  // Столбец 19: Только фамилия ответственного лица
  assert.equal(row.col19, 'Громов');

  // Столбец 20: Пусто
  assert.equal(row.col20, '');

  // Столбец 31: Либо "Годен", либо "Ремонт", либо "н/п". Никаких "в работе".
  assert.ok(['Годен', 'Ремонт', 'н/п'].includes(row.col31));
  assert.equal(row.col31.toLowerCase().includes('в работе'), false);

  // Столбец 36: Только фамилия мастера/прораба при ремонте, либо 'н/п' при отсутствии ремонта
  assert.equal(row.col36, 'н/п');

  // Столбец 37: Пусто
  assert.equal(row.col37, '');

  // Проверка логики брака/ремонта: если первичный контроль "Ремонт" -> дублирующий контроль "н/п", столбец 32 "Ремонт"
  const repairJoint: WeldJoint = {
    ...sampleJoint,
    id: 'j-repair-test',
    jointNumber: '099',
    ndtResult: 'Ремонт',
    dupNdtResult: 'Годен', // дублирующий контроль не должен иметь смысла при браке первичного
    responsiblePerson: 'Прораб СМР Тимофеев В.П.',
  };
  const repairRow = formatStoGazpromJournalRow(repairJoint, 1, INITIAL_LRV_CATALOG);

  // Столбец 28-31: Дублирующий контроль отменяется, так как первичный выявил дефект -> "н/п"
  assert.equal(repairRow.col28, 'н/п');
  assert.equal(repairRow.col29, 'н/п');
  assert.equal(repairRow.col30, 'н/п');
  assert.equal(repairRow.col31, 'н/п');

  // Столбец 32: Не "Назначен ремонт", а просто "Ремонт"
  assert.equal(repairRow.col32, 'Ремонт');

  // Фамилия в столбце 19 и 36
  assert.equal(repairRow.col19, 'Тимофеев');
  assert.equal(repairRow.col36, 'Тимофеев');
});

test('COMPREHENSIVE 10-USER SIMULATION: registration of 10 users, collaborative workflow across roles, adding & deleting all 9 entity types, backup/restore, author zero-reset, and journal printing', () => {
  // =========================================================================
  // ЭТАП 1. Сброс в «Чистый лист» (Author Zero-Reset) и регистрация 10 пользователей
  // =========================================================================
  let userAccounts: UserAccount[] = [];
  let projectLineList: ProjectLineItem[] = [];
  let lrvCatalog: LRVItem[] = [];
  let welders: WelderProfile[] = [];
  let techCards: TechCardItem[] = [];
  let weldingMaterials: WeldingMaterialCertificate[] = [];
  let joints: WeldJoint[] = [];
  let auditLogs: AuditLogEntry[] = [];

  const tenSpecialists: Omit<UserAccount, 'sessionNumber'>[] = [
    {
      login: 'ilchenko.vlad@gmail.com',
      password: '123',
      fullName: 'Ильченко В. (Автор / Главный администратор)',
      role: 'Администратор ИТ / Руководитель проекта',
      department: 'Дирекция проекта',
    },
    {
      login: 'pto_smirnov',
      password: '123',
      fullName: 'Смирнов Алексей Викторович',
      role: 'Ведущий инженер ПТО',
      department: 'ПТО УКПГ-2В',
    },
    {
      login: 'pto_kuznetsova',
      password: '123',
      fullName: 'Кузнецова Елена Сергеевна',
      role: 'Инженер ПТО (комплектация и ЛРВ)',
      department: 'ПТО УКПГ-2В',
    },
    {
      login: 'pto_volkov',
      password: '123',
      fullName: 'Волков Дмитрий Игоревич',
      role: 'Инженер ПТО (исполнительная документация)',
      department: 'ПТО КС Воркутинская',
    },
    {
      login: 'tech_morozov',
      password: '123',
      fullName: 'Морозов Павел Николаевич',
      role: 'Главный сварщик / Инженер-технолог',
      department: 'Служба главного сварщика',
    },
    {
      login: 'tech_sokolov',
      password: '123',
      fullName: 'Соколов Андрей Олегович',
      role: 'Инженер-технолог по сварке (НАКС и СМ)',
      department: 'Служба главного сварщика',
    },
    {
      login: 'lnk_lebedev',
      password: '123',
      fullName: 'Лебедев Сергей Анатольевич',
      role: 'Начальник ЛНК / Дефектоскопист II ур.',
      department: 'Лаборатория НК',
    },
    {
      login: 'lnk_popov',
      password: '123',
      fullName: 'Попов Максим Валерьевич',
      role: 'Дефектоскопист РК/УЗК',
      department: 'Лаборатория НК',
    },
    {
      login: 'lnk_novikova',
      password: '123',
      fullName: 'Новикова Ольга Андреевна',
      role: 'Инженер ВИК и ПВК',
      department: 'Лаборатория НК',
    },
    {
      login: 'temp_intern',
      password: '123',
      fullName: 'Стажёров Стажёр Стажёрович',
      role: 'Стажёр ПТО (временный доступ)',
      department: 'ПТО',
    },
  ];

  tenSpecialists.forEach((spec, idx) => {
    const newAcc: UserAccount = {
      ...spec,
      sessionNumber: idx + 1,
    };
    userAccounts.push(newAcc);
    auditLogs.unshift({
      id: `aud-reg-${idx + 1}`,
      timestamp: new Date().toISOString(),
      userLogin: newAcc.login,
      userFullName: newAcc.fullName,
      userRole: newAcc.role,
      jointId: 'sys-auth',
      uniqueLineId: 'Регистрация пользователя',
      jointNumber: `Сессия #${newAcc.sessionNumber}`,
      rdCode: newAcc.department,
      fieldKey: 'auth_register',
      fieldLabel: 'Регистрация новой учётной записи',
      oldValue: '—',
      newValue: `${newAcc.fullName} (${newAcc.login})`,
      operationType: 'create_joint',
    });
  });

  assert.equal(userAccounts.length, 10, 'Должны быть зарегистрированы все 10 пользователей');

  // Удаление 10-го временного пользователя (проверка функции удаления пользователя)
  userAccounts = userAccounts.filter((u) => u.login !== 'temp_intern');
  assert.equal(userAccounts.length, 9, 'Временный пользователь должен быть успешно удалён');

  // =========================================================================
  // ЭТАП 2. Работа Технологов по сварке (tech_morozov и tech_sokolov):
  // Добавление и удаление сварщиков, бригады, техкарт и сварочных материалов
  // =========================================================================
  welders = [
    {
      id: 'w-sim-1',
      stamp: normalizeStampString('A701'), // латинская A -> кириллическая А
      fullName: 'Ковалёв Руслан Викторович',
      certNumber: 'НАКС-ЯМЛ-2026-0701',
      certIssueDate: '2025-05-10',
      certExpiryDate: '2027-05-10',
      weldingTypes: ['РАД', 'РД', 'РАД+РД'],
      gtdGroups: ['НГДО п.3,4', 'ОХНВП п.16'],
      admissionSheetNumber: 'ДЛ-701/26',
      admissionSheetDate: '2026-01-15',
      crewForeman: 'Мастер СМР Громов И.А.',
    },
    {
      id: 'w-sim-2',
      stamp: normalizeStampString('В702'),
      fullName: 'Захаров Артём Игоревич',
      certNumber: 'НАКС-ЯМЛ-2026-0702',
      certIssueDate: '2025-06-01',
      certExpiryDate: '2027-06-01',
      weldingTypes: ['РАД', 'РД', 'РАД+РД'],
      gtdGroups: ['НГДО п.3,4', 'ОХНВП п.16'],
      admissionSheetNumber: 'ДЛ-702/26',
      admissionSheetDate: '2026-01-20',
      crewForeman: 'Мастер СМР Громов И.А.',
    },
    {
      id: 'w-sim-brigade',
      stamp: 'БР-70',
      fullName: 'Ковалёв Руслан Викторович, Захаров Артём Игоревич',
      certNumber: 'НАКС-ЯМЛ-2026-0701, НАКС-ЯМЛ-2026-0702',
      certIssueDate: '2025-05-10',
      certExpiryDate: '2027-05-10',
      weldingTypes: ['РАД+РД', 'РД'],
      gtdGroups: ['НГДО п.3,4'],
      admissionSheetNumber: 'ДЛ-БР70/26',
      admissionSheetDate: '2026-01-25',
      crewForeman: 'Прораб СМР Тимофеев В.П.',
      isBrigade: true,
      brigadeMembers: ['А701', 'В702'],
    },
    {
      id: 'w-sim-err',
      stamp: 'Х999',
      fullName: 'Ошибочный Сварщик (на удаление)',
      certNumber: 'НАКС-000',
      certIssueDate: '2024-01-01',
      certExpiryDate: '2025-01-01',
      weldingTypes: ['РД'],
      gtdGroups: ['НГДО'],
      admissionSheetNumber: 'ДЛ-000',
      admissionSheetDate: '2024-01-02',
      crewForeman: 'Мастер СМР Громов И.А.',
    },
  ];
  assert.equal(welders[0].stamp, 'А701', 'Клеймо должно быть нормализовано в кириллицу');

  // Удаление ошибочного сварщика Х999
  welders = welders.filter((w) => w.id !== 'w-sim-err');
  assert.equal(welders.length, 3);

  // Редактирование клейма существующего сварщика по ID (проверка исправления бага дублирования)
  const updatedWelder2: WelderProfile = {
    ...welders[1],
    stamp: 'В702М',
  };
  welders = welders.some((x) => (updatedWelder2.id && x.id === updatedWelder2.id) || x.stamp === updatedWelder2.stamp)
    ? welders.map((x) =>
        (updatedWelder2.id && x.id === updatedWelder2.id) || x.stamp === updatedWelder2.stamp
          ? updatedWelder2
          : x
      )
    : [updatedWelder2, ...welders];
  assert.equal(welders.length, 3, 'Изменение клейма у существующего сварщика должно обновлять карточку, а не создавать дубликат');
  // Возвращаем клеймо В702 для бригады
  welders = welders.map((x) => (x.id === 'w-sim-2' ? { ...x, stamp: 'В702' } : x));

  // Добавление и удаление Техкарт (WPS)
  techCards = [
    {
      id: 'tc-sim-1',
      number: 'ТК-SIM-09Г2С-01',
      title: 'Сварка трубопроводов из стали 09Г2С',
      weldingType: 'РАД+РД',
      steelGroup: '09Г2С',
      minDiameterMm: 57,
      maxDiameterMm: 530,
      minWallThicknessMm: 4,
      maxWallThicknessMm: 20,
      recommendedMaterials: 'Св-08Г2С Ø2.0 / УОНИ-13/55 Ø3.0',
      ntd: 'СТО Газпром 15-1.3-004-2023',
      preheatRules: [
        {
          ambientMinC: 5,
          ambientMaxC: 45,
          minPreheatTempC: 0,
          conditionLabel: 'При T возд. ≥ +5 °C',
        },
        {
          ambientMinC: -40,
          ambientMaxC: 4,
          minPreheatTempC: 120,
          conditionLabel: 'При T возд. от -40 до +4 °C',
        },
      ],
    },
    {
      id: 'tc-sim-del',
      number: 'ТК-УДАЛИТЬ-99',
      title: 'Временная ТК на удаление',
      weldingType: 'РД',
      steelGroup: '20',
      minDiameterMm: 57,
      maxDiameterMm: 108,
      minWallThicknessMm: 4,
      maxWallThicknessMm: 8,
      recommendedMaterials: 'УОНИ-13/55',
      ntd: 'ГОСТ 32569-2013',
      preheatRules: [],
    },
  ];
  techCards = techCards.filter((tc) => tc.id !== 'tc-sim-del');
  assert.equal(techCards.length, 1);

  // Добавление и удаление Сертификатов СМ
  weldingMaterials = [
    {
      id: 'mat-sim-1',
      brandAndDiameter: 'Св-08Г2С Ø2.0',
      type: 'Сварочная проволока',
      standardNtd: 'ГОСТ 2246-70',
      batchNumber: 'П-2026-901',
      certificateNumber: 'СЕРТ-СВ-901',
      naksCertNumber: 'НАКС-СМ-901',
      incomingInspectionAct: 'АВК-901 от 10.09.26',
      status: 'Допущен в производство',
    },
    {
      id: 'mat-sim-2',
      brandAndDiameter: 'УОНИ-13/55 Ø3.0',
      type: 'Покрытые электроды',
      standardNtd: 'ГОСТ 9466-75',
      batchNumber: 'П-2026-902',
      certificateNumber: 'СЕРТ-ЭЛ-902',
      naksCertNumber: 'НАКС-СМ-902',
      incomingInspectionAct: 'АВК-902 от 10.09.26',
      status: 'Допущен в производство',
    },
    {
      id: 'mat-sim-del',
      brandAndDiameter: 'МР-3 Ø4.0 (брак)',
      type: 'Покрытые электроды',
      standardNtd: 'ГОСТ 9466-75',
      batchNumber: 'БРАК-01',
      certificateNumber: 'БРАК-01',
      naksCertNumber: '—',
      incomingInspectionAct: 'Не прошёл ВК',
      status: 'Брак / Карантин',
    },
  ];
  weldingMaterials = weldingMaterials.filter((m) => m.id !== 'mat-sim-del');
  assert.equal(weldingMaterials.length, 2);

  // =========================================================================
  // ЭТАП 3. Работа Инженеров ПТО (pto_smirnov, pto_kuznetsova, pto_volkov):
  // Создание Объектов, Шифров РД, Линий в лайнлисте, Каталога ЛРВ и каскадное удаление
  // =========================================================================
  const rawLinesToImport: Record<string, unknown>[] = [
    {
      'Название объекта': 'УКПГ-2В Бованенковское НГКМ',
      'Шифр РД': '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3',
      'Номер линии': 'ГС-201/1',
      'Наименование линии': 'Линия подачи сырого газа',
      Продукт: 'Природный газ',
      'Контур испытания': 'Контур КВД-201',
      'НТД на сварку': 'СТО Газпром 15-1.1-002-2023',
      'НТД на контроль': 'СТО Газпром 15-1.3-004-2023',
      'Категория трубопровода': 'I',
      'Процент контроля РК': '100%',
      'Процент контроля УЗК': '100%',
      'Процент контроля ПВК': '0%',
    },
    {
      'Название объекта': 'УКПГ-2В Бованенковское НГКМ',
      'Шифр РД': '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3',
      'Номер линии': 'ГС-201/2',
      'Наименование линии': 'Резервная линия сепарации',
      Продукт: 'Природный газ',
      'Контур испытания': 'Контур КВД-201',
      'НТД на сварку': 'СТО Газпром 15-1.1-002-2023',
      'НТД на контроль': 'СТО Газпром 15-1.3-004-2023',
      'Категория трубопровода': 'I',
      'Процент контроля РК': '100%',
      'Процент контроля УЗК': '100%',
      'Процент контроля ПВК': '0%',
    },
    {
      'Название объекта': 'УКПГ-2В Бованенковское НГКМ',
      'Шифр РД': '0092.049.Р.13/1 0004 УКПГ.045.0077.002-ТХ4',
      'Номер линии': 'ДР-999',
      'Наименование линии': 'Временная дренажная линия (на удаление РД)',
      Продукт: 'Конденсат',
      'Контур испытания': 'Контур ДР-1',
    },
    {
      'Название объекта': 'КС «Воркутинская» (Объект на удаление)',
      'Шифр РД': '0092.049.Р.99-ТХ9',
      'Номер линии': 'ВР-101',
      'Наименование линии': 'Временный коллектор',
      Продукт: 'Газ',
      'Контур испытания': 'Контур ВР',
    },
  ];
  projectLineList = parseProjectLineListRecords(
    rawLinesToImport,
    'УКПГ-2В Бованенковское НГКМ',
    '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3'
  );
  assert.equal(projectLineList.length, 4);

  let derivedFacs = deriveFacilitiesFromLineList(projectLineList);
  assert.equal(derivedFacs.length, 2, 'Должны автоматически появиться 2 объекта');

  // Удаление целого Объекта «КС «Воркутинская» (Объект на удаление)»
  projectLineList = projectLineList.filter(
    (l) => l.objectName !== 'КС «Воркутинская» (Объект на удаление)'
  );
  derivedFacs = deriveFacilitiesFromLineList(projectLineList);
  assert.equal(derivedFacs.length, 1, 'После удаления объекта должен остаться 1 объект');

  // Удаление Шифра РД «0092.049.Р.13/1 0004 УКПГ.045.0077.002-ТХ4»
  projectLineList = projectLineList.filter(
    (l) => l.rdCode !== '0092.049.Р.13/1 0004 УКПГ.045.0077.002-ТХ4'
  );
  derivedFacs = deriveFacilitiesFromLineList(projectLineList);
  assert.equal(derivedFacs[0].rdCodes.length, 1, 'Должен остаться 1 рабочий шифр РД');

  // Добавление ещё одной линии и удаление одной линии
  projectLineList.push({
    id: 'pl-del-line',
    objectName: 'УКПГ-2В Бованенковское НГКМ',
    rdCode: '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3',
    lineNumber: 'ЛИНИЯ-УДАЛИТЬ',
    uniqueLineId: buildUniqueLineId(
      '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3',
      'ЛИНИЯ-УДАЛИТЬ'
    ),
    lineName: 'Линия на удаление',
    product: 'Вода',
    testContour: 'Контур КВД-201',
    weldingNtd: 'СТО Газпром',
    controlNtd: 'СТО Газпром',
    qualityLevel: 'Уровень В',
    pipelineCategory: 'II',
    workingPressure: '10 МПа',
    workingTemperature: '+20 °C',
    rkPercent: 100,
    uzkPercent: 0,
    pvkPercent: 0,
  });
  assert.equal(projectLineList.length, 3);
  projectLineList = projectLineList.filter((l) => l.id !== 'pl-del-line');
  assert.equal(projectLineList.length, 2, 'Линия должна быть успешно удалена');

  // Заполнение Каталога ЛРВ (Инженер ПТО Кузнецова Е.С.) + редактирование и удаление позиции ЛРВ
  const activeRd = '0092.049.Р.13/1 0004 УКПГ.045.0077.001-ТХ3';
  lrvCatalog = [
    {
      id: 'lrv-sim-1',
      lrvCode: 'ЛРВ-СИМ-001',
      rdCode: activeRd,
      objectName: 'УКПГ-2В Бованенковское НГКМ',
      shortName: 'Труба БШ 219х12',
      material: '09Г2С',
      ntd: 'ГОСТ 8732-78',
      manufacturer: 'ПАО «ЧТПЗ»',
      dn1: 200,
      diameterMm: 219,
      wallThickness: 12,
      specQty: 120,
      unit: 'м',
    },
    {
      id: 'lrv-sim-2',
      lrvCode: 'ЛРВ-СИМ-002',
      rdCode: activeRd,
      objectName: 'УКПГ-2В Бованенковское НГКМ',
      shortName: 'Отвод 90° 219х12',
      material: '09Г2С',
      ntd: 'ГОСТ 17375-2001',
      manufacturer: 'АО «СОТ»',
      dn1: 200,
      diameterMm: 219,
      wallThickness: 12,
      specQty: 24,
      unit: 'шт',
    },
    {
      id: 'lrv-sim-3',
      lrvCode: 'ЛРВ-СИМ-003',
      rdCode: activeRd,
      objectName: 'УКПГ-2В Бованенковское НГКМ',
      shortName: 'Переход К 219х12-159х8',
      material: '09Г2С',
      ntd: 'ГОСТ 17378-2001',
      manufacturer: 'АО «СОТ»',
      dn1: 200,
      diameterMm: 219,
      wallThickness: 12,
      dn2: 150,
      diameterMm2: 159,
      wallThickness2: 8,
      specQty: 10,
      unit: 'шт',
    },
    {
      id: 'lrv-sim-del',
      lrvCode: 'ЛРВ-УДАЛИТЬ-99',
      rdCode: activeRd,
      objectName: 'УКПГ-2В Бованенковское НГКМ',
      shortName: 'Заглушка (ошибочная)',
      material: '09Г2С',
      ntd: 'ГОСТ 17379-2001',
      diameterMm: 219,
      wallThickness: 12,
      specQty: 1,
      unit: 'шт',
    },
  ];
  lrvCatalog = lrvCatalog.filter((c) => c.id !== 'lrv-sim-del');
  assert.equal(lrvCatalog.length, 3, 'Ошибочная позиция ЛРВ должна быть удалена');

  // Редактирование позиции ЛРВ (проверка новой кнопки редактирования в ЛРВ)
  lrvCatalog = lrvCatalog.map((c) =>
    c.id === 'lrv-sim-1' ? { ...c, specQty: 150 } : c
  );
  assert.equal(lrvCatalog[0].specQty, 150, 'Количество по спецификации в ЛРВ должно обновиться');

  // =========================================================================
  // ЭТАП 4. Пакетный импорт стыков из Excel с автопривязкой + добавление доп. стыков 011, 012 + удаление стыка
  // =========================================================================
  const excelRowsToImport = [
    {
      'Шифр РД': activeRd,
      'Номер линии': 'ГС-201/1',
      'Номер стыка': '010',
      'Диаметр и толщина стенки': '219х12',
      'Код ЛРВ 1': 'ЛРВ-СИМ-001',
      'Код ЛРВ 2': 'ЛРВ-СИМ-002',
      'Тип соединения (ГОСТ)': 'С17',
    },
    {
      'Шифр РД': activeRd,
      'Номер линии': 'ГС-201/1',
      'Номер стыка': '020',
      'Диаметр и толщина стенки': '219х12',
      'Код ЛРВ 1': 'ЛРВ-СИМ-002',
      'Код ЛРВ 2': 'ЛРВ-СИМ-003',
      'Тип соединения (ГОСТ)': 'С17',
    },
    {
      'Шифр РД': activeRd,
      'Номер линии': 'ГС-201/1',
      'Номер стыка': '030',
      'Диаметр и толщина стенки': '219х12',
      'Код ЛРВ 1': 'ЛРВ-СИМ-001',
      'Код ЛРВ 2': 'ЛРВ-СИМ-001',
      'Тип соединения (ГОСТ)': 'У4',
    },
    {
      'Шифр РД': activeRd,
      'Номер линии': 'ГС-201/2',
      'Номер стыка': '010',
      'Диаметр и толщина стенки': '219х12',
      'Код ЛРВ 1': 'ЛРВ-СИМ-001',
      'Код ЛРВ 2': 'ЛРВ-СИМ-002',
      'Тип соединения (ГОСТ)': 'С17',
    },
  ];

  const importResult = parseAndValidateJointsImport(
    excelRowsToImport,
    projectLineList,
    lrvCatalog,
    techCards,
    joints,
    'УКПГ-2В Бованенковское НГКМ',
    activeRd
  );
  assert.equal(importResult.errorCount, 0, 'Все 4 проектных стыка должны пройти валидацию без ошибок');
  joints = importResult.rows.map((r) => r.jointToImport!);
  assert.equal(joints.length, 4);
  assert.equal(joints[0].techCardNumber, 'ТК-SIM-09Г2С-01', 'Техкарта должна автоматически привязаться по диаметру и толщине');
  assert.equal(joints[0].elem1Manufacturer, 'ПАО «ЧТПЗ»', 'Завод-изготовитель элемента 1 должен подтянуться из ЛРВ');
  assert.equal(joints[0].elem2Manufacturer, 'АО «СОТ»', 'Завод-изготовитель элемента 2 должен подтянуться из ЛРВ');

  // Добавление дополнительного (ремонтного/монтажного) стыка 011 и временного 012 (на удаление)
  const line1Nums = joints
    .filter((j) => j.lineNumber === 'ГС-201/1')
    .map((j) => j.jointNumber);
  const suppNum1 = suggestNextJointNumber(line1Nums, '010');
  assert.equal(suppNum1, '011');
  const suppJoint011: WeldJoint = {
    ...joints[0],
    id: 'j-sim-011',
    jointNumber: suppNum1,
  };
  joints.push(suppJoint011);

  const suppJoint012ToDel: WeldJoint = {
    ...joints[0],
    id: 'j-sim-012-del',
    jointNumber: '012',
  };
  joints.push(suppJoint012ToDel);
  assert.equal(joints.length, 6);

  // Удаление ошибочного стыка 012
  joints = joints.filter((j) => j.id !== 'j-sim-012-del');
  assert.equal(joints.length, 5, 'Ошибочный стык 012 должен быть удалён');

  // =========================================================================
  // ЭТАП 5. Разноска сварки по рапортам (Инженер ПТО Волков Д.И.) и контроль (ЛНК Лебедев С.А., Попов М.В., Новикова О.А.)
  // Включая сценарий «Ремонт» -> Повторный контроль «Годен» и стек Undo/Redo
  // =========================================================================
  let undoStack: WeldJoint[][] = [];
  let redoStack: WeldJoint[][] = [];

  undoStack = pushHistorySnapshot(undoStack, joints, MAX_HISTORY_STEPS).undoStack;

  // Массовое редактирование сварки для стыков 010, 011, 020 на линии ГС-201/1 (клеймо А701)
  const resolvedSingle = resolveWeldersSelection(['А701'], undefined, welders);
  const bulkWeldingRes = applyBulkUpdateToJoints(
    joints,
    [joints[0].id, suppJoint011.id, joints[1].id],
    {
      weldingDate: '2026-10-14',
      ambientTemp: String(estimateAmbientTempByCoordsAndDate(70.37, 68.44, '2026-10-14')),
      welderStamp: resolvedSingle.welderStamp,
      welderFullName: resolvedSingle.welderFullName,
      welderCertNumber: resolvedSingle.welderCertNumber,
      responsiblePerson: resolvedSingle.responsiblePerson,
      preheatTemp: '+140',
      elem1Length: 11.5,
      elem2Length: 0.45,
      elem1FactoryNumber: 'СЕРТ-ТР-101',
      elem2FactoryNumber: 'СЕРТ-ОТВ-202',
      weldingMaterials: 'Св-08Г2С Ø2.0 / УОНИ-13/55 Ø3.0',
    },
    {
      login: 'pto_volkov',
      fullName: 'Волков Дмитрий Игоревич',
      role: 'Инженер ПТО',
    },
    FIELD_LABELS_MAP
  );
  joints = bulkWeldingRes.updatedJoints;
  auditLogs = [...bulkWeldingRes.auditEntries, ...auditLogs];

  // Сварка стыка 030 (угловой У4) и стыка 010 на ГС-201/2 бригадой БР-70
  const resolvedBrigade = resolveWeldersSelection([], 'БР-70', welders);
  assert.equal(resolvedBrigade.welderStamp, 'БР-70 (А701, В702)', 'Бригада БР-70 должна раскрываться в личные клейма членов бригады');
  const bulkBrigadeRes = applyBulkUpdateToJoints(
    joints,
    [joints[2].id, joints[3].id],
    {
      weldingDate: '2026-10-15',
      ambientTemp: '-8',
      welderStamp: resolvedBrigade.welderStamp,
      welderFullName: resolvedBrigade.welderFullName,
      welderCertNumber: resolvedBrigade.welderCertNumber,
      responsiblePerson: resolvedBrigade.responsiblePerson,
      preheatTemp: '+140',
      elem1Length: 6.2,
      elem2Length: 5.8,
      elem1FactoryNumber: 'СЕРТ-ТР-103',
      elem2FactoryNumber: 'СЕРТ-ТР-104',
      weldingMaterials: 'Св-08Г2С Ø2.0 / УОНИ-13/55 Ø3.0',
    },
    {
      login: 'pto_volkov',
      fullName: 'Волков Дмитрий Игоревич',
      role: 'Инженер ПТО',
    },
    FIELD_LABELS_MAP
  );
  joints = bulkBrigadeRes.updatedJoints;

  // Проверка Undo / Redo
  const undoStep = performUndoStep(undoStack, redoStack, joints, MAX_HISTORY_STEPS);
  assert.equal(Boolean(undoStep.targetState), true);
  assert.equal(undoStep.targetState![0].weldingDate, '', 'После Undo дата сварки должна откатиться');
  const redoStep = performRedoStep(
    undoStep.undoStack,
    undoStep.redoStack,
    undoStep.targetState!,
    MAX_HISTORY_STEPS
  );
  joints = redoStep.targetState!;
  assert.equal(joints[0].weldingDate, '2026-10-14', 'После Redo дата сварки должна восстановиться');

  // Внесение ВИК и Первичного НК (Дефектоскописты Новикова О.А. и Попов М.В.):
  // 4 стыка -> Годен, а стык 020 (joints[1]) -> Ремонт при первичном РК!
  const goodIds = [joints[0].id, suppJoint011.id, joints[2].id, joints[3].id];
  joints = applyBulkUpdateToJoints(
    joints,
    goodIds,
    {
      vikResult: 'Годен',
      vikDate: '2026-10-16',
      vikInspector: 'Новикова О.А.',
      ndtType: 'РК',
      ndtResult: 'Годен',
      ndtDate: '2026-10-17',
      ndtInspector: 'Попов М.В.',
      dupNdtType: 'Не требуется',
      dupNdtResult: 'Не проводился',
    },
    {
      login: 'lnk_popov',
      fullName: 'Попов Максим Валерьевич',
      role: 'Дефектоскопист РК/УЗК',
    },
    FIELD_LABELS_MAP
  ).updatedJoints;

  // Стык 020 получает заключение «Ремонт» при первичном РК
  joints = applyBulkUpdateToJoints(
    joints,
    [joints[1].id],
    {
      vikResult: 'Годен',
      vikDate: '2026-10-16',
      vikInspector: 'Новикова О.А.',
      ndtType: 'РК',
      ndtResult: 'Ремонт',
      ndtDate: '2026-10-17',
      ndtInspector: 'Лебедев С.А.',
    },
    {
      login: 'lnk_lebedev',
      fullName: 'Лебедев Сергей Анатольевич',
      role: 'Начальник ЛНК',
    },
    FIELD_LABELS_MAP
  ).updatedJoints;

  assert.equal(isJointCurrentlyInRepair(joints[1]), true, 'Стык 020 должен числиться в активном ремонте');
  assert.equal(isJointFullyAccepted(joints[1]), false);

  // Закрытие ремонта стыка 020 повторным контролем «РК» -> «Годен»
  joints = applyBulkUpdateToJoints(
    joints,
    [joints[1].id],
    {
      dupNdtType: 'РК',
      dupNdtResult: 'Годен',
      dupNdtDate: '2026-10-19',
      dupNdtInspector: 'Лебедев С.А.',
    },
    {
      login: 'lnk_lebedev',
      fullName: 'Лебедев Сергей Анатольевич',
      role: 'Начальник ЛНК',
    },
    FIELD_LABELS_MAP
  ).updatedJoints;

  assert.equal(isJointCurrentlyInRepair(joints[1]), false, 'После Годен по повторному НК стык снимается с ремонта');
  assert.equal(isJointFullyAccepted(joints[1]), true, 'Стык 020 должен перейти в 100% принятые стыки');

  // Комплексная проверка всех 5 паспортов стыков по диаметрам, подогреву и виду сварки
  joints.forEach((j) => {
    const diamCheck = validateElementsDiameterMatch(
      j.elem1DiameterMm ?? j.diameterMm,
      j.elem2DiameterMm ?? j.diameterMm
    );
    assert.equal(diamCheck.isMatch, true, `Диаметры элементов стыка ${j.jointNumber} должны совпадать`);
    const preheatCheck = validatePreheatTemperature(j.preheatTemp, j.ambientTemp, techCards[0]);
    assert.equal(preheatCheck.isValid, true, `Подогрев стыка ${j.jointNumber} должен соответствовать ТК`);
    const wtCheck = validateWeldingTypeWithTechCard(j.weldingType, techCards[0]);
    assert.equal(wtCheck.isValid, true, `Вид сварки стыка ${j.jointNumber} должен соответствовать ТК`);
  });

  // Проверка сводки готовности (Readiness Report) и расчёта статуса линий лайнлиста
  const readinessByLine = calculateReadinessReport(joints, 'uniqueLineId');
  assert.equal(readinessByLine.length, 2);
  assert.equal(readinessByLine.every((r) => r.readinessPct === 100), true, 'Обе линии должны иметь 100% готовность');
  const line1Status = computeLineListItemStatus(projectLineList[0], joints);
  assert.equal(line1Status.isCompleted, true, 'Линия 1 в лайнлисте должна получить статус 100% готовности');
  assert.ok(line1Status.statusLabel.includes('Все стыки сварены и проконтролированы'));

  // =========================================================================
  // ЭТАП 6. Полный Бэкап (.JSON), Обнуление Автором («Чистый лист») и Восстановление из Бэкапа
  // =========================================================================
  const backupPayload: FullSystemBackupPayload = {
    backupFormat: 'ZAYCHICK_FULL_BACKUP_V1',
    appVersion: '2.5.0',
    createdAt: new Date().toISOString(),
    createdByLogin: 'ilchenko.vlad@gmail.com',
    createdByFullName: 'Ильченко В.',
    comment: 'Полный бэкап симуляции 10 пользователей',
    data: {
      joints: JSON.parse(JSON.stringify(joints)),
      projectLineList: JSON.parse(JSON.stringify(projectLineList)),
      lrvCatalog: JSON.parse(JSON.stringify(lrvCatalog)),
      welders: JSON.parse(JSON.stringify(welders)),
      techCards: JSON.parse(JSON.stringify(techCards)),
      weldingMaterials: JSON.parse(JSON.stringify(weldingMaterials)),
      userAccounts: JSON.parse(JSON.stringify(userAccounts)),
      auditLogs: JSON.parse(JSON.stringify(auditLogs)),
      facilityGeoOverrides: {},
      templates: [],
      activeTemplateId: 'tpl-full-all',
    },
  };

  // Скрытый сброс Автора («Чистый лист»)
  joints = [];
  projectLineList = [];
  lrvCatalog = [];
  welders = [];
  techCards = [];
  weldingMaterials = [];
  assert.equal(joints.length, 0);
  assert.equal(projectLineList.length, 0);

  // Восстановление 100% функционала и данных из бэкапа
  joints = backupPayload.data.joints;
  projectLineList = backupPayload.data.projectLineList;
  lrvCatalog = backupPayload.data.lrvCatalog;
  welders = backupPayload.data.welders;
  techCards = backupPayload.data.techCards;
  weldingMaterials = backupPayload.data.weldingMaterials;
  userAccounts = backupPayload.data.userAccounts;
  assert.equal(joints.length, 5, 'Все 5 стыков должны восстановиться из бэкапа');
  assert.equal(userAccounts.length, 9, 'Все 9 активных пользователей должны восстановиться из бэкапа');

  // =========================================================================
  // ЭТАП 7. Формирование и проверка печати журналов СТО Газпром 15-1.1-002-2023 (49 граф) и ГОСТ 32569-2013 (17 граф)
  // =========================================================================
  const sortedForJournal = sortJointsChronologically(joints);
  assert.equal(sortedForJournal.length, 5);

  sortedForJournal.forEach((j, idx) => {
    const stoRow = formatStoGazpromJournalRow(j, idx, lrvCatalog);
    const gostRow = formatGost32569JournalRow(j, idx, weldingMaterials);

    assert.equal(stoRow.cells.length, 49, 'Строка журнала СТО Газпром должна содержать ровно 49 граф');
    assert.equal(gostRow.cells.length, 17, 'Строка журнала ГОСТ 32569-2013 должна содержать ровно 17 граф');

    // Проверка строгих нормативов СТО Газпром 15-1.1-002-2023:
    assert.ok(stoRow.col6.includes('ПАО «ЧТПЗ»') || stoRow.col6.includes('АО «СОТ»'), 'В графе 6 должен быть завод-изготовитель');
    assert.equal(stoRow.col16, 'ТК-SIM-09Г2С-01', 'В графе 16 должен быть только номер ТК без положения сварки');
    assert.ok(['Громов', 'Тимофеев'].includes(stoRow.col19), 'В графе 19 должна быть только фамилия руководителя работ');
    assert.equal(stoRow.col20, '', 'Графа 20 под живую подпись должна быть пустой');
    assert.equal(stoRow.col37, '', 'Графа 37 под живую подпись должна быть пустой');

    if (j.gostJointType === 'У4') {
      assert.equal(stoRow.col14, 'Я', 'Для углового шва У4 в графе 14 ставится Я');
    } else {
      assert.equal(stoRow.col14, 'н/п', 'Для стыкового шва С17 в графе 14 ставится н/п');
    }

    // Проверка отремонтированного стыка 020 в журнале СТО Газпром:
    if (j.jointNumber === '020') {
      assert.equal(stoRow.col27, 'Ремонт', 'В графе 27 первичного НК фиксируется Ремонт');
      assert.equal(stoRow.col31, 'н/п', 'При браке первичного контроля дублирующий контроль (гр. 31) равен н/п');
      assert.equal(stoRow.col32, 'Ремонт', 'В графе 32 указывается Ремонт');
      assert.equal(stoRow.col36, 'Громов', 'В графе 36 указывается только фамилия мастера');
      assert.equal(stoRow.col40, 'Годен', 'В графе 40 ВИК после ремонта — Годен');
      assert.equal(stoRow.col44, 'Годен', 'В графе 44 ФМК после ремонта — Годен');
    }
  });
});




